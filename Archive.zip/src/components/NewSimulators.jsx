import { useState, useEffect, useRef } from 'react'
import { WorkspacePortal, InputCardField, getInitialParam } from './WorkspaceShared'
import { checkRealism, RealismCheckCard } from './RealismCheck'

// ══════════════════════════════════════════════════
//  HELPER: draw arrow with head
// ══════════════════════════════════════════════════
function drawArrow(ctx, x1, y1, x2, y2, color, lineWidth = 2, headSize = 8) {
  const dx = x2 - x1, dy = y2 - y1, len = Math.sqrt(dx * dx + dy * dy)
  if (len < 2) return
  const nx = dx / len, ny = dy / len
  ctx.strokeStyle = color; ctx.lineWidth = lineWidth
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke()
  ctx.fillStyle = color; ctx.beginPath()
  ctx.moveTo(x2, y2)
  ctx.lineTo(x2 - nx * headSize + ny * headSize * 0.4, y2 - ny * headSize - nx * headSize * 0.4)
  ctx.lineTo(x2 - nx * headSize - ny * headSize * 0.4, y2 - ny * headSize + nx * headSize * 0.4)
  ctx.fill()
}

// ══════════════════════════════════════════════════
//  1. PROJECTILE MOTION SIMULATOR — FULL PHYSICS
// ══════════════════════════════════════════════════
export function ProjectileSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [v0, setV0] = useState(() => getInitialParam(initialParams, 'velocity', 25))
  const [angle, setAngle] = useState(() => {
    const val = getInitialParam(initialParams, 'angle', 45)
    if (initialParams && typeof val === 'number') {
      return val * 180 / Math.PI
    }
    return val
  })
  const [localV0, setLocalV0] = useState(25)
  const [localAngle, setLocalAngle] = useState(45)
  useEffect(() => { setLocalV0(v0); setLocalAngle(angle) }, [v0, angle])

  const animRef = useRef()
  
  const isPending = v0 === "" || angle === "";
  const realism = checkRealism('projectile', { velocity: v0, angle: angle })

  const stateRef = useRef({ v0: 25, angle: 45, t: 0, trail: [], phase: 'flying', isPending: false, isRealistic: true })
  useEffect(() => { stateRef.current.v0 = v0; stateRef.current.angle = angle; stateRef.current.t = 0; stateRef.current.trail = []; stateRef.current.phase = 'flying'; stateRef.current.isPending = isPending; stateRef.current.isRealistic = realism.isRealistic }, [v0, angle, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 380
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)

        const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        if (isPending) {
          ctx.fillText('Awaiting required parameters...', W / 2, H / 2)
        } else {
          ctx.fillText('Simulation Suspended — Invalid Parameters', W / 2, H / 2)
        }
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current
      const g = 9.81
      const rad = s.angle * Math.PI / 180
      const vx0 = s.v0 * Math.cos(rad), vy0 = s.v0 * Math.sin(rad)
      const totalTime = 2 * vy0 / g
      const maxRange = vx0 * totalTime
      const maxH = (vy0 * vy0) / (2 * g)

      // Scaling
      const margin = 80
      const scaleX = (W - margin * 2) / Math.max(maxRange, 1)
      const scaleY = (H - 140) / Math.max(maxH * 1.3, 1)
      const groundY = H - 55
      const originX = margin

      // Advance time
      if (s.phase === 'flying') {
        s.t += 0.025
        if (s.t > totalTime) { s.t = totalTime; s.phase = 'landed' }
      } else if (s.phase === 'landed') {
        s.t += 0.025
        if (s.t > totalTime + 2) { s.t = 0; s.trail = []; s.phase = 'flying' }
      }

      const curT = Math.min(s.t, totalTime)
      const px = originX + vx0 * curT * scaleX
      const rawY = vy0 * curT - 0.5 * g * curT * curT
      const py = groundY - rawY * scaleY

      // Trail
      if (s.phase === 'flying' && curT < totalTime) {
        s.trail.push({ x: px, y: py, t: curT })
      }

      ctx.clearRect(0, 0, W, H)

      // Grid
      ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
      for (let x = margin; x < W - margin; x += 60) { ctx.beginPath(); ctx.moveTo(x, 30); ctx.lineTo(x, groundY); ctx.stroke() }
      for (let y = 30; y <= groundY; y += 40) { ctx.beginPath(); ctx.moveTo(margin, y); ctx.lineTo(W - margin, y); ctx.stroke() }

      // Ground
      ctx.strokeStyle = 'rgba(136,192,184,0.25)'; ctx.lineWidth = 2
      ctx.beginPath(); ctx.moveTo(margin - 20, groundY); ctx.lineTo(W - margin + 20, groundY); ctx.stroke()
      // Ground hash marks
      for (let x = margin; x < W - margin; x += 30) {
        ctx.strokeStyle = 'rgba(136,192,184,0.08)'; ctx.lineWidth = 1
        ctx.beginPath(); ctx.moveTo(x, groundY); ctx.lineTo(x - 6, groundY + 8); ctx.stroke()
      }

      // Ideal parabola (faint dashed)
      ctx.beginPath()
      ctx.setLineDash([5, 5]); ctx.strokeStyle = 'rgba(196,149,106,0.12)'; ctx.lineWidth = 1
      for (let t = 0; t <= totalTime; t += totalTime / 150) {
        const x = originX + vx0 * t * scaleX
        const y = groundY - (vy0 * t - 0.5 * g * t * t) * scaleY
        t === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)
      }
      ctx.stroke(); ctx.setLineDash([])

      // Apex marker
      const apexT = vy0 / g
      const apexX = originX + vx0 * apexT * scaleX
      const apexY = groundY - maxH * scaleY
      ctx.setLineDash([3, 3]); ctx.strokeStyle = 'rgba(196,149,106,0.25)'; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(apexX, apexY); ctx.lineTo(apexX, groundY); ctx.stroke()
      ctx.beginPath(); ctx.moveTo(margin, apexY); ctx.lineTo(apexX, apexY); ctx.stroke()
      ctx.setLineDash([])
      ctx.fillStyle = 'rgba(196,149,106,0.5)'; ctx.font = '10px var(--font-body)'
      ctx.textAlign = 'center'; ctx.fillText(`H = ${maxH.toFixed(1)}m`, apexX, apexY - 10)

      // Landing marker
      const landX = originX + maxRange * scaleX
      ctx.fillStyle = 'rgba(136,192,184,0.3)'
      ctx.beginPath(); ctx.arc(landX, groundY, 4, 0, Math.PI * 2); ctx.fill()
      ctx.fillStyle = 'rgba(136,192,184,0.5)'; ctx.font = '10px var(--font-body)'
      ctx.textAlign = 'center'; ctx.fillText(`R = ${maxRange.toFixed(1)}m`, landX, groundY + 18)

      // Launch point
      ctx.fillStyle = 'rgba(196,149,106,0.5)'
      ctx.beginPath(); ctx.arc(originX, groundY, 5, 0, Math.PI * 2); ctx.fill()
      // Angle indicator arc
      ctx.strokeStyle = 'rgba(196,149,106,0.3)'; ctx.lineWidth = 1.5
      ctx.beginPath(); ctx.arc(originX, groundY, 35, -rad, 0); ctx.stroke()
      ctx.fillStyle = 'rgba(196,149,106,0.4)'; ctx.font = '10px var(--font-body)'
      ctx.fillText(`${s.angle}°`, originX + 42, groundY - 8)

      // Trail
      if (s.trail.length > 1) {
        ctx.beginPath()
        ctx.moveTo(s.trail[0].x, s.trail[0].y)
        for (let i = 1; i < s.trail.length; i++) {
          ctx.lineTo(s.trail[i].x, s.trail[i].y)
        }
        ctx.strokeStyle = 'rgba(136,192,184,0.5)'; ctx.lineWidth = 2.5; ctx.stroke()
      }

      // Projectile ball (only during flight or at landing)
      if (s.phase === 'flying' || (s.phase === 'landed' && s.t <= totalTime + 0.5)) {
        // Glow
        ctx.fillStyle = 'rgba(136,192,184,0.15)'; ctx.beginPath(); ctx.arc(px, py, 16, 0, Math.PI * 2); ctx.fill()
        // Ball
        const ballGrad = ctx.createRadialGradient(px - 2, py - 2, 0, px, py, 8)
        ballGrad.addColorStop(0, '#a8ddd6'); ballGrad.addColorStop(1, '#88C0B8')
        ctx.fillStyle = ballGrad; ctx.beginPath(); ctx.arc(px, py, 7, 0, Math.PI * 2); ctx.fill()

        // Velocity vectors (only during flight)
        if (s.phase === 'flying') {
          const vyNow = vy0 - g * curT
          const vScale = 1.2
          // Horizontal velocity (green-ish)
          drawArrow(ctx, px, py, px + vx0 * vScale, py, 'rgba(136,192,184,0.7)', 1.5, 6)
          // Vertical velocity (gold)
          drawArrow(ctx, px, py, px, py - vyNow * vScale, 'rgba(196,149,106,0.7)', 1.5, 6)
          // Resultant velocity (white)
          const vMag = Math.sqrt(vx0 * vx0 + vyNow * vyNow)
          const vAngle = Math.atan2(-vyNow, vx0)
          drawArrow(ctx, px, py, px + Math.cos(vAngle) * vMag * vScale, py + Math.sin(vAngle) * vMag * vScale, 'rgba(232,221,204,0.6)', 2, 7)
        }
      }

      // Time display
      ctx.fillStyle = 'rgba(220,200,165,0.6)'; ctx.font = '12px var(--font-body)'; ctx.textAlign = 'left'
      ctx.fillText(`t = ${curT.toFixed(2)} s`, W - 160, 30)
      ctx.fillText(`T = ${totalTime.toFixed(2)} s`, W - 160, 50)

      // Legend
      ctx.fillStyle = 'rgba(136,192,184,0.5)'; ctx.fillRect(40, 20, 8, 8)
      ctx.fillStyle = 'rgba(220,200,165,0.4)'; ctx.font = '10px var(--font-body)'
      ctx.fillText('vₓ', 52, 28)
      ctx.fillStyle = 'rgba(196,149,106,0.5)'; ctx.fillRect(40, 34, 8, 8)
      ctx.fillStyle = 'rgba(220,200,165,0.4)'; ctx.fillText('vᵧ', 52, 42)

      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const g = 9.81, rad = angle * Math.PI / 180
  const vx = v0 * Math.cos(rad), vy = v0 * Math.sin(rad)
  const totalTime = 2 * vy / g, maxRange = vx * totalTime, maxH = vy * vy / (2 * g)

  const handleCalc = () => {
    if (localV0 === "" || localAngle === "") {
      if (localV0 === "") setV0("");
      if (localAngle === "") setAngle("");
      return;
    }

    let pv = parseFloat(localV0); if (isNaN(pv)) pv = 25; pv = Math.max(1, Math.min(100, pv))
    let pa = parseFloat(localAngle); if (isNaN(pa)) pa = 45; pa = Math.max(1, Math.min(89, pa))
    setV0(pv); setAngle(pa)
  }
  const handleReset = () => { setV0(25); setAngle(45) }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InputCardField label="Initial Velocity" value={localV0} min={1} max={100} step={0.5} onChange={setLocalV0} unit="m/s" />
            <InputCardField label="Launch Angle" value={localAngle} min={1} max={89} step={1} onChange={setLocalAngle} unit="°" />
          </div>
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>Calculate</button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button>
          </div>
        </div>
      </WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="projectile" params={{ velocity: v0, angle: angle }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Range (R):</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${maxRange.toFixed(2)} m` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Max Height (H):</span>
            <span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${maxH.toFixed(2)} m` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}>
            <span className="opacity-50">Time of Flight (T):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${totalTime.toFixed(3)} s` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Horizontal Vel (vₓ):</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${vx.toFixed(2)} m/s` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Initial Vert Vel (vᵧ):</span>
            <span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${vy.toFixed(2)} m/s` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Equations:</span>
            <span className="font-mono text-xs text-[#E8C880] block">R = v₀²sin(2θ)/g = {(!isPending && realism.isRealistic) ? `${v0}²sin(${2*angle}°)/9.81 = ${maxRange.toFixed(2)} m` : "[Missing]"}</span>
            <span className="font-mono text-xs text-[#88C0B8] block mt-1">H = v₀²sin²θ/(2g) = {(!isPending && realism.isRealistic) ? `${maxH.toFixed(2)} m` : "[Missing]"}</span>
            <span className="font-mono text-xs text-[#C4956A] block mt-1">T = 2v₀sinθ/g = {(!isPending && realism.isRealistic) ? `${totalTime.toFixed(3)} s` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

// ══════════════════════════════════════════════════
//  2. CONSERVATION OF ENERGY SIMULATOR
// ══════════════════════════════════════════════════
export function EnergySimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [mass, setMass] = useState(() => getInitialParam(initialParams, 'mass', 2))
  const [height, setHeight] = useState(() => getInitialParam(initialParams, 'height', 10))
  const [localMass, setLocalMass] = useState(2)
  const [localHeight, setLocalHeight] = useState(10)
  useEffect(() => { setLocalMass(mass); setLocalHeight(height) }, [mass, height])

  const animRef = useRef()
  
  const isPending = mass === "" || height === "";
  const realism = checkRealism('energy', { mass: mass, height: height })

  const stateRef = useRef({ mass: 2, height: 10, t: 0, isPending: false, isRealistic: true })
  useEffect(() => { stateRef.current.mass = mass; stateRef.current.height = height; stateRef.current.isPending = isPending; stateRef.current.isRealistic = realism.isRealistic }, [mass, height, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
        const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        if (isPending) {
          ctx.fillText('Awaiting required parameters...', W / 2, H / 2)
        } else {
          ctx.fillText('Simulation Suspended — Invalid Parameters', W / 2, H / 2)
        }
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const { mass, height } = stateRef.current
      stateRef.current.t += 0.012
      const g = 9.81, totalE = mass * g * height
      const period = Math.sqrt(2 * height / g) * 2
      const phase = (stateRef.current.t % period) / period
      const curH = height * Math.abs(Math.cos(phase * Math.PI))
      const pe = mass * g * curH, ke = totalE - pe
      const barW = 80, maxBarH = H - 100
      ctx.clearRect(0, 0, W, H)
      // Ramp
      ctx.strokeStyle = 'rgba(136,192,184,0.2)'; ctx.lineWidth = 2
      ctx.beginPath(); ctx.moveTo(200, H - 50); ctx.lineTo(600, H - 50); ctx.lineTo(200, 50); ctx.closePath(); ctx.stroke()
      // Ball on ramp
      const ballX = 200 + (600 - 200) * (1 - curH / height)
      const ballY = 50 + (H - 100) * (1 - curH / height)
      ctx.fillStyle = '#88C0B8'; ctx.beginPath(); ctx.arc(ballX, ballY, 8, 0, Math.PI * 2); ctx.fill()
      ctx.fillStyle = 'rgba(136,192,184,0.2)'; ctx.beginPath(); ctx.arc(ballX, ballY, 16, 0, Math.PI * 2); ctx.fill()
      // Energy bars
      const barX1 = W - 220, barX2 = W - 120
      const peH = (pe / totalE) * maxBarH, keH = (ke / totalE) * maxBarH
      ctx.fillStyle = 'rgba(196,149,106,0.15)'; ctx.fillRect(barX1, 50, barW, maxBarH)
      ctx.fillStyle = '#C4956A'; ctx.fillRect(barX1, 50 + maxBarH - peH, barW, peH)
      ctx.fillStyle = 'rgba(220,200,165,0.6)'; ctx.font = '11px var(--font-body)'
      ctx.fillText('PE', barX1 + 30, 42)
      ctx.fillStyle = 'rgba(136,192,184,0.15)'; ctx.fillRect(barX2, 50, barW, maxBarH)
      ctx.fillStyle = '#88C0B8'; ctx.fillRect(barX2, 50 + maxBarH - keH, barW, keH)
      ctx.fillText('KE', barX2 + 30, 42)
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'
      ctx.fillText(`E_total = ${totalE.toFixed(1)} J`, 40, 25)
      ctx.fillText(`PE = ${pe.toFixed(1)} J  KE = ${ke.toFixed(1)} J`, 40, 45)
      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const g = 9.81, totalE = mass * g * height, maxV = Math.sqrt(2 * g * height)
  const handleCalc = () => {
    if (localMass === "" || localHeight === "") {
      if (localMass === "") setMass("");
      if (localHeight === "") setHeight("");
      return;
    }

    let pm = parseFloat(localMass); if (isNaN(pm)) pm = 2; pm = Math.max(0.1, Math.min(100, pm))
    let ph = parseFloat(localHeight); if (isNaN(ph)) ph = 10; ph = Math.max(0.5, Math.min(100, ph))
    setMass(pm); setHeight(ph)
  }
  const handleReset = () => { setMass(2); setHeight(10); stateRef.current.t = 0 }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InputCardField label="Mass" value={localMass} min={0.1} max={100} step={0.1} onChange={setLocalMass} unit="kg" />
            <InputCardField label="Height" value={localHeight} min={0.5} max={100} step={0.5} onChange={setLocalHeight} unit="m" />
          </div>
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>Calculate</button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button>
          </div>
        </div>
      </WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="energy" params={{ mass: mass, height: height }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Total Energy:</span><span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${totalE.toFixed(2)} J` : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">PE at top:</span><span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${totalE.toFixed(2)} J` : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}><span className="opacity-50">Max Velocity:</span><span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${maxV.toFixed(3)} m/s` : "[Missing]"}</span></div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">v = √(2gh) = {(!isPending && realism.isRealistic) ? `√(2 × 9.81 × ${height}) = ${maxV.toFixed(3)} m/s` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

// ══════════════════════════════════════════════════
//  3. MOMENTUM / ELASTIC COLLISION — STATE MACHINE
// ══════════════════════════════════════════════════
export function MomentumSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [m1, setM1] = useState(() => getInitialParam(initialParams, 'mass1', 2))
  const [v1, setV1] = useState(() => getInitialParam(initialParams, 'velocity1', 5))
  const [m2, setM2] = useState(() => getInitialParam(initialParams, 'mass2', 3))
  const [v2, setV2] = useState(() => getInitialParam(initialParams, 'velocity2', -2))
  const [localM1, setLocalM1] = useState(2); const [localV1, setLocalV1] = useState(5)
  const [localM2, setLocalM2] = useState(3); const [localV2, setLocalV2] = useState(-2)
  useEffect(() => { setLocalM1(m1); setLocalV1(v1); setLocalM2(m2); setLocalV2(v2) }, [m1, v1, m2, v2])

  const animRef = useRef()
  const isPending = m1 === "" || v1 === "" || m2 === "" || v2 === "";
  const realism = checkRealism('momentum', { mass1: m1, velocity1: v1, mass2: m2, velocity2: v2 })
  // State machine: APPROACH -> COLLIDE -> SEPARATE -> PAUSE -> APPROACH
  const stateRef = useRef({
    m1: 2, v1: 5, m2: 3, v2: -2,
    p1: 200, p2: 900,
    phase: 'APPROACH', phaseTimer: 0, flashAlpha: 0, isRealistic: true
  })
  useEffect(() => {
    const s = stateRef.current
    Object.assign(s, { m1, v1, m2, v2, p1: 200, p2: 900, phase: 'APPROACH', phaseTimer: 0, flashAlpha: 0, isPending, isRealistic: realism.isRealistic })
  }, [m1, v1, m2, v2, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 380
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)

        const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        if (isPending) {
          ctx.fillText('Awaiting required parameters...', W / 2, H / 2)
        } else {
          ctx.fillText('Simulation Suspended — Invalid Parameters', W / 2, H / 2)
        }
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current
      const cy = H / 2 + 10
      const size1 = 18 + s.m1 * 3, size2 = 18 + s.m2 * 3
      const speed = 1.2

      // Elastic collision final velocities
      const v1f = ((s.m1 - s.m2) * s.v1 + 2 * s.m2 * s.v2) / (s.m1 + s.m2)
      const v2f = ((s.m2 - s.m1) * s.v2 + 2 * s.m1 * s.v1) / (s.m1 + s.m2)

      // Phase logic
      if (s.phase === 'APPROACH') {
        s.p1 += s.v1 * speed
        s.p2 += s.v2 * speed
        if (s.p1 + size1 >= s.p2 - size2) {
          // Collision!
          s.phase = 'COLLIDE'
          s.phaseTimer = 0
          s.flashAlpha = 1.0
          // Snap to contact
          const mid = (s.p1 + s.p2) / 2
          s.p1 = mid - size1
          s.p2 = mid + size2
        }
      } else if (s.phase === 'COLLIDE') {
        s.phaseTimer += 1
        s.flashAlpha *= 0.92
        if (s.phaseTimer > 30) {
          s.phase = 'SEPARATE'
          s.phaseTimer = 0
        }
      } else if (s.phase === 'SEPARATE') {
        s.p1 += v1f * speed
        s.p2 += v2f * speed
        s.phaseTimer += 1
        if (s.p1 < -50 || s.p1 > W + 50 || s.p2 < -50 || s.p2 > W + 50 || s.phaseTimer > 200) {
          s.phase = 'PAUSE'
          s.phaseTimer = 0
        }
      } else if (s.phase === 'PAUSE') {
        s.phaseTimer += 1
        if (s.phaseTimer > 60) {
          s.p1 = 200; s.p2 = 900
          s.phase = 'APPROACH'
          s.phaseTimer = 0
        }
      }

      ctx.clearRect(0, 0, W, H)

      // Track
      ctx.strokeStyle = 'rgba(136,192,184,0.15)'; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(40, cy + 50); ctx.lineTo(W - 40, cy + 50); ctx.stroke()
      // Track markers
      for (let x = 100; x < W - 100; x += 80) {
        ctx.strokeStyle = 'rgba(136,192,184,0.06)'; ctx.lineWidth = 1
        ctx.beginPath(); ctx.moveTo(x, cy + 45); ctx.lineTo(x, cy + 55); ctx.stroke()
      }

      // Collision flash
      if (s.flashAlpha > 0.05) {
        const mid = (s.p1 + s.p2) / 2
        const flashGrad = ctx.createRadialGradient(mid, cy, 0, mid, cy, 60)
        flashGrad.addColorStop(0, `rgba(232,200,128,${s.flashAlpha * 0.4})`)
        flashGrad.addColorStop(1, `rgba(232,200,128,0)`)
        ctx.fillStyle = flashGrad; ctx.beginPath(); ctx.arc(mid, cy, 60, 0, Math.PI * 2); ctx.fill()
      }

      // Ball 1
      const g1 = ctx.createRadialGradient(s.p1 - size1 * 0.2, cy - size1 * 0.2, 0, s.p1, cy, size1)
      g1.addColorStop(0, '#a8ddd6'); g1.addColorStop(1, '#6aa8a0')
      ctx.fillStyle = g1; ctx.beginPath(); ctx.arc(s.p1, cy, size1, 0, Math.PI * 2); ctx.fill()
      ctx.fillStyle = 'rgba(220,200,165,0.8)'; ctx.font = 'bold 12px var(--font-body)'; ctx.textAlign = 'center'
      ctx.fillText(`m₁=${s.m1}kg`, s.p1, cy - size1 - 12)

      // Ball 2
      const g2 = ctx.createRadialGradient(s.p2 - size2 * 0.2, cy - size2 * 0.2, 0, s.p2, cy, size2)
      g2.addColorStop(0, '#f0a060'); g2.addColorStop(1, '#c06830')
      ctx.fillStyle = g2; ctx.beginPath(); ctx.arc(s.p2, cy, size2, 0, Math.PI * 2); ctx.fill()
      ctx.fillText(`m₂=${s.m2}kg`, s.p2, cy - size2 - 12)

      // Velocity arrows
      const curV1 = s.phase === 'SEPARATE' || s.phase === 'PAUSE' ? v1f : s.v1
      const curV2 = s.phase === 'SEPARATE' || s.phase === 'PAUSE' ? v2f : s.v2
      const arrowScale = 8
      if (s.phase !== 'COLLIDE' && s.phase !== 'PAUSE') {
        drawArrow(ctx, s.p1, cy - size1 - 28, s.p1 + curV1 * arrowScale, cy - size1 - 28, '#88C0B8', 2, 6)
        drawArrow(ctx, s.p2, cy - size2 - 28, s.p2 + curV2 * arrowScale, cy - size2 - 28, '#E07840', 2, 6)
      }

      // Momentum arrows (below track)
      const pScale = 4
      const mom1 = s.m1 * curV1, mom2 = s.m2 * curV2
      if (s.phase !== 'PAUSE') {
        drawArrow(ctx, s.p1, cy + 70, s.p1 + mom1 * pScale, cy + 70, 'rgba(136,192,184,0.5)', 1.5, 5)
        drawArrow(ctx, s.p2, cy + 70, s.p2 + mom2 * pScale, cy + 70, 'rgba(224,120,64,0.5)', 1.5, 5)
        ctx.fillStyle = 'rgba(220,200,165,0.35)'; ctx.font = '9px var(--font-body)'; ctx.textAlign = 'center'
        ctx.fillText('p₁', s.p1, cy + 85)
        ctx.fillText('p₂', s.p2, cy + 85)
      }

      // Phase label
      ctx.textAlign = 'center'
      const phaseLabels = { APPROACH: 'Before Collision', COLLIDE: '⚡ Collision!', SEPARATE: 'After Collision', PAUSE: 'Resetting...' }
      const phaseColors = { APPROACH: 'rgba(136,192,184,0.6)', COLLIDE: '#E8C880', SEPARATE: 'rgba(224,120,64,0.6)', PAUSE: 'rgba(220,200,165,0.3)' }
      ctx.fillStyle = phaseColors[s.phase]; ctx.font = '13px var(--font-body)'
      ctx.fillText(phaseLabels[s.phase], W / 2, 30)

      // Total momentum
      ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'
      ctx.fillText(`p_total = ${(s.m1 * s.v1 + s.m2 * s.v2).toFixed(1)} kg·m/s (conserved)`, 40, H - 15)

      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const pTotal = m1 * v1 + m2 * v2
  const v1f = ((m1 - m2) * v1 + 2 * m2 * v2) / (m1 + m2)
  const v2f = ((m2 - m1) * v2 + 2 * m1 * v1) / (m1 + m2)

  const handleCalc = () => {
    if (localM1 === "" || localV1 === "" || localM2 === "" || localV2 === "") {
      if (localM1 === "") setM1("");
      if (localV1 === "") setV1("");
      if (localM2 === "") setM2("");
      if (localV2 === "") setV2("");
      return;
    }

    let pm1 = parseFloat(localM1); if (isNaN(pm1)) pm1 = 2; pm1 = Math.max(0.1, Math.min(50, pm1))
    let pv1 = parseFloat(localV1); if (isNaN(pv1)) pv1 = 5; pv1 = Math.max(-50, Math.min(50, pv1))
    let pm2 = parseFloat(localM2); if (isNaN(pm2)) pm2 = 3; pm2 = Math.max(0.1, Math.min(50, pm2))
    let pv2 = parseFloat(localV2); if (isNaN(pv2)) pv2 = -2; pv2 = Math.max(-50, Math.min(50, pv2))
    setM1(pm1); setV1(pv1); setM2(pm2); setV2(pv2)
  }
  const handleReset = () => { setM1(2); setV1(5); setM2(3); setV2(-2) }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <InputCardField label="Mass 1" value={localM1} min={0.1} max={50} step={0.1} onChange={setLocalM1} unit="kg" />
            <InputCardField label="Velocity 1" value={localV1} min={-50} max={50} step={0.5} onChange={setLocalV1} unit="m/s" />
            <InputCardField label="Mass 2" value={localM2} min={0.1} max={50} step={0.1} onChange={setLocalM2} unit="kg" />
            <InputCardField label="Velocity 2" value={localV2} min={-50} max={50} step={0.5} onChange={setLocalV2} unit="m/s" />
          </div>
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>Calculate</button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button>
          </div>
        </div>
      </WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="momentum" params={{ mass1: m1, velocity1: v1, mass2: m2, velocity2: v2 }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}><span className="opacity-50">Total Momentum:</span><span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${pTotal.toFixed(2)} kg·m/s` : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">v₁ after:</span><span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${v1f.toFixed(3)} m/s` : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">v₂ after:</span><span className="font-bold text-[#E07840]">{(!isPending && realism.isRealistic) ? `${v2f.toFixed(3)} m/s` : "[Missing]"}</span></div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Conservation Check:</span>
            <span className="font-mono text-xs text-[#E8C880] block">p_before = {(!isPending && realism.isRealistic) ? `${m1}×${v1} + ${m2}×${v2} = ${pTotal.toFixed(2)}` : "[Missing]"}</span>
            <span className="font-mono text-xs text-[#88C0B8] block mt-1">p_after = {(!isPending && realism.isRealistic) ? `${m1}×${v1f.toFixed(2)} + ${m2}×${v2f.toFixed(2)} = ${(m1*v1f + m2*v2f).toFixed(2)}` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

// ══════════════════════════════════════════════════
//  4. CIRCULAR MOTION SIMULATOR
// ══════════════════════════════════════════════════
export function CircularMotionSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [mass, setMass] = useState(() => getInitialParam(initialParams, 'mass', 1))
  const [velocity, setVelocity] = useState(() => getInitialParam(initialParams, 'velocity', 5))
  const [radius, setRadius] = useState(() => getInitialParam(initialParams, 'radius', 3))
  const [localMass, setLocalMass] = useState(1); const [localVel, setLocalVel] = useState(5); const [localR, setLocalR] = useState(3)
  useEffect(() => { setLocalMass(mass); setLocalVel(velocity); setLocalR(radius) }, [mass, velocity, radius])

  const animRef = useRef()
  
  const isPending = mass === "" || velocity === "" || radius === "";
  const realism = checkRealism('circular', { mass, velocity, radius })

  const stateRef = useRef({ mass: 1, velocity: 5, radius: 3, angle: 0, isPending: false, isRealistic: true })
  useEffect(() => { Object.assign(stateRef.current, { mass, velocity, radius, isPending, isRealistic: realism.isRealistic }) }, [mass, velocity, radius, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
        const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        if (isPending) {
          ctx.fillText('Awaiting required parameters...', W / 2, H / 2)
        } else {
          ctx.fillText('Simulation Suspended — Invalid Parameters', W / 2, H / 2)
        }
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current
      const omega = s.velocity / s.radius
      s.angle += omega * 0.016
      const cx = W / 2, cy = H / 2
      const rPx = Math.min(120, s.radius * 30)
      const px = cx + rPx * Math.cos(s.angle), py = cy + rPx * Math.sin(s.angle)
      ctx.clearRect(0, 0, W, H)
      // Orbit circle
      ctx.strokeStyle = 'rgba(136,192,184,0.15)'; ctx.lineWidth = 1
      ctx.beginPath(); ctx.arc(cx, cy, rPx, 0, Math.PI * 2); ctx.stroke()
      // Radius line
      ctx.strokeStyle = 'rgba(196,149,106,0.3)'; ctx.lineWidth = 1; ctx.setLineDash([4, 4])
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(px, py); ctx.stroke(); ctx.setLineDash([])
      // Center dot
      ctx.fillStyle = 'rgba(220,200,165,0.3)'; ctx.beginPath(); ctx.arc(cx, cy, 3, 0, Math.PI * 2); ctx.fill()
      // Object
      const objSize = 6 + s.mass * 2
      ctx.fillStyle = '#88C0B8'; ctx.beginPath(); ctx.arc(px, py, objSize, 0, Math.PI * 2); ctx.fill()
      // Centripetal force arrow (toward center)
      const fc = s.mass * s.velocity * s.velocity / s.radius
      const arrowLen = Math.min(60, fc * 3)
      const dx = (cx - px) / rPx, dy = (cy - py) / rPx
      drawArrow(ctx, px, py, px + dx * arrowLen, py + dy * arrowLen, '#E07840', 2, 7)
      // Velocity arrow (tangent)
      const tx = -Math.sin(s.angle), ty = Math.cos(s.angle)
      drawArrow(ctx, px, py, px + tx * 40, py + ty * 40, '#88C0B8', 1.5, 6)
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'; ctx.textAlign = 'left'
      ctx.fillText(`F_c = ${fc.toFixed(2)} N`, 40, 25)
      ctx.fillText(`ω = ${omega.toFixed(2)} rad/s`, 40, 45)
      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const fc = mass * velocity * velocity / radius
  const omega = velocity / radius
  const period = 2 * Math.PI * radius / velocity

  const handleCalc = () => {
    if (localMass === "" || localVel === "" || localR === "") {
      if (localMass === "") setMass("");
      if (localVel === "") setVelocity("");
      if (localR === "") setRadius("");
      return;
    }

    let pm = parseFloat(localMass); if (isNaN(pm)) pm = 1; pm = Math.max(0.1, Math.min(50, pm))
    let pv = parseFloat(localVel); if (isNaN(pv)) pv = 5; pv = Math.max(0.1, Math.min(50, pv))
    let pr = parseFloat(localR); if (isNaN(pr)) pr = 3; pr = Math.max(0.5, Math.min(20, pr))
    setMass(pm); setVelocity(pv); setRadius(pr)
  }
  const handleReset = () => { setMass(1); setVelocity(5); setRadius(3) }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <InputCardField label="Mass" value={localMass} min={0.1} max={50} step={0.1} onChange={setLocalMass} unit="kg" />
            <InputCardField label="Velocity" value={localVel} min={0.1} max={50} step={0.5} onChange={setLocalVel} unit="m/s" />
            <InputCardField label="Radius" value={localR} min={0.5} max={20} step={0.1} onChange={setLocalR} unit="m" />
          </div>
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>Calculate</button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button>
          </div>
        </div>
      </WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="circular" params={{ mass, velocity, radius }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}><span className="opacity-50">Centripetal Force:</span><span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${fc.toFixed(3)} N` : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Angular Velocity:</span><span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${omega.toFixed(3)} rad/s` : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Period:</span><span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${period.toFixed(3)} s` : "[Missing]"}</span></div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">F = mv²/r = {(!isPending && realism.isRealistic) ? `${mass}×${velocity}²/${radius} = ${fc.toFixed(3)} N` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

// ══════════════════════════════════════════════════
//  5. GRAVITATION — VERLET ORBITAL MECHANICS
// ══════════════════════════════════════════════════
export function GravitationSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [planetMass, setPlanetMass] = useState(() => {
    const v = getInitialParam(initialParams, 'mass1', 5.97);
    return v === "" ? "" : (initialParams ? v / 1e24 : v);
  })
  const [satMass, setSatMass] = useState(() => getInitialParam(initialParams, 'mass2', 1))
  const [orbRadius, setOrbRadius] = useState(() => {
    const v = getInitialParam(initialParams, 'distance', 6.37);
    return v === "" ? "" : (initialParams ? v / 1e6 : v);
  })
  const [orbSpeed, setOrbSpeed] = useState(1.0)
  const [localPM, setLocalPM] = useState(5.97); const [localSM, setLocalSM] = useState(1)
  const [localOR, setLocalOR] = useState(6.37); const [localOS, setLocalOS] = useState(1.0)
  useEffect(() => { setLocalPM(planetMass); setLocalSM(satMass); setLocalOR(orbRadius); setLocalOS(orbSpeed) }, [planetMass, satMass, orbRadius, orbSpeed])

  const animRef = useRef()
  const stateRef = useRef(null)
  const isPending = planetMass === "" || satMass === "" || orbRadius === "";
  const realism = checkRealism('gravitation', { planetMass, satMass, orbRadius })

  // Initialize orbital state
  const initOrbit = (pM, r, spdMul) => {
    const G_sim = 800
    const vCircular = Math.sqrt(G_sim * pM / (r * 30))
    return {
      pM, r,
      x: r * 30, y: 0,
      vx: 0, vy: -vCircular * spdMul,
      trail: [], G_sim
    }
  }

  useEffect(() => {
    stateRef.current = initOrbit(planetMass, orbRadius, orbSpeed)
    if (stateRef.current) {
      stateRef.current.isPending = isPending
      stateRef.current.isRealistic = realism.isRealistic
    }
  }, [planetMass, orbRadius, orbSpeed, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 400
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    if (!stateRef.current) stateRef.current = initOrbit(5.97, 6.37, 1.0)

        const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        if (isPending) {
          ctx.fillText('Awaiting required parameters...', W / 2, H / 2)
        } else {
          ctx.fillText('Simulation Suspended — Invalid Parameters', W / 2, H / 2)
        }
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current
      const cx = W / 2, cy = H / 2
      const dt = 0.3

      // Verlet integration
      const dx = s.x, dy = s.y
      const dist = Math.sqrt(dx * dx + dy * dy)
      const clampDist = Math.max(dist, 20)
      const aScale = -s.G_sim * s.pM / (clampDist * clampDist * clampDist)
      const ax = aScale * dx, ay = aScale * dy

      s.vx += ax * dt; s.vy += ay * dt
      s.x += s.vx * dt; s.y += s.vy * dt

      // Clamp to prevent escape
      const newDist = Math.sqrt(s.x * s.x + s.y * s.y)
      if (newDist > 300) {
        s.x *= 300 / newDist; s.y *= 300 / newDist
      }

      // Trail
      s.trail.push({ x: cx + s.x, y: cy + s.y })
      if (s.trail.length > 400) s.trail.shift()

      ctx.clearRect(0, 0, W, H)

      // Field lines
      for (let a = 0; a < Math.PI * 2; a += Math.PI / 8) {
        ctx.strokeStyle = 'rgba(196,149,106,0.06)'; ctx.lineWidth = 1
        ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * 30, cy + Math.sin(a) * 30)
        ctx.lineTo(cx + Math.cos(a) * 250, cy + Math.sin(a) * 250); ctx.stroke()
      }

      // Orbital trail
      if (s.trail.length > 2) {
        for (let i = 1; i < s.trail.length; i++) {
          const alpha = (i / s.trail.length) * 0.4
          ctx.strokeStyle = `rgba(136,192,184,${alpha})`; ctx.lineWidth = 1.5
          ctx.beginPath(); ctx.moveTo(s.trail[i - 1].x, s.trail[i - 1].y)
          ctx.lineTo(s.trail[i].x, s.trail[i].y); ctx.stroke()
        }
      }

      // Planet
      const planetR = 22 + s.pM * 1.5
      const pg = ctx.createRadialGradient(cx - planetR * 0.15, cy - planetR * 0.15, 0, cx, cy, planetR)
      pg.addColorStop(0, '#d4a870'); pg.addColorStop(0.7, '#C4956A'); pg.addColorStop(1, 'rgba(196,149,106,0.3)')
      ctx.fillStyle = pg; ctx.beginPath(); ctx.arc(cx, cy, planetR, 0, Math.PI * 2); ctx.fill()
      // Atmosphere glow
      ctx.fillStyle = 'rgba(196,149,106,0.08)'; ctx.beginPath(); ctx.arc(cx, cy, planetR + 12, 0, Math.PI * 2); ctx.fill()

      // Satellite
      const satX = cx + s.x, satY = cy + s.y
      const satR = 5
      ctx.fillStyle = '#88C0B8'; ctx.beginPath(); ctx.arc(satX, satY, satR, 0, Math.PI * 2); ctx.fill()
      ctx.fillStyle = 'rgba(136,192,184,0.2)'; ctx.beginPath(); ctx.arc(satX, satY, satR + 6, 0, Math.PI * 2); ctx.fill()

      // Gravity force vector (toward planet)
      const fDist = Math.sqrt((satX - cx) ** 2 + (satY - cy) ** 2)
      if (fDist > 30) {
        const fnx = (cx - satX) / fDist, fny = (cy - satY) / fDist
        const fLen = Math.min(40, 800 / fDist)
        drawArrow(ctx, satX, satY, satX + fnx * fLen, satY + fny * fLen, '#E07840', 2, 6)
      }

      // Velocity vector (tangent)
      const vMag = Math.sqrt(s.vx * s.vx + s.vy * s.vy)
      if (vMag > 0.5) {
        const vScale = 15
        drawArrow(ctx, satX, satY, satX + s.vx * vScale, satY + s.vy * vScale, '#88C0B8', 1.5, 5)
      }

      // Info
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'; ctx.textAlign = 'left'
      const G = 6.674e-11
      const F = G * planetMass * 1e24 * satMass / Math.pow(orbRadius * 1e6, 2)
      ctx.fillText(`F = ${F.toExponential(3)} N`, 40, 25)
      ctx.fillText(`Orbit ≈ ${(newDist / 30 * orbRadius).toFixed(1)} ×10⁶ m`, 40, 45)

      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const G = 6.674e-11, F = G * planetMass * 1e24 * satMass / Math.pow(orbRadius * 1e6, 2)
  const vOrb = Math.sqrt(G * planetMass * 1e24 / (orbRadius * 1e6))
  const T = 2 * Math.PI * orbRadius * 1e6 / vOrb
  const vEsc = vOrb * Math.sqrt(2)

  const handleCalc = () => {
    if (localPM === "" || localSM === "" || localOR === "") {
      if (localPM === "") setPlanetMass("");
      if (localSM === "") setSatMass("");
      if (localOR === "") setOrbRadius("");
      return;
    }

    let pm = parseFloat(localPM); if (isNaN(pm)) pm = 5.97; pm = Math.max(0.01, Math.min(100, pm))
    let sm = parseFloat(localSM); if (isNaN(sm)) sm = 1; sm = Math.max(0.01, Math.min(100, sm))
    let or_ = parseFloat(localOR); if (isNaN(or_)) or_ = 6.37; or_ = Math.max(0.1, Math.min(50, or_))
    let os = parseFloat(localOS); if (isNaN(os)) os = 1.0; os = Math.max(0.3, Math.min(2.5, os))
    setPlanetMass(pm); setSatMass(sm); setOrbRadius(or_); setOrbSpeed(os)
  }
  const handleReset = () => { setPlanetMass(5.97); setSatMass(1); setOrbRadius(6.37); setOrbSpeed(1.0) }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(196,149,106,0.1)' }} />
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <InputCardField label="Planet Mass (×10²⁴)" value={localPM} min={0.01} max={100} step={0.01} onChange={setLocalPM} unit="kg" />
            <InputCardField label="Satellite Mass" value={localSM} min={0.01} max={100} step={0.1} onChange={setLocalSM} unit="kg" />
            <InputCardField label="Orbit Radius (×10⁶)" value={localOR} min={0.1} max={50} step={0.1} onChange={setLocalOR} unit="m" />
            <InputCardField label="Speed Factor" value={localOS} min={0.3} max={2.5} step={0.1} onChange={setLocalOS} />
          </div>
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#C4956A', color: '#141210' }}>Calculate</button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button>
          </div>
        </div>
      </WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="gravitation" params={{ planetMass, satMass, orbRadius }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}><span className="opacity-50">Gravitational Force:</span><span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${F.toExponential(4)} N` : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Orbital Velocity:</span><span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${vOrb.toFixed(0)} m/s` : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Orbital Period:</span><span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${(T / 3600).toFixed(1)} hours` : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Escape Velocity:</span><span className="font-bold text-[#E07840]">{(!isPending && realism.isRealistic) ? `${vEsc.toFixed(0)} m/s` : "[Missing]"}</span></div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula:</span>
            <span className="font-mono text-xs text-[#E8C880]">F = G·m₁·m₂/r² = {(!isPending && realism.isRealistic) ? `${F.toExponential(4)} N` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

// ══════════════════════════════════════════════════
//  6. BERNOULLI EQUATION SIMULATOR
// ══════════════════════════════════════════════════
export function BernoulliSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [v1, setV1] = useState(() => getInitialParam(initialParams, 'velocity1', 2))
  const [p1, setP1] = useState(() => getInitialParam(initialParams, 'pressure1', 101325))
  const [h1, setH1] = useState(0); const [areaRatio, setAreaRatio] = useState(0.5)
  const [localV1, setLocalV1] = useState(2); const [localP1, setLocalP1] = useState(101325)
  const [localH1, setLocalH1] = useState(0); const [localAR, setLocalAR] = useState(0.5)
  useEffect(() => { setLocalV1(v1); setLocalP1(p1); setLocalH1(h1); setLocalAR(areaRatio) }, [v1, p1, h1, areaRatio])
  const animRef = useRef()
  
  const isPending = v1 === "" || p1 === "";
  const realism = checkRealism('bernoulli', isPending ? {} : { velocity1: v1, pressure1: p1, areaRatio })

  const stateRef = useRef({ v1: 2, p1: 101325, h1: 0, areaRatio: 0.5, t: 0, isPending: false, isRealistic: true })
  useEffect(() => { Object.assign(stateRef.current, { v1, p1, h1, areaRatio, isPending, isRealistic: realism.isRealistic }) }, [v1, p1, h1, areaRatio, isPending, realism.isRealistic])
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d'); const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr; canvas.style.width = '100%'; canvas.style.height = `${H}px`; ctx.scale(dpr, dpr)
        const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current; s.t += 0.016; const cy = H / 2; ctx.clearRect(0, 0, W, H)
      const pipeH1 = 80, pipeH2 = pipeH1 * s.areaRatio, narrowStart = W * 0.4, narrowEnd = W * 0.65
      ctx.fillStyle = 'rgba(136,192,184,0.06)'; ctx.beginPath()
      ctx.moveTo(60, cy - pipeH1 / 2); ctx.lineTo(narrowStart, cy - pipeH1 / 2)
      ctx.lineTo(narrowStart + 40, cy - pipeH2 / 2); ctx.lineTo(narrowEnd, cy - pipeH2 / 2)
      ctx.lineTo(narrowEnd + 40, cy - pipeH1 / 2); ctx.lineTo(W - 60, cy - pipeH1 / 2)
      ctx.lineTo(W - 60, cy + pipeH1 / 2); ctx.lineTo(narrowEnd + 40, cy + pipeH1 / 2)
      ctx.lineTo(narrowEnd, cy + pipeH2 / 2); ctx.lineTo(narrowStart + 40, cy + pipeH2 / 2)
      ctx.lineTo(narrowStart, cy + pipeH1 / 2); ctx.lineTo(60, cy + pipeH1 / 2)
      ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(136,192,184,0.25)'; ctx.lineWidth = 1; ctx.stroke()
      for (let i = 0; i < 20; i++) {
        const baseX = (60 + (s.t * 80 + i * 55) % (W - 120)); let y = cy + (Math.sin(i * 1.5) * pipeH1 * 0.3); let speed = 1
        if (baseX > narrowStart && baseX < narrowEnd + 40) { y = cy + (Math.sin(i * 1.5) * pipeH2 * 0.3); speed = 1 / s.areaRatio }
        ctx.fillStyle = `rgba(136,192,184,${0.15 + speed * 0.1})`; ctx.beginPath(); ctx.arc(baseX, y, 2 + speed, 0, Math.PI * 2); ctx.fill()
      }
      const v2 = s.v1 / s.areaRatio; ctx.fillStyle = 'rgba(220,200,165,0.6)'; ctx.font = '11px var(--font-body)'
      ctx.fillText(`v₁ = ${s.v1.toFixed(1)} m/s`, 80, cy - pipeH1 / 2 - 15)
      ctx.fillText(`v₂ = ${v2.toFixed(1)} m/s`, narrowStart + 50, cy - pipeH2 / 2 - 15)
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'
      const rho = 1000, p2 = s.p1 + 0.5 * rho * (s.v1 * s.v1 - v2 * v2)
      ctx.fillText(`P₁ = ${(s.p1 / 1000).toFixed(1)} kPa  →  P₂ = ${(p2 / 1000).toFixed(1)} kPa`, 40, 25)
      animRef.current = requestAnimationFrame(draw)
    }; draw(); return () => cancelAnimationFrame(animRef.current)
  }, [])
  const rho = 1000; const v2 = v1 / areaRatio; const p2 = p1 + 0.5 * rho * (v1 * v1 - v2 * v2)
  const handleCalc = () => {
    if (localV1 === "" || localP1 === "") {
      if (localV1 === "") setV1("");
      if (localP1 === "") setP1("");
      return;
    }
    let pv = parseFloat(localV1); if (isNaN(pv)) pv = 2; pv = Math.max(0.1, Math.min(50, pv)); let pp = parseFloat(localP1); if (isNaN(pp)) pp = 101325; pp = Math.max(1000, Math.min(500000, pp)); let ph = parseFloat(localH1); if (isNaN(ph)) ph = 0; ph = Math.max(0, Math.min(100, ph)); let pa = parseFloat(localAR); if (isNaN(pa)) pa = 0.5; pa = Math.max(0.1, Math.min(1, pa)); setV1(pv); setP1(pp); setH1(ph); setAreaRatio(pa) }
  const handleReset = () => { setV1(2); setP1(101325); setH1(0); setAreaRatio(0.5) }
  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      <WorkspacePortal target="inputs"><div className="flex flex-col gap-4 w-full"><div className="grid grid-cols-2 sm:grid-cols-4 gap-4"><InputCardField label="Velocity" value={localV1} min={0.1} max={50} step={0.1} onChange={setLocalV1} unit="m/s" /><InputCardField label="Pressure" value={localP1} min={1000} max={500000} step={1000} onChange={setLocalP1} unit="Pa" /><InputCardField label="Height" value={localH1} min={0} max={100} step={0.5} onChange={setLocalH1} unit="m" /><InputCardField label="Area Ratio" value={localAR} min={0.1} max={1} step={0.05} onChange={setLocalAR} /></div><div className="flex gap-4 mt-2 w-full"><button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>Calculate</button><button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button></div></div></WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="bernoulli" params={{ velocity1: v1, pressure1: p1, areaRatio }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Velocity at narrow (v₂):</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${v2.toFixed(2)} m/s` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}>
            <span className="opacity-50">Pressure at narrow (P₂):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${(p2/1000).toFixed(2)} kPa` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Pressure Drop:</span>
            <span className="font-bold text-[#E07840]">{(!isPending && realism.isRealistic) ? `${((p1 - p2)/1000).toFixed(2)} kPa` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula:</span>
            <span className="font-mono text-xs text-[#E8C880]">P₂ = P₁ + ½ρ(v₁²−v₂²) = {(!isPending && realism.isRealistic) ? `${(p2/1000).toFixed(2)} kPa` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

// ══════════════════════════════════════════════════
//  7. REYNOLDS NUMBER SIMULATOR
// ══════════════════════════════════════════════════
export function ReynoldsSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [velocity, setVelocity] = useState(() => getInitialParam(initialParams, 'velocity', 1))
  const [charLen, setCharLen] = useState(() => getInitialParam(initialParams, 'length', 0.1))
  const [viscosity, setViscosity] = useState(() => getInitialParam(initialParams, 'viscosity', 1e-3))
  const [density, setDensity] = useState(() => getInitialParam(initialParams, 'density', 1000))
  const [localV, setLocalV] = useState(1); const [localL, setLocalL] = useState(0.1)
  const [localMu, setLocalMu] = useState(1e-3); const [localRho, setLocalRho] = useState(1000)
  useEffect(() => { setLocalV(velocity); setLocalL(charLen); setLocalMu(viscosity); setLocalRho(density) }, [velocity, charLen, viscosity, density])
  const animRef = useRef()
  
  const isPending = velocity === "" || charLen === "" || viscosity === "" || density === "";
  const realism = checkRealism('reynolds', isPending ? {} : { density, velocity, charLen: charLen, viscosity })

  const stateRef = useRef({ v: 1, L: 0.1, mu: 1e-3, rho: 1000, t: 0, isPending: false, isRealistic: true })
  useEffect(() => { Object.assign(stateRef.current, { v: velocity, L: charLen, mu: viscosity, rho: density, isPending, isRealistic: realism.isRealistic }) }, [velocity, charLen, viscosity, density, isPending, realism.isRealistic])
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d'); const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340; canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`; ctx.scale(dpr, dpr)
        const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current; s.t += 0.016; const Re = s.rho * s.v * s.L / s.mu; const isTurbulent = Re > 2300
      ctx.clearRect(0, 0, W, H); const numLines = 12, cy = H / 2
      for (let i = 0; i < numLines; i++) {
        const baseY = cy - 100 + i * (200 / numLines)
        ctx.strokeStyle = isTurbulent ? `rgba(224,120,64,${0.15 + Math.random() * 0.1})` : 'rgba(136,192,184,0.2)'
        ctx.lineWidth = 1.5; ctx.beginPath()
        for (let x = 40; x < W - 40; x += 3) {
          const turbulence = isTurbulent ? Math.sin(x * 0.05 + s.t * 3 + i) * (10 + Re * 0.002) : 0
          const y = baseY + turbulence; x === 40 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)
        }; ctx.stroke()
      }
      ctx.fillStyle = 'rgba(220,200,165,0.6)'; ctx.font = '13px var(--font-body)'
      ctx.fillText(`Re = ${Re.toFixed(0)}`, W / 2 - 40, 30)
      ctx.fillText(isTurbulent ? 'TURBULENT FLOW' : 'LAMINAR FLOW', W / 2 - 55, 55)
      animRef.current = requestAnimationFrame(draw)
    }; draw(); return () => cancelAnimationFrame(animRef.current)
  }, [])
  const Re = density * velocity * charLen / viscosity; const regime = Re > 4000 ? 'Turbulent' : Re > 2300 ? 'Transitional' : 'Laminar'
  const handleCalc = () => {
    if (localV === "" || localL === "" || localMu === "" || localRho === "") {
      if (localV === "") setVelocity("");
      if (localL === "") setCharLen("");
      if (localMu === "") setViscosity("");
      if (localRho === "") setDensity("");
      return;
    }
    let pv = parseFloat(localV); if (isNaN(pv)) pv = 1; pv = Math.max(0.01, Math.min(50, pv)); let pl = parseFloat(localL); if (isNaN(pl)) pl = 0.1; pl = Math.max(0.001, Math.min(10, pl)); let pm = parseFloat(localMu); if (isNaN(pm)) pm = 1e-3; pm = Math.max(1e-6, Math.min(1, pm)); let pr = parseFloat(localRho); if (isNaN(pr)) pr = 1000; pr = Math.max(1, Math.min(13600, pr)); setVelocity(pv); setCharLen(pl); setViscosity(pm); setDensity(pr) }
  const handleReset = () => { setVelocity(1); setCharLen(0.1); setViscosity(1e-3); setDensity(1000) }
  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      <WorkspacePortal target="inputs"><div className="flex flex-col gap-4 w-full"><div className="grid grid-cols-2 sm:grid-cols-4 gap-4"><InputCardField label="Velocity" value={localV} min={0.01} max={50} step={0.1} onChange={setLocalV} unit="m/s" /><InputCardField label="Char. Length" value={localL} min={0.001} max={10} step={0.01} onChange={setLocalL} unit="m" /><InputCardField label="Viscosity" value={localMu} min={0.000001} max={1} step={0.0001} onChange={setLocalMu} unit="Pa·s" /><InputCardField label="Density" value={localRho} min={1} max={13600} step={10} onChange={setLocalRho} unit="kg/m³" /></div><div className="flex gap-4 mt-2 w-full"><button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>Calculate</button><button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button></div></div></WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="reynolds" params={{ density, velocity, charLen, viscosity }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}<div className="flex flex-col gap-5 font-mono text-xs w-full"><div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}><span className="opacity-50">Reynolds Number:</span><span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? Re.toFixed(0) : "[Missing]"}</span></div><div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Flow Regime:</span><span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? regime : "[Missing]"}</span></div><div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}><span className="opacity-40 block mb-1">Formula:</span><span className="font-mono text-xs text-[#E8C880]">Re = ρvL/μ = {(!isPending && realism.isRealistic) ? `${density}×${velocity}×${charLen}/${viscosity} = ${Re.toFixed(0)}` : "[Missing]"}</span></div></div></WorkspacePortal>
    </div>
  )
}

// ══════════════════════════════════════════════════
//  8. COULOMB'S LAW — FIELD LINES + TEST PARTICLE
// ══════════════════════════════════════════════════
export function CoulombSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [q1, setQ1] = useState(() => {
    const v = getInitialParam(initialParams, 'charge1', 1);
    return v === "" ? "" : (initialParams ? v / 1e-6 : v);
  })
  const [q2, setQ2] = useState(() => {
    const v = getInitialParam(initialParams, 'charge2', -1);
    return v === "" ? "" : (initialParams ? v / 1e-6 : v);
  })
  const [dist, setDist] = useState(() => getInitialParam(initialParams, 'distance', 0.5))
  const [localQ1, setLocalQ1] = useState(1); const [localQ2, setLocalQ2] = useState(-1); const [localD, setLocalD] = useState(0.5)
  useEffect(() => { setLocalQ1(q1); setLocalQ2(q2); setLocalD(dist) }, [q1, q2, dist])
  const animRef = useRef()
  
  const isPending = q1 === "" || q2 === "" || dist === "";
  const realism = checkRealism('coulomb', isPending ? {} : { charge1: q1, charge2: q2, distance: dist })

  const stateRef = useRef({ q1: 1, q2: -1, dist: 0.5, t: 0, testParticles: [], isPending: false, isRealistic: true })
  useEffect(() => { Object.assign(stateRef.current, { q1, q2, dist, testParticles: [], isPending, isRealistic: realism.isRealistic }) }, [q1, q2, dist, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d'); const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 400; canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`; ctx.scale(dpr, dpr)

        const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current; s.t += 0.016
      const cx = W / 2, cy = H / 2
      const sep = Math.max(100, s.dist * 250)
      const x1 = cx - sep / 2, x2 = cx + sep / 2
      const isAttractive = s.q1 * s.q2 < 0

      ctx.clearRect(0, 0, W, H)

      // Electric field lines
      const numLines = 12
      for (let i = 0; i < numLines; i++) {
        const a = (i / numLines) * Math.PI * 2
        ctx.strokeStyle = s.q1 > 0 ? 'rgba(224,120,64,0.15)' : 'rgba(160,156,200,0.15)'
        ctx.lineWidth = 1

        // Trace field line from charge 1
        ctx.beginPath()
        let lx = x1 + Math.cos(a) * 22, ly = cy + Math.sin(a) * 22
        ctx.moveTo(lx, ly)
        for (let step = 0; step < 80; step++) {
          // Electric field from both charges at (lx, ly)
          const dx1 = lx - x1, dy1 = ly - cy, r1 = Math.sqrt(dx1 * dx1 + dy1 * dy1) + 1
          const dx2 = lx - x2, dy2 = ly - cy, r2 = Math.sqrt(dx2 * dx2 + dy2 * dy2) + 1
          let Ex = s.q1 * dx1 / (r1 * r1 * r1) + s.q2 * dx2 / (r2 * r2 * r2)
          let Ey = s.q1 * dy1 / (r1 * r1 * r1) + s.q2 * dy2 / (r2 * r2 * r2)
          const Em = Math.sqrt(Ex * Ex + Ey * Ey) + 0.001
          const stepSize = 5
          lx += (Ex / Em) * stepSize; ly += (Ey / Em) * stepSize
          ctx.lineTo(lx, ly)
          if (lx < 20 || lx > W - 20 || ly < 10 || ly > H - 10) break
          // Stop if we reach charge 2 (for attractive)
          const d2 = Math.sqrt((lx - x2) ** 2 + (ly - cy) ** 2)
          if (d2 < 22) break
        }
        ctx.stroke()
      }

      // Test particles moving along field
      if (s.testParticles.length < 6) {
        for (let i = 0; i < 6; i++) {
          const a = (i / 6) * Math.PI * 2
          s.testParticles.push({ x: x1 + Math.cos(a) * 25, y: cy + Math.sin(a) * 25, age: i * 30 })
        }
      }
      for (const tp of s.testParticles) {
        tp.age++
        const dx1 = tp.x - x1, dy1 = tp.y - cy, r1 = Math.sqrt(dx1 * dx1 + dy1 * dy1) + 1
        const dx2 = tp.x - x2, dy2 = tp.y - cy, r2 = Math.sqrt(dx2 * dx2 + dy2 * dy2) + 1
        let Ex = s.q1 * dx1 / (r1 * r1 * r1) + s.q2 * dx2 / (r2 * r2 * r2)
        let Ey = s.q1 * dy1 / (r1 * r1 * r1) + s.q2 * dy2 / (r2 * r2 * r2)
        const Em = Math.sqrt(Ex * Ex + Ey * Ey) + 0.001
        tp.x += (Ex / Em) * 1.5; tp.y += (Ey / Em) * 1.5
        const alpha = Math.max(0, 1 - tp.age / 200)
        ctx.fillStyle = `rgba(232,200,128,${alpha * 0.6})`
        ctx.beginPath(); ctx.arc(tp.x, tp.y, 2.5, 0, Math.PI * 2); ctx.fill()
        if (tp.x < 10 || tp.x > W - 10 || tp.y < 5 || tp.y > H - 5 || tp.age > 200 || r2 < 22) {
          const a = Math.random() * Math.PI * 2
          tp.x = x1 + Math.cos(a) * 25; tp.y = cy + Math.sin(a) * 25; tp.age = 0
        }
      }

      // Charge 1 glow
      ctx.fillStyle = s.q1 > 0 ? 'rgba(224,120,64,0.08)' : 'rgba(160,156,200,0.08)'
      ctx.beginPath(); ctx.arc(x1, cy, 35, 0, Math.PI * 2); ctx.fill()
      // Charge 1
      ctx.fillStyle = s.q1 > 0 ? '#E07840' : '#A09CC8'
      ctx.beginPath(); ctx.arc(x1, cy, 20, 0, Math.PI * 2); ctx.fill()
      ctx.fillStyle = '#141210'; ctx.font = 'bold 18px var(--font-body)'; ctx.textAlign = 'center'
      ctx.fillText(s.q1 > 0 ? '+' : '−', x1, cy + 7)

      // Charge 2 glow
      ctx.fillStyle = s.q2 > 0 ? 'rgba(224,120,64,0.08)' : 'rgba(160,156,200,0.08)'
      ctx.beginPath(); ctx.arc(x2, cy, 35, 0, Math.PI * 2); ctx.fill()
      // Charge 2
      ctx.fillStyle = s.q2 > 0 ? '#E07840' : '#A09CC8'
      ctx.beginPath(); ctx.arc(x2, cy, 20, 0, Math.PI * 2); ctx.fill()
      ctx.fillStyle = '#141210'; ctx.fillText(s.q2 > 0 ? '+' : '−', x2, cy + 7)

      // Force arrows
      const k = 8.988e9, F = k * Math.abs(s.q1 * 1e-6) * Math.abs(s.q2 * 1e-6) / (s.dist * s.dist)
      const arrowLen = Math.min(60, Math.log10(F + 1) * 12 + 25)
      const dir = isAttractive ? 1 : -1
      drawArrow(ctx, x1 + 22, cy, x1 + 22 + dir * arrowLen, cy, '#C4956A', 2.5, 7)
      drawArrow(ctx, x2 - 22, cy, x2 - 22 - dir * arrowLen, cy, '#C4956A', 2.5, 7)

      // Labels
      ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(220,200,165,0.6)'; ctx.font = '12px var(--font-body)'
      ctx.fillText(`F = ${F.toFixed(4)} N  (${isAttractive ? 'Attractive' : 'Repulsive'})`, 40, 25)
      ctx.fillText(`q₁ = ${s.q1 > 0 ? '+' : ''}${s.q1} μC    q₂ = ${s.q2 > 0 ? '+' : ''}${s.q2} μC`, 40, 45)

      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const k = 8.988e9, F = k * Math.abs(q1 * 1e-6) * Math.abs(q2 * 1e-6) / (dist * dist)
  const isAttractive = q1 * q2 < 0

  const handleCalc = () => {
    if (localQ1 === "" || localQ2 === "" || localD === "") {
      if (localQ1 === "") setQ1("");
      if (localQ2 === "") setQ2("");
      if (localD === "") setDist("");
      return;
    }

    let pq1 = parseFloat(localQ1); if (isNaN(pq1)) pq1 = 1; pq1 = Math.max(-100, Math.min(100, pq1))
    let pq2 = parseFloat(localQ2); if (isNaN(pq2)) pq2 = -1; pq2 = Math.max(-100, Math.min(100, pq2))
    let pd = parseFloat(localD); if (isNaN(pd)) pd = 0.5; pd = Math.max(1e-9, Math.min(10, pd))
    setQ1(pq1); setQ2(pq2); setDist(pd)
  }
  const handleReset = () => { setQ1(1); setQ2(-1); setDist(0.5) }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(160,156,200,0.1)' }} />
      <WorkspacePortal target="inputs"><div className="flex flex-col gap-4 w-full"><div className="grid grid-cols-1 sm:grid-cols-3 gap-4"><InputCardField label="Charge 1" value={localQ1} min={-100} max={100} step={0.1} onChange={setLocalQ1} unit="μC" /><InputCardField label="Charge 2" value={localQ2} min={-100} max={100} step={0.1} onChange={setLocalQ2} unit="μC" /><InputCardField label="Distance" value={localD} min={1e-8} max={10} step={1e-7} onChange={setLocalD} unit="m" /></div><div className="flex gap-4 mt-2 w-full"><button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#A09CC8', color: '#141210' }}>Calculate</button><button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button></div></div></WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="coulomb" params={{ charge1: q1, charge2: q2, distance: dist }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}>
            <span className="opacity-50">Electrostatic Force:</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${F.toFixed(4)} N` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Type:</span>
            <span className="font-bold text-[#A09CC8]">{(!isPending && realism.isRealistic) ? (isAttractive ? 'Attractive' : 'Repulsive') : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Electric Field at midpoint:</span>
            <span className="font-bold text-[#88C0B8]">
              {(!isPending && realism.isRealistic) ? `${(k * Math.abs(q1*1e-6) / ((dist/2)**2) + k * Math.abs(q2*1e-6) / ((dist/2)**2)).toExponential(2)} N/C` : "[Missing]"}
            </span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              {(!isPending && realism.isRealistic) ? `F = k|q₁||q₂|/r² = 8.99e9 × ${Math.abs(q1)}μC × ${Math.abs(q2)}μC / ${dist}² = ${F.toFixed(4)} N` : "[Missing]"}
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

// ══════════════════════════════════════════════════
//  9. LORENTZ FORCE — CLEAN CIRCULAR ORBIT
// ══════════════════════════════════════════════════
export function LorentzForceSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [charge, setCharge] = useState(() => getInitialParam(initialParams, 'charge', 1.60218e-19))
  const [vel, setVel] = useState(() => getInitialParam(initialParams, 'velocity', 1e6))
  const [bField, setBField] = useState(() => getInitialParam(initialParams, 'magneticField', 0.5))
  const [mass, setMass] = useState(() => getInitialParam(initialParams, 'mass', 9.10938e-31))

  const [localQ, setLocalQ] = useState(() => charge === "" ? "" : String(charge))
  const [localV, setLocalV] = useState(() => vel === "" ? "" : String(vel))
  const [localB, setLocalB] = useState(() => bField === "" ? "" : String(bField))
  const [localM, setLocalM] = useState(() => mass === "" ? "" : String(mass))

  const [isPlaying, setIsPlaying] = useState(true)

  useEffect(() => {
    setLocalQ(charge === "" ? "" : String(charge))
    setLocalV(vel === "" ? "" : String(vel))
    setLocalB(bField === "" ? "" : String(bField))
    setLocalM(mass === "" ? "" : String(mass))
  }, [charge, vel, bField, mass])

  const animRef = useRef()
  const isPending = charge === "" || vel === "" || bField === "" || mass === ""
  const realism = checkRealism('lorentzforce', isPending ? {} : { charge, velocity: vel, magneticField: bField, mass })

  const stateRef = useRef({ q: 1.6e-19, v: 1e6, B: 0.5, mass: 9.1e-31, angle: 0, driftX: 50, trail: [], isPlaying: true, isPending: false, stepOnce: false, isRealistic: true })
  useEffect(() => {
    Object.assign(stateRef.current, {
      q: charge === "" ? 0 : Number(charge),
      v: vel === "" ? 0 : Number(vel),
      B: bField === "" ? 0 : Number(bField),
      mass: mass === "" ? 0 : Number(mass),
      isPending,
      isPlaying,
      isRealistic: realism.isRealistic
    })
  }, [charge, vel, bField, mass, isPending, isPlaying, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d'); const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 400; canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`; ctx.scale(dpr, dpr)

    const draw = () => {
      const s = stateRef.current
      if (s.isPending || !s.isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(s.isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        return
      }

      const qAbs = Math.abs(s.q)
      const r = (qAbs > 0 && s.B > 0) ? (s.mass * s.v) / (qAbs * s.B) : 0
      const cyclotronFreq = (s.mass > 0) ? (qAbs * s.B) / s.mass : 0

      // Animation parameters
      const omega = (s.mass > 0) ? (s.q * s.B) / s.mass : 0
      // Scale omega to be visible and stable
      const omegaAnim = Math.sign(omega) * Math.min(0.25, Math.max(0.01, (Math.abs(omega) / 8.794e10) * 0.08))
      
      // Parallel drift velocity (along horizontal X axis representing magnetic field direction)
      const v_parallel = s.v * Math.cos(Math.PI / 6) // assume 30 deg launch angle for helix
      const driftSpeed = Math.min(6.0, Math.max(0.3, (v_parallel / 8.66e5) * 1.5))

      if (s.isPlaying || s.stepOnce) {
        s.angle += omegaAnim
        s.driftX += driftSpeed
        if (s.driftX > W - 100) {
          s.driftX = 50
          s.trail = []
        }
        s.stepOnce = false
      }

      // Projection parameters
      const rPx = r === 0 ? 0 : Math.min(180, Math.max(15, (r / 1.137e-5) * 60)) // scale micro-meters to screen pixels
      const cx = s.driftX
      const cy = H / 2

      // Helical coordinates (X drift, Y-Z rotation)
      const pz = rPx * Math.sin(s.angle) // Depth
      const px = cx + pz * 0.35 // 3D projection skew
      const py = cy + rPx * Math.cos(s.angle)

      // Trail
      if (s.isPlaying) {
        s.trail.push({ x: px, y: py, z: pz })
        if (s.trail.length > 180) s.trail.shift()
      }

      ctx.clearRect(0, 0, W, H)

      // Background magnetic field lines (pointing right horizontally)
      ctx.strokeStyle = 'rgba(160,156,200,0.05)'; ctx.lineWidth = 1
      for (let y = 50; y < H - 20; y += 40) {
        ctx.beginPath(); ctx.moveTo(40, y); ctx.lineTo(W - 40, y); ctx.stroke()
        // Draw small arrows on B field lines
        for (let ax = 100; ax < W - 100; ax += 150) {
          ctx.fillStyle = 'rgba(160,156,200,0.08)'
          ctx.beginPath(); ctx.moveTo(ax, y); ctx.lineTo(ax - 6, y - 4); ctx.lineTo(ax - 6, y + 4); ctx.fill()
        }
      }

      // Orbit guide (dashed circle matching depth projection)
      ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1; ctx.setLineDash([3, 5])
      ctx.beginPath(); ctx.arc(cx, cy, rPx, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([])

      // Draw trail with depth-based opacity and thickness
      if (s.trail.length > 1) {
        for (let i = 1; i < s.trail.length; i++) {
          const pt1 = s.trail[i - 1]
          const pt2 = s.trail[i]
          const depthAlpha = 0.15 + ((pt2.z + rPx) / (Math.max(1, 2 * rPx))) * 0.45
          const alpha = (i / s.trail.length) * depthAlpha
          ctx.strokeStyle = `rgba(136,192,184,${alpha})`
          ctx.lineWidth = 1 + ((pt2.z + rPx) / (Math.max(1, 2 * rPx))) * 2.5
          ctx.beginPath(); ctx.moveTo(pt1.x, pt1.y); ctx.lineTo(pt2.x, pt2.y); ctx.stroke()
        }
      }

      // Draw particle with 3D depth-based scaling and shading
      const depthScale = 0.65 + ((pz + rPx) / (Math.max(1, 2 * rPx))) * 0.7 // scale radius from 0.65x to 1.35x
      const ballR = 6 * depthScale
      
      // Particle glow
      ctx.fillStyle = `rgba(136,192,184,${0.08 + ((pz + rPx) / (Math.max(1, 2 * rPx))) * 0.12})`
      ctx.beginPath(); ctx.arc(px, py, ballR * 2.5, 0, Math.PI * 2); ctx.fill()
      
      // Shaded particle
      const pg = ctx.createRadialGradient(px - ballR * 0.2, py - ballR * 0.2, 0, px, py, ballR)
      pg.addColorStop(0, '#a8ddd6'); pg.addColorStop(1, '#52827a')
      ctx.fillStyle = pg; ctx.beginPath(); ctx.arc(px, py, ballR, 0, Math.PI * 2); ctx.fill()

      // Charge sign inside particle
      ctx.fillStyle = 'rgba(20,18,16,0.8)'; ctx.font = `bold ${Math.max(7, Math.floor(9 * depthScale))}px var(--font-mono)`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
      ctx.fillText(s.q > 0 ? '+' : '−', px, py)

      // Lorentz force vector (radially inward towards rotation center)
      const fdx = cx - px, fdy = cy - py
      const fd = Math.sqrt(fdx * fdx + fdy * fdy) || 1
      const forceColor = 'rgba(224,120,64,0.7)'
      drawArrow(ctx, px, py, px + (fdx / fd) * 35 * depthScale, py + (fdy / fd) * 35 * depthScale, forceColor, 1.8, 5)

      // Velocity component vector (tangent to helix)
      const tx = -Math.sin(s.angle) * (s.q > 0 ? 1 : -1) * 0.35 + driftSpeed
      const ty = Math.cos(s.angle) * (s.q > 0 ? 1 : -1)
      const td = Math.sqrt(tx * tx + ty * ty) || 1
      const velColor = 'rgba(136,192,184,0.8)'
      drawArrow(ctx, px, py, px + (tx / td) * 35 * depthScale, py + (ty / td) * 35 * depthScale, velColor, 1.8, 5)

      // Labels and readouts
      ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'
      ctx.fillText(`r = ${r.toExponential(4)} m`, 40, 25)
      ctx.fillText(`T_c = ${(Math.abs(omega) > 0 ? (2 * Math.PI / Math.abs(omega)) : 0).toExponential(4)} s`, 40, 45)
      ctx.fillText('B ➔ (horizontal field)', W - 190, 25)

      // Legend
      ctx.fillStyle = '#88C0B8'; ctx.fillRect(W - 190, 38, 8, 8)
      ctx.fillStyle = 'rgba(220,200,165,0.4)'; ctx.font = '10px var(--font-body)'; ctx.fillText('Velocity (v)', W - 178, 46)
      ctx.fillStyle = '#E07840'; ctx.fillRect(W - 190, 52, 8, 8)
      ctx.fillStyle = 'rgba(220,200,165,0.4)'; ctx.fillText('Force (F_Lorentz)', W - 178, 60)
    }

    const intervalId = setInterval(draw, 16)
    return () => clearInterval(intervalId)
  }, [])

  const F = Math.abs(charge) * vel * bField
  const r = (mass > 0 && Math.abs(charge) > 0 && bField > 0) ? (mass * vel) / (Math.abs(charge) * bField) : 0
  const cyclotronFreq = (mass > 0) ? (Math.abs(charge) * bField) / mass : 0

  const handleCalc = () => {
    if (localQ === "" || localV === "" || localB === "" || localM === "") {
      if (localQ === "") setCharge("");
      if (localV === "") setVel("");
      if (localB === "") setBField("");
      if (localM === "") setMass("");
      return;
    }

    let pq = parseFloat(localQ); if (isNaN(pq)) pq = 1.6e-19
    let pv = parseFloat(localV); if (isNaN(pv)) pv = 1e6; pv = Math.max(1, Math.min(1e9, pv))
    let pb = parseFloat(localB); if (isNaN(pb)) pb = 0.5; pb = Math.max(0.001, Math.min(100, pb))
    let pm = parseFloat(localM); if (isNaN(pm)) pm = 9.1e-31; pm = Math.max(1e-35, Math.min(1, pm))
    setCharge(pq); setVel(pv); setBField(pb); setMass(pm)
  }
  const handleReset = () => {
    setCharge(1.60218e-19)
    setVel(1e6)
    setBField(0.5)
    setMass(9.10938e-31)
    setIsPlaying(true)
    Object.assign(stateRef.current, { angle: 0, driftX: 50, trail: [] })
  }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(160,156,200,0.1)' }} />
      
      {/* Simulation Controls */}
      <div className="flex gap-2.5 mt-3 mb-4 font-mono text-[11px] uppercase tracking-wider">
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="px-4 py-1.5 rounded-lg border border-[rgba(196,149,106,0.3)] bg-[rgba(196,149,106,0.06)] text-[#E8C880] cursor-pointer hover:bg-[rgba(196,149,106,0.12)] transition"
        >
          {isPlaying ? '⏸ Pause' : '▶ Play'}
        </button>
        <button
          onClick={() => {
            setIsPlaying(false)
            stateRef.current.stepOnce = true
          }}
          className="px-4 py-1.5 rounded-lg border border-[rgba(136,192,184,0.3)] bg-[rgba(136,192,184,0.06)] text-[#88C0B8] cursor-pointer hover:bg-[rgba(136,192,184,0.12)] transition"
        >
          ⏭ Step
        </button>
        <button
          onClick={() => {
            stateRef.current.trail = []
          }}
          className="px-4 py-1.5 rounded-lg border border-[rgba(255,255,255,0.15)] bg-[rgba(255,255,255,0.03)] text-[rgba(220,208,188,0.7)] cursor-pointer hover:bg-[rgba(255,255,255,0.08)] transition"
        >
          🔄 Clear Trail
        </button>
      </div>

      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InputCardField label="Charge (C)" value={localQ} onChange={setLocalQ} unit="C" />
            <InputCardField label="Velocity (m/s)" value={localV} onChange={setLocalV} unit="m/s" />
            <InputCardField label="B Field (T)" value={localB} onChange={setLocalB} unit="T" />
            <InputCardField label="Mass (kg)" value={localM} onChange={setLocalM} unit="kg" />
          </div>
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#A09CC8', color: '#141210' }}>Calculate</button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button>
          </div>
        </div>
      </WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="lorentzforce" params={{ charge, velocity: vel, magneticField: bField, mass }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}>
            <span className="opacity-50">Magnetic Force (F):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${F.toExponential(4)} N` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Orbit Radius (r):</span>
            <span className="font-bold text-[#A09CC8]">{(!isPending && realism.isRealistic) ? `${r.toExponential(4)} m` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Cyclotron Freq (ω):</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${cyclotronFreq.toExponential(4)} rad/s` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula:</span>
            <span className="font-mono text-xs text-[#E8C880] block">F = |q|vB = {(!isPending && realism.isRealistic) ? `${Math.abs(charge).toExponential(3)} C × ${vel.toExponential(2)} m/s × ${bField.toFixed(2)} T = ${F.toExponential(4)} N` : "[Missing]"}</span>
            <span className="font-mono text-xs text-[#A09CC8] block mt-1">r = mv/(|q|B) = {(!isPending && realism.isRealistic) ? `${r.toExponential(4)} m` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

export function IdealGasSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [moles, setMoles] = useState(() => getInitialParam(initialParams, 'moles', 1))
  const [temp, setTemp] = useState(() => getInitialParam(initialParams, 'temperature', 300))
  const [volume, setVolume] = useState(() => getInitialParam(initialParams, 'volume', 0.0224))
  const [localN, setLocalN] = useState(1); const [localT, setLocalT] = useState(300); const [localV, setLocalV] = useState(0.0224)
  useEffect(() => { setLocalN(moles); setLocalT(temp); setLocalV(volume) }, [moles, temp, volume])
  const animRef = useRef()
  
  const isPending = moles === "" || temp === "" || volume === "";
  const realism = checkRealism('idealgas', isPending ? {} : { moles, temperature: temp, volume })

  const stateRef = useRef({ n: 1, T: 300, V: 0.0224, t: 0, particles: [], isPending: false, isRealistic: true })
  useEffect(() => { Object.assign(stateRef.current, { n: moles, T: temp, V: volume, isPending, isRealistic: realism.isRealistic }) }, [moles, temp, volume, isPending, realism.isRealistic])
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d'); const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340; canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`; ctx.scale(dpr, dpr)
    const particles = Array.from({ length: 60 }, () => ({ x: 200 + Math.random() * 500, y: 60 + Math.random() * 220, vx: (Math.random() - 0.5) * 3, vy: (Math.random() - 0.5) * 3 }))
    stateRef.current.particles = particles
        const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current; s.t += 0.016; const R = 8.314, P = s.n * R * s.T / s.V
      const containerW = Math.max(200, Math.min(700, s.V * 15000)); const containerH = 220
      const cx = W / 2 - containerW / 2, cy = 60; const speedFactor = Math.sqrt(s.T / 300)
      ctx.clearRect(0, 0, W, H)
      ctx.strokeStyle = 'rgba(224,120,64,0.3)'; ctx.lineWidth = 2; ctx.strokeRect(cx, cy, containerW, containerH)
      ctx.fillStyle = 'rgba(224,120,64,0.15)'; ctx.fillRect(cx + containerW - 8, cy, 8, containerH)
      for (const p of particles) {
        p.x += p.vx * speedFactor; p.y += p.vy * speedFactor
        if (p.x < cx + 5 || p.x > cx + containerW - 5) { p.vx *= -1; p.x = Math.max(cx + 5, Math.min(cx + containerW - 5, p.x)) }
        if (p.y < cy + 5 || p.y > cy + containerH - 5) { p.vy *= -1; p.y = Math.max(cy + 5, Math.min(cy + containerH - 5, p.y)) }
        ctx.fillStyle = `rgba(224,120,64,${0.3 + speedFactor * 0.2})`; ctx.beginPath(); ctx.arc(p.x, p.y, 3, 0, Math.PI * 2); ctx.fill()
      }
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'
      ctx.fillText(`P = ${(P / 1000).toFixed(1)} kPa`, 40, 25); ctx.fillText(`T = ${s.T} K`, 40, 45)
      animRef.current = requestAnimationFrame(draw)
    }; draw(); return () => cancelAnimationFrame(animRef.current)
  }, [])
  const R = 8.314, P = moles * R * temp / volume
  const handleCalc = () => {
    if (localN === "" || localT === "" || localV === "") {
      if (localN === "") setMoles("");
      if (localT === "") setTemp("");
      if (localV === "") setVolume("");
      return;
    }
  let pn = parseFloat(localN); if (isNaN(pn)) pn = 1; pn = Math.max(0.01, Math.min(100, pn)); let pt = parseFloat(localT); if (isNaN(pt)) pt = 300; pt = Math.max(50, Math.min(5000, pt)); let pv = parseFloat(localV); if (isNaN(pv)) pv = 0.0224; pv = Math.max(0.001, Math.min(10, pv)); setMoles(pn); setTemp(pt); setVolume(pv) }
  const handleReset = () => { setMoles(1); setTemp(300); setVolume(0.0224) }
  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(224,120,64,0.1)' }} />
      <WorkspacePortal target="inputs"><div className="flex flex-col gap-4 w-full"><div className="grid grid-cols-1 sm:grid-cols-3 gap-4"><InputCardField label="Moles (n)" value={localN} min={0.01} max={100} step={0.01} onChange={setLocalN} unit="mol" /><InputCardField label="Temperature" value={localT} min={50} max={5000} step={10} onChange={setLocalT} unit="K" /><InputCardField label="Volume" value={localV} min={0.001} max={10} step={0.001} onChange={setLocalV} unit="m³" /></div><div className="flex gap-4 mt-2 w-full"><button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#E07840', color: '#141210' }}>Calculate</button><button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button></div></div></WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="idealgas" params={{ moles, temperature: temp, volume }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}>
            <span className="opacity-50">Pressure (P):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${(P/1000).toFixed(2)} kPa` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">PV Product:</span>
            <span className="font-bold text-[#E07840]">{(!isPending && realism.isRealistic) ? `${(P * volume).toFixed(2)} J` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">nRT:</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${(moles * R * temp).toFixed(2)} J` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(224,120,64,0.15)] bg-[rgba(224,120,64,0.04)]" style={{ borderLeft: '3px solid rgba(224,120,64,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula:</span>
            <span className="font-mono text-xs text-[#E8C880]">P = nRT/V = {(!isPending && realism.isRealistic) ? `${moles}×8.314×${temp}/${volume} = ${(P/1000).toFixed(2)} kPa` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

// ══════════════════════════════════════════════════
//  11. HOOKE'S LAW SIMULATOR — Spring-Mass System
// ══════════════════════════════════════════════════
export function HookeSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [k, setK] = useState(() => getInitialParam(initialParams, 'springConstant', 50))
  const [x, setX] = useState(() => getInitialParam(initialParams, 'displacement', 0.15))
  const [localK, setLocalK] = useState(50)
  const [localX, setLocalX] = useState(0.15)
  useEffect(() => { setLocalK(k); setLocalX(x) }, [k, x])
  const animRef = useRef()
  
  const isPending = k === "" || x === "";
  const realism = checkRealism('hooke', isPending ? {} : { springConstant: k, displacement: x })

  const stateRef = useRef({ k: 50, x: 0.15, t: 0, isPending: false, isRealistic: true })
  useEffect(() => { Object.assign(stateRef.current, { k, x, isPending, isRealistic: realism.isRealistic }) }, [k, x, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 380
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
        const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current; s.t += 0.03
      ctx.clearRect(0, 0, W, H)
      const eqX = W * 0.35, massW = 50, massH = 40
      const omega = Math.sqrt(s.k / 2) // m=2kg
      const disp = s.x * Math.cos(omega * s.t)
      const currentX = eqX + disp * 500 // scale to pixels
      // Wall
      ctx.fillStyle = 'rgba(136,192,184,0.3)'; ctx.fillRect(20, H/2 - 50, 10, 100)
      for (let i = 0; i < 8; i++) { ctx.strokeStyle = 'rgba(136,192,184,0.2)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(30, H/2-45+i*12); ctx.lineTo(20, H/2-35+i*12); ctx.stroke() }
      // Spring coils
      const springStart = 30, springEnd = currentX - massW/2
      const coils = 12, coilH = 15
      ctx.beginPath(); ctx.moveTo(springStart, H/2)
      const coilW = (springEnd - springStart) / coils
      for (let i = 0; i < coils; i++) {
        const cx1 = springStart + coilW * (i + 0.25), cy1 = H/2 - coilH
        const cx2 = springStart + coilW * (i + 0.75), cy2 = H/2 + coilH
        ctx.quadraticCurveTo(cx1, cy1, springStart + coilW * (i + 0.5), H/2)
        ctx.quadraticCurveTo(cx2, cy2, springStart + coilW * (i + 1), H/2)
      }
      ctx.strokeStyle = 'rgba(136,192,184,0.6)'; ctx.lineWidth = 2; ctx.stroke()
      // Mass block
      ctx.fillStyle = 'rgba(136,192,184,0.2)'; ctx.strokeStyle = 'rgba(136,192,184,0.5)'; ctx.lineWidth = 1.5
      ctx.fillRect(currentX - massW/2, H/2 - massH/2, massW, massH)
      ctx.strokeRect(currentX - massW/2, H/2 - massH/2, massW, massH)
      ctx.fillStyle = 'rgba(220,220,240,0.6)'; ctx.font = 'bold 11px var(--font-body)'
      ctx.textAlign = 'center'; ctx.fillText('m', currentX, H/2 + 4)
      // Equilibrium line
      ctx.setLineDash([4,4]); ctx.strokeStyle = 'rgba(196,149,106,0.25)'; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(eqX, H/2 - 60); ctx.lineTo(eqX, H/2 + 60); ctx.stroke()
      ctx.setLineDash([]); ctx.font = '10px var(--font-body)'; ctx.fillStyle = 'rgba(196,149,106,0.5)'; ctx.fillText('x=0', eqX, H/2 + 75)
      // Force arrow
      const force = -s.k * disp
      if (Math.abs(force) > 0.5) {
        const arrowLen = Math.min(Math.abs(force) * 0.8, 100)
        const arrowDir = force > 0 ? 1 : -1
        drawArrow(ctx, currentX + massW/2 * arrowDir, H/2, currentX + massW/2 * arrowDir + arrowLen * arrowDir, H/2, 'rgba(224,120,64,0.7)', 2, 8)
        ctx.fillStyle = 'rgba(224,120,64,0.7)'; ctx.font = '11px var(--font-body)'; ctx.fillText('F', currentX + massW/2 * arrowDir + arrowLen * arrowDir * 0.5, H/2 - 12)
      }
      // Graph (right side) — x(t) sinusoidal
      const gx = W * 0.6, gw = W * 0.35, gh = 120, gy = H/2
      ctx.strokeStyle = 'rgba(255,255,255,0.05)'; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(gx, gy); ctx.lineTo(gx + gw, gy); ctx.stroke()
      ctx.beginPath()
      for (let px = 0; px < gw; px++) {
        const tt = (px / gw) * 4 * Math.PI
        const yy = gy - s.x * Math.cos(omega * (s.t - (4*Math.PI - tt)/omega * 0.5)) * gh / 0.3
        if (px === 0) ctx.moveTo(gx + px, yy); else ctx.lineTo(gx + px, yy)
      }
      ctx.strokeStyle = 'rgba(136,192,184,0.5)'; ctx.lineWidth = 1.5; ctx.stroke()
      // Labels
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'; ctx.textAlign = 'left'
      ctx.fillText(`F = ${Math.abs(s.k * disp).toFixed(2)} N`, 40, 25)
      ctx.fillText(`x = ${(disp * 100).toFixed(1)} cm`, 40, 45)
      animRef.current = requestAnimationFrame(draw)
    }; draw(); return () => cancelAnimationFrame(animRef.current)
  }, [])
  const F = k * x
  const PE = 0.5 * k * x * x
  const handleCalc = () => {
    if (localK === "" || localX === "") {
      if (localK === "") setK("");
      if (localX === "") setX("");
      return;
    }
    let pk = parseFloat(localK); if (isNaN(pk)) pk = 50; pk = Math.max(1, Math.min(500, pk)); let px = parseFloat(localX); if (isNaN(px)) px = 0.1; px = Math.max(0.01, Math.min(0.5, px)); setK(pk); setX(px)
  }
  const handleReset = () => { setK(50); setX(0.15) }
  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InputCardField label="Spring Constant (k)" value={localK} min={1} max={500} step={1} onChange={setLocalK} unit="N/m" />
            <InputCardField label="Displacement (x)" value={localX} min={0.01} max={0.5} step={0.01} onChange={setLocalX} unit="m" />
          </div>
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>Calculate</button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button>
          </div>
        </div>
      </WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="hooke" params={{ springConstant: k, displacement: x }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}>
            <span className="opacity-50">Restoring Force (F):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${F.toFixed(3)} N` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Potential Energy (PE):</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${PE.toFixed(4)} J` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

export function SHMSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [amp, setAmp] = useState(() => getInitialParam(initialParams, 'amplitude', 0.1))
  const [freq, setFreq] = useState(() => getInitialParam(initialParams, 'frequency', 2))
  const [localA, setLocalA] = useState(0.1)
  const [localF, setLocalF] = useState(2)
  useEffect(() => { setLocalA(amp); setLocalF(freq) }, [amp, freq])
  const animRef = useRef()
  
  const isPending = amp === "" || freq === "";
  const realism = checkRealism('shm', isPending ? {} : { amplitude: amp, frequency: freq })

  const stateRef = useRef({ amp: 0.1, freq: 2, t: 0, isPending: false, isRealistic: true })
  useEffect(() => { Object.assign(stateRef.current, { amp, freq, isPending, isRealistic: realism.isRealistic }) }, [amp, freq, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 380
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
        const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current; s.t += 0.025
      ctx.clearRect(0, 0, W, H)
      const omega = 2 * Math.PI * s.freq
      const x = s.amp * Math.cos(omega * s.t)
      // Pendulum visualization (left half)
      const pivotX = W * 0.2, pivotY = 60, rodLen = 180
      const angle = Math.asin(x / s.amp * 0.5)
      const bobX = pivotX + rodLen * Math.sin(angle), bobY = pivotY + rodLen * Math.cos(angle)
      ctx.strokeStyle = 'rgba(196,149,106,0.3)'; ctx.lineWidth = 1; ctx.setLineDash([3,3])
      ctx.beginPath(); ctx.moveTo(pivotX, pivotY); ctx.lineTo(pivotX, pivotY + rodLen); ctx.stroke()
      ctx.setLineDash([])
      ctx.strokeStyle = 'rgba(136,192,184,0.6)'; ctx.lineWidth = 2
      ctx.beginPath(); ctx.moveTo(pivotX, pivotY); ctx.lineTo(bobX, bobY); ctx.stroke()
      ctx.fillStyle = 'rgba(136,192,184,0.3)'; ctx.strokeStyle = 'rgba(136,192,184,0.6)'; ctx.lineWidth = 1.5
      ctx.beginPath(); ctx.arc(bobX, bobY, 18, 0, Math.PI * 2); ctx.fill(); ctx.stroke()
      // Pivot
      ctx.fillStyle = 'rgba(196,149,106,0.5)'; ctx.beginPath(); ctx.arc(pivotX, pivotY, 4, 0, Math.PI * 2); ctx.fill()
      // Sinusoidal graph (right half)
      const gx = W * 0.45, gw = W * 0.5, gh = 100, gy = H / 2
      // Grid
      ctx.strokeStyle = 'rgba(255,255,255,0.03)'; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(gx, gy); ctx.lineTo(gx + gw, gy); ctx.stroke()
      ctx.beginPath(); ctx.moveTo(gx, gy - gh); ctx.lineTo(gx + gw, gy - gh); ctx.stroke()
      ctx.beginPath(); ctx.moveTo(gx, gy + gh); ctx.lineTo(gx + gw, gy + gh); ctx.stroke()
      // Wave
      ctx.beginPath()
      for (let px = 0; px < gw; px++) {
        const tt = (px / gw) * 4 * Math.PI / s.freq
        const yy = gy - s.amp * Math.cos(omega * (s.t - (4*Math.PI/s.freq - tt))) * gh / 0.2
        if (px === 0) ctx.moveTo(gx + px, yy); else ctx.lineTo(gx + px, yy)
      }
      ctx.strokeStyle = '#88C0B8'; ctx.lineWidth = 2; ctx.stroke()
      // Current position marker
      const markerY = gy - x * gh / 0.2
      ctx.fillStyle = '#E8C880'; ctx.beginPath(); ctx.arc(gx, markerY, 5, 0, Math.PI * 2); ctx.fill()
      // Labels
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'; ctx.textAlign = 'left'
      ctx.fillText(`x(t) = ${(x * 100).toFixed(2)} cm`, 40, 25)
      ctx.fillText(`Period = ${(1/s.freq).toFixed(3)} s`, 40, 45)
      ctx.fillText('x(t)', gx - 25, gy - gh - 5); ctx.fillText('t →', gx + gw - 20, gy + 15)
      animRef.current = requestAnimationFrame(draw)
    }; draw(); return () => cancelAnimationFrame(animRef.current)
  }, [])
  const period = 1 / freq
  const omega = 2 * Math.PI * freq
  const vMax = omega * amp
  const aMax = omega * omega * amp
  const handleCalc = () => {
    if (localA === "" || localF === "") {
      if (localA === "") setAmp("");
      if (localF === "") setFreq("");
      return;
    }
  let pa = parseFloat(localA); if (isNaN(pa)) pa = 0.1; pa = Math.max(0.01, Math.min(1, pa)); let pf = parseFloat(localF); if (isNaN(pf)) pf = 2; pf = Math.max(0.1, Math.min(20, pf)); setAmp(pa); setFreq(pf) }
  const handleReset = () => { setAmp(0.1); setFreq(2) }
  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      <WorkspacePortal target="inputs"><div className="flex flex-col gap-4 w-full"><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><InputCardField label="Amplitude (A)" value={localA} min={0.01} max={1} step={0.01} onChange={setLocalA} unit="m" /><InputCardField label="Frequency (f)" value={localF} min={0.1} max={20} step={0.1} onChange={setLocalF} unit="Hz" /></div><div className="flex gap-4 mt-2 w-full"><button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>Calculate</button><button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button></div></div></WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="shm" params={{ amplitude: amp, frequency: freq }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}<div className="flex flex-col gap-5 font-mono text-xs w-full"><div className="flex justify-between items-center pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}><span className="opacity-50">Period (T):</span><span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${period.toFixed(4)} s` : "[Missing]"}</span></div><div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Angular Frequency (ω):</span><span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${omega.toFixed(2)} rad/s` : "[Missing]"}</span></div><div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Max Velocity:</span><span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${vMax.toFixed(4)} m/s` : "[Missing]"}</span></div><div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Max Acceleration:</span><span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${aMax.toFixed(4)} m/s²` : "[Missing]"}</span></div></div></WorkspacePortal>
    </div>
  )
}

// ══════════════════════════════════════════════════
//  13. OHM'S LAW SIMULATOR — Circuit Visualization
// ══════════════════════════════════════════════════
export function OhmSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [voltage, setVoltage] = useState(() => getInitialParam(initialParams, 'voltage', 12))
  const [resistance, setResistance] = useState(() => getInitialParam(initialParams, 'resistance', 100))
  const [localV, setLocalV] = useState(12)
  const [localR, setLocalR] = useState(100)
  useEffect(() => { setLocalV(voltage); setLocalR(resistance) }, [voltage, resistance])
  const animRef = useRef()
  
  const isPending = voltage === "" || resistance === "";
  const realism = checkRealism('ohm', isPending ? {} : { voltage, resistance })

  const stateRef = useRef({ V: 12, R: 100, t: 0, isPending: false, isRealistic: true })
  useEffect(() => {
    stateRef.current.V = voltage;
    stateRef.current.R = resistance;
    stateRef.current.t = 0;
    stateRef.current.isPending = isPending;
    stateRef.current.isRealistic = realism.isRealistic;
  }, [voltage, resistance, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 380
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    // Electron particles along circuit
    const electrons = Array.from({length: 30}, (_, i) => ({ pos: i / 30, speed: 0.002 }))
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current; s.t += 0.02
      const I = s.V / s.R
      const speedFactor = Math.min(I * 50, 3)
      ctx.clearRect(0, 0, W, H)
      // Circuit path: rectangle
      const cx = 150, cy = 60, cw = 700, ch = 260
      ctx.strokeStyle = 'rgba(160,156,200,0.3)'; ctx.lineWidth = 3; ctx.lineJoin = 'round'
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + cw, cy); ctx.lineTo(cx + cw, cy + ch); ctx.lineTo(cx, cy + ch); ctx.closePath(); ctx.stroke()
      // Battery (left side)
      const batY = cy + ch/2
      ctx.strokeStyle = 'rgba(160,156,200,0.5)'; ctx.lineWidth = 3
      ctx.beginPath(); ctx.moveTo(cx - 15, batY - 25); ctx.lineTo(cx - 15, batY + 25); ctx.stroke()
      ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(cx + 5, batY - 15); ctx.lineTo(cx + 5, batY + 15); ctx.stroke()
      ctx.fillStyle = 'rgba(160,156,200,0.5)'; ctx.font = '11px var(--font-body)'; ctx.textAlign = 'center'
      ctx.fillText('+', cx - 15, batY - 30); ctx.fillText('−', cx + 5, batY - 22)
      ctx.fillText(`${s.V}V`, cx - 5, batY + 45)
      // Resistor (top, centered)
      const resX = cx + cw/2 - 40, resY = cy - 5
      for (let i = 0; i < 6; i++) {
        ctx.strokeStyle = 'rgba(160,156,200,0.4)'; ctx.lineWidth = 2
        ctx.beginPath()
        ctx.moveTo(resX + i * 14, resY); ctx.lineTo(resX + i * 14 + 7, resY - 10); ctx.lineTo(resX + i * 14 + 14, resY)
        ctx.stroke()
      }
      ctx.fillStyle = 'rgba(160,156,200,0.5)'; ctx.font = '11px var(--font-body)'
      ctx.fillText(`${s.R}Ω`, cx + cw/2, cy - 20)
      // Animated electrons
      for (const e of electrons) {
        e.pos += e.speed * speedFactor
        if (e.pos > 1) e.pos -= 1
        let ex, ey
        const p = e.pos
        const perimeter = 2 * cw + 2 * ch
        const dist = p * perimeter
        if (dist < cw) { ex = cx + dist; ey = cy }
        else if (dist < cw + ch) { ex = cx + cw; ey = cy + (dist - cw) }
        else if (dist < 2*cw + ch) { ex = cx + cw - (dist - cw - ch); ey = cy + ch }
        else { ex = cx; ey = cy + ch - (dist - 2*cw - ch) }
        ctx.fillStyle = `rgba(160,156,200,${0.3 + speedFactor * 0.15})`
        ctx.beginPath(); ctx.arc(ex, ey, 3, 0, Math.PI * 2); ctx.fill()
      }
      // Labels
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'; ctx.textAlign = 'left'
      ctx.fillText(`I = ${parseFloat(I.toFixed(4))} A`, 40, H - 30)
      ctx.fillText(`P = ${parseFloat((s.V * I).toFixed(4))} W`, 200, H - 30)
      animRef.current = requestAnimationFrame(draw)
    }; draw(); return () => cancelAnimationFrame(animRef.current)
  }, [])
  const I = voltage / resistance
  const P = voltage * I
  const handleCalc = () => {
    if (localV === "" || localR === "") {
      if (localV === "") setVoltage("");
      if (localR === "") setResistance("");
      return;
    }
    let pv = parseFloat(localV); if (isNaN(pv)) pv = 12;
    let pr = parseFloat(localR); if (isNaN(pr)) pr = 100;
    setVoltage(pv); setResistance(pr)
  }
  const handleReset = () => { setVoltage(12); setResistance(100) }
  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(160,156,200,0.1)' }} />
      <WorkspacePortal target="inputs"><div className="flex flex-col gap-4 w-full"><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><InputCardField label="Voltage (V)" value={localV} min={-1000} max={1000} step={0.1} onChange={setLocalV} unit="V" /><InputCardField label="Resistance (R)" value={localR} min={-1000000} max={1000000} step={1} onChange={setLocalR} unit="Ω" /></div><div className="flex gap-4 mt-2 w-full"><button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#A09CC8', color: '#141210' }}>Calculate</button><button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button></div></div></WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="ohm" params={{ voltage, resistance }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}>
            <span className="opacity-50">Current (I):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${parseFloat(I.toFixed(4))} A` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Power (P):</span>
            <span className="font-bold text-[#A09CC8]">{(!isPending && realism.isRealistic) ? `${parseFloat(P.toFixed(4))} W` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Energy/min:</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${parseFloat((P * 60).toFixed(2))} J/min` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(160,156,200,0.15)] bg-[rgba(160,156,200,0.04)]" style={{ borderLeft: '3px solid rgba(160,156,200,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula:</span>
            <span className="font-mono text-xs text-[#E8C880]">I = V/R = {voltage}/{resistance} = {(!isPending && realism.isRealistic) ? `${parseFloat(I.toFixed(4))} A` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

// ══════════════════════════════════════════════════
//  14. DE BROGLIE WAVELENGTH SIMULATOR
// ══════════════════════════════════════════════════
export function DeBroglieSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [mass, setMass] = useState(() => getInitialParam(initialParams, 'mass', 9.109e-31))
  const [vel, setVel] = useState(() => getInitialParam(initialParams, 'velocity', 1e6))
  const [localM, setLocalM] = useState('9.109e-31')
  const [localV, setLocalV] = useState('1e6')
  useEffect(() => { setLocalM(String(mass)); setLocalV(String(vel)) }, [mass, vel])
  const animRef = useRef()
  
  const isPending = mass === "" || vel === "";
  const realism = checkRealism('debroglie', isPending ? {} : { mass, velocity: vel })

  const stateRef = useRef({ mass: 9.109e-31, vel: 1e6, t: 0, isPending: false, isRealistic: true })
  useEffect(() => {
    stateRef.current.mass = mass;
    stateRef.current.vel = vel;
    stateRef.current.t = 0;
    stateRef.current.isPending = isPending;
    stateRef.current.isRealistic = realism.isRealistic;
  }, [mass, vel, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 380
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current; s.t += 0.04
      const h = 6.626e-34
      const p = s.mass * s.vel
      const lambda = h / p
      ctx.clearRect(0, 0, W, H)
      // Wave packet visualization
      const waveY = H / 2, waveAmp = 80
      const wavelengthPx = Math.max(20, Math.min(200, lambda * 1e12 * 50))
      const k = 2 * Math.PI / wavelengthPx
      // Wave packet envelope
      const packetWidth = W * 0.7, packetStart = W * 0.15
      ctx.beginPath()
      for (let px = 0; px < W; px++) {
        const relX = px - packetStart - packetWidth/2
        const envelope = Math.exp(-(relX * relX) / (packetWidth * packetWidth * 0.08))
        const wave = Math.cos(k * px - s.t * 3) * envelope
        const yy = waveY - wave * waveAmp
        if (px === 0) ctx.moveTo(px, yy); else ctx.lineTo(px, yy)
      }
      ctx.strokeStyle = '#C4956A'; ctx.lineWidth = 2.5; ctx.stroke()
      // Envelope
      ctx.beginPath()
      for (let px = 0; px < W; px++) {
        const relX = px - packetStart - packetWidth/2
        const envelope = Math.exp(-(relX * relX) / (packetWidth * packetWidth * 0.08))
        ctx.lineTo(px, waveY - envelope * waveAmp)
      }
      ctx.strokeStyle = 'rgba(196,149,106,0.2)'; ctx.lineWidth = 1; ctx.setLineDash([4,4]); ctx.stroke(); ctx.setLineDash([])
      // Wavelength annotation
      const annotY = waveY + waveAmp + 30
      const wlStart = W/2 - wavelengthPx/2, wlEnd = W/2 + wavelengthPx/2
      ctx.strokeStyle = 'rgba(136,192,184,0.5)'; ctx.lineWidth = 1.5
      drawArrow(ctx, wlStart, annotY, wlEnd, annotY, 'rgba(136,192,184,0.5)', 1.5, 6)
      drawArrow(ctx, wlEnd, annotY, wlStart, annotY, 'rgba(136,192,184,0.5)', 1.5, 6)
      ctx.fillStyle = 'rgba(136,192,184,0.7)'; ctx.font = '12px var(--font-body)'; ctx.textAlign = 'center'
      ctx.fillText(`λ = ${lambda.toExponential(3)} m`, W/2, annotY - 10)
      // Particle dot
      const particleX = packetStart + packetWidth/2 + Math.sin(s.t * 2) * 20
      ctx.fillStyle = 'rgba(196,149,106,0.8)'; ctx.beginPath(); ctx.arc(particleX, waveY, 6, 0, Math.PI * 2); ctx.fill()
      ctx.fillStyle = 'rgba(196,149,106,0.2)'; ctx.beginPath(); ctx.arc(particleX, waveY, 12, 0, Math.PI * 2); ctx.fill()
      // Labels
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'; ctx.textAlign = 'left'
      ctx.fillText(`p = ${p.toExponential(3)} kg·m/s`, 40, 25)
      ctx.fillText(`λ = ${lambda.toExponential(3)} m`, 40, 45)
      animRef.current = requestAnimationFrame(draw)
    }; draw(); return () => cancelAnimationFrame(animRef.current)
  }, [])
  const h = 6.626e-34
  const p = mass * vel
  const lambda = h / p
  const E = 0.5 * mass * vel * vel
  const handleCalc = () => {
    if (localM === "" || localV === "") {
      if (localM === "") setMass("");
      if (localV === "") setVel("");
      return;
    }
    let pm = parseFloat(localM); if (isNaN(pm)) pm = 9.109e-31; pm = Math.max(1e-35, Math.min(1, pm)); let pv = parseFloat(localV); if (isNaN(pv)) pv = 1e6; pv = Math.max(1, Math.min(3e8, pv)); setMass(pm); setVel(pv)
  }
  const handleReset = () => { setMass(9.109e-31); setVel(1e6) }
  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(196,149,106,0.1)' }} />
      <WorkspacePortal target="inputs"><div className="flex flex-col gap-4 w-full"><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><InputCardField label="Particle Mass" value={localM} onChange={setLocalM} unit="kg" /><InputCardField label="Velocity" value={localV} onChange={setLocalV} unit="m/s" /></div><div className="flex gap-4 mt-2 w-full"><button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#C4956A', color: '#141210' }}>Calculate</button><button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button></div></div></WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="debroglie" params={{ mass, velocity: vel }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}>
            <span className="opacity-50">Wavelength (λ):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${lambda.toExponential(4)} m` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Momentum (p):</span>
            <span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${p.toExponential(4)} kg·m/s` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Kinetic Energy:</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${E.toExponential(4)} J` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula:</span>
            <span className="font-mono text-xs text-[#E8C880]">λ = h/(mv) = {h.toExponential(3)}/({mass.toExponential(3)}×{vel.toExponential(3)}) = {(!isPending && realism.isRealistic) ? `${lambda.toExponential(4)} m` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

// ══════════════════════════════════════════════════
//  15. PHOTOELECTRIC EFFECT SIMULATOR
// ══════════════════════════════════════════════════
export function PhotoelectricSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [frequency, setFrequency] = useState(() => getInitialParam(initialParams, 'frequency', 1e15))
  const [workFn, setWorkFn] = useState(() => getInitialParam(initialParams, 'workFunction', 4.2))
  const [localFreq, setLocalFreq] = useState('1e15')
  const [localPhi, setLocalPhi] = useState(4.2)
  useEffect(() => { setLocalFreq(String(frequency)); setLocalPhi(workFn) }, [frequency, workFn])
  const animRef = useRef()
  
  const isPending = frequency === "" || workFn === "";
  const realism = checkRealism('photoelectric', isPending ? {} : { frequency, workFunction: workFn })

  const stateRef = useRef({ freq: 1e15, phi: 4.2, t: 0, electrons: [], isPending: false, isRealistic: true })
  useEffect(() => {
    stateRef.current.freq = frequency;
    stateRef.current.phi = workFn;
    stateRef.current.t = 0;
    stateRef.current.electrons = [];
    stateRef.current.isPending = isPending;
    stateRef.current.isRealistic = realism.isRealistic;
  }, [frequency, workFn, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 380
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    // Photon wave particles
    const photons = Array.from({length: 8}, (_, i) => ({ x: -50 - i * 80, y: 120 + Math.random() * 140 }))
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current || {}
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const s = stateRef.current; s.t += 0.03
      const hPlank = 6.626e-34, eV = 1.602e-19
      const photonE = hPlank * s.freq / eV // in eV
      const emission = photonE > s.phi
      const KE = emission ? photonE - s.phi : 0
      ctx.clearRect(0, 0, W, H)
      // Metal surface
      const metalX = W * 0.45, metalW = 20
      ctx.fillStyle = 'rgba(160,156,200,0.15)'; ctx.fillRect(metalX, 30, metalW, H - 60)
      ctx.strokeStyle = 'rgba(160,156,200,0.3)'; ctx.lineWidth = 2; ctx.strokeRect(metalX, 30, metalW, H - 60)
      ctx.fillStyle = 'rgba(160,156,200,0.4)'; ctx.font = '10px var(--font-body)'; ctx.textAlign = 'center'
      ctx.save(); ctx.translate(metalX + metalW + 12, H/2); ctx.rotate(-Math.PI/2); ctx.fillText('Metal Surface', 0, 0); ctx.restore()
      // Photons coming from left
      for (const ph of photons) {
        ph.x += 2.5
        if (ph.x > metalX - 5) {
          ph.x = -50 - Math.random() * 100
          ph.y = 120 + Math.random() * 140
          // Emit electron if energy sufficient
          if (emission && Math.random() > 0.6) {
            s.electrons.push({ x: metalX + metalW + 5, y: ph.y, vx: 1 + KE * 0.3, vy: (Math.random() - 0.5) * 2, life: 100 })
          }
        }
        // Photon wave drawing
        ctx.strokeStyle = `rgba(196,149,106,${emission ? 0.7 : 0.3})`; ctx.lineWidth = 1.5
        ctx.beginPath()
        for (let i = 0; i < 20; i++) {
          const px = ph.x - i * 4, py = ph.y + Math.sin(i * 0.8 + s.t * 5) * 6
          if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py)
        }
        ctx.stroke()
        ctx.fillStyle = `rgba(196,149,106,${emission ? 0.8 : 0.4})`; ctx.beginPath(); ctx.arc(ph.x, ph.y, 3, 0, Math.PI * 2); ctx.fill()
      }
      // Emitted electrons
      s.electrons = s.electrons.filter(e => e.life > 0)
      for (const e of s.electrons) {
        e.x += e.vx; e.y += e.vy; e.life--
        const alpha = e.life / 100
        ctx.fillStyle = `rgba(136,192,184,${alpha * 0.7})`; ctx.beginPath(); ctx.arc(e.x, e.y, 3, 0, Math.PI * 2); ctx.fill()
        ctx.fillStyle = `rgba(136,192,184,${alpha * 0.2})`; ctx.beginPath(); ctx.arc(e.x, e.y, 6, 0, Math.PI * 2); ctx.fill()
      }
      // Status label
      ctx.fillStyle = emission ? 'rgba(136,192,184,0.7)' : 'rgba(224,120,64,0.7)'
      ctx.font = 'bold 14px var(--font-body)'; ctx.textAlign = 'center'
      ctx.fillText(emission ? 'ELECTRONS EMITTED' : 'NO EMISSION — Below Threshold', W/2, H - 20)
      // Info
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'; ctx.textAlign = 'left'
      ctx.fillText(`hf = ${photonE.toFixed(2)} eV`, 40, 25)
      ctx.fillText(`φ = ${s.phi} eV`, 40, 45)
      if (emission) ctx.fillText(`KE = ${KE.toFixed(2)} eV`, 40, 65)
      // Arrow labels
      ctx.fillStyle = 'rgba(196,149,106,0.5)'; ctx.font = '11px var(--font-body)'; ctx.textAlign = 'center'
      ctx.fillText('Photons →', W * 0.2, 50)
      if (emission) { ctx.fillStyle = 'rgba(136,192,184,0.5)'; ctx.fillText('← Electrons', W * 0.7, 50) }
      animRef.current = requestAnimationFrame(draw)
    }; draw(); return () => cancelAnimationFrame(animRef.current)
  }, [])
  const hPlank = 6.626e-34, eVConst = 1.602e-19
  const photonE = hPlank * frequency / eVConst
  const emission = photonE > workFn
  const KE = emission ? photonE - workFn : 0
  const thresholdFreq = workFn * eVConst / hPlank
  const handleCalc = () => {
    if (localFreq === "" || localPhi === "") {
      if (localFreq === "") setFrequency("");
      if (localPhi === "") setWorkFn("");
      return;
    }
    let pf = parseFloat(localFreq); if (isNaN(pf)) pf = 1e15; pf = Math.max(1e12, Math.min(1e18, pf)); let pp = parseFloat(localPhi); if (isNaN(pp)) pp = 4.2; pp = Math.max(0.1, Math.min(20, pp)); setFrequency(pf); setWorkFn(pp)
  }
  const handleReset = () => { setFrequency(1e15); setWorkFn(4.2) }
  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(196,149,106,0.1)' }} />
      <WorkspacePortal target="inputs"><div className="flex flex-col gap-4 w-full"><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><InputCardField label="Light Frequency" value={localFreq} onChange={setLocalFreq} unit="Hz" /><InputCardField label="Work Function" value={localPhi} onChange={setLocalPhi} unit="eV" /></div><div className="flex gap-4 mt-2 w-full"><button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#C4956A', color: '#141210' }}>Calculate</button><button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button></div></div></WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="photoelectric" params={{ frequency, workFunction: workFn }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}>
            <span className="opacity-50">Photon Energy (E):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${photonE.toFixed(3)} eV` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Emission Status:</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? (emission ? "YES (Emitted)" : "NO (Below Threshold)") : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Max Kinetic Energy:</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${KE.toFixed(4)} eV` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Threshold Freq:</span>
            <span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${thresholdFreq.toExponential(4)} Hz` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula:</span>
            <span className="font-mono text-xs text-[#E8C880]">KE = hf - φ = {(!isPending && realism.isRealistic) ? `${photonE.toFixed(2)} eV - ${workFn} eV = ${KE.toFixed(2)} eV` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

export function RCCircuitSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [voltage, setVoltage] = useState(() => getInitialParam(initialParams, 'voltage', 10))
  const [resistance, setResistance] = useState(() => getInitialParam(initialParams, 'resistance', 1000))
  const [capacitance, setCapacitance] = useState(() => getInitialParam(initialParams, 'capacitance', 1e-5))

  const [localV, setLocalV] = useState(voltage)
  const [localR, setLocalR] = useState(resistance)
  const [localC, setLocalC] = useState(() => capacitance === "" ? "" : capacitance * 1e6)

  useEffect(() => {
    setLocalV(voltage)
    setLocalR(resistance)
    setLocalC(capacitance === "" ? "" : capacitance * 1e6)
  }, [voltage, resistance, capacitance])

  const isPending = voltage === "" || resistance === "" || capacitance === ""
  const realism = checkRealism('rc_circuit', isPending ? {} : { voltage, resistance, capacitance })

  const animRef = useRef()
  const stateRef = useRef({ V: 10, R: 1000, C: 1e-5, t: 0, isPending: false, isRealistic: true })
  useEffect(() => {
    stateRef.current = { V: voltage, R: resistance, C: capacitance, t: 0, isPending, isRealistic: realism.isRealistic }
  }, [voltage, resistance, capacitance, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 380
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)

    const electrons = Array.from({ length: 30 }, (_, i) => ({ pos: i / 30, speed: 0.002 }))

    const draw = () => {
      const s = stateRef.current
      if (s.isPending || !s.isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(s.isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }

      const tau = s.R * s.C
      s.t += 0.016
      const cycleTime = tau * 5 + 2
      if (s.t > cycleTime) {
        s.t = 0
      }
      
      const curT = Math.min(s.t, tau * 5)
      const vc = s.V * (1 - Math.exp(-curT / tau))
      const current = (s.V / s.R) * Math.exp(-curT / tau)
      const q = s.C * vc

      ctx.clearRect(0, 0, W, H)

      ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
      for (let y = 30; y <= H - 30; y += 40) { ctx.beginPath(); ctx.moveTo(40, y); ctx.lineTo(W - 40, y); ctx.stroke() }

      const cx = 80, cy = 60, cw = 400, ch = 220
      ctx.strokeStyle = 'rgba(160,156,200,0.3)'; ctx.lineWidth = 3; ctx.lineJoin = 'round'
      ctx.beginPath()
      ctx.moveTo(cx, cy)
      ctx.lineTo(cx + cw, cy)
      ctx.lineTo(cx + cw, cy + ch)
      ctx.lineTo(cx, cy + ch)
      ctx.closePath()
      ctx.stroke()

      const batY = cy + ch / 2
      ctx.strokeStyle = 'rgba(160,156,200,0.5)'; ctx.lineWidth = 3
      ctx.beginPath(); ctx.moveTo(cx - 15, batY - 25); ctx.lineTo(cx - 15, batY + 25); ctx.stroke()
      ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(cx + 5, batY - 15); ctx.lineTo(cx + 5, batY + 15); ctx.stroke()
      ctx.fillStyle = 'rgba(160,156,200,0.5)'; ctx.font = '11px var(--font-body)'; ctx.textAlign = 'center'
      ctx.fillText('+', cx - 15, batY - 30); ctx.fillText('−', cx + 5, batY - 22)
      ctx.fillText(`${s.V}V`, cx - 5, batY + 45)

      const resX = cx + cw / 3 - 40, resY = cy - 5
      for (let i = 0; i < 6; i++) {
        ctx.strokeStyle = 'rgba(160,156,200,0.4)'; ctx.lineWidth = 2
        ctx.beginPath()
        ctx.moveTo(resX + i * 14, resY)
        ctx.lineTo(resX + i * 14 + 7, resY - 10)
        ctx.lineTo(resX + i * 14 + 14, resY)
        ctx.stroke()
      }
      ctx.fillStyle = 'rgba(160,156,200,0.5)'; ctx.fillText(`${s.R}Ω`, cx + cw / 3, cy - 20)

      const capX = cx + cw, capY = cy + ch / 2
      ctx.clearRect(capX - 2, capY - 40, 4, 80)
      ctx.strokeStyle = '#E8C880'; ctx.lineWidth = 4
      ctx.beginPath(); ctx.moveTo(capX - 10, capY - 30); ctx.lineTo(capX - 10, capY + 30); ctx.stroke()
      ctx.strokeStyle = '#88C0B8'; ctx.beginPath(); ctx.moveTo(capX + 10, capY - 30); ctx.lineTo(capX + 10, capY + 30); ctx.stroke()
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.fillText(`${(s.C * 1e6).toFixed(1)}µF`, capX + 35, capY + 5)

      const numCharges = Math.min(8, Math.floor((vc / s.V) * 8))
      ctx.fillStyle = '#E8C880'; ctx.font = '10px var(--font-mono)'
      for (let i = 0; i < numCharges; i++) {
        const offset = (i - (numCharges - 1) / 2) * 8
        ctx.fillText('+', capX - 18, capY + offset + 3)
      }
      ctx.fillStyle = '#88C0B8'
      for (let i = 0; i < numCharges; i++) {
        const offset = (i - (numCharges - 1) / 2) * 8
        ctx.fillText('-', capX + 18, capY + offset + 3)
      }

      const currentRatio = current / (s.V / s.R)
      const speedFactor = Math.min(currentRatio * 5, 2.5)
      if (speedFactor > 0.01) {
        for (const e of electrons) {
          e.pos += e.speed * speedFactor
          if (e.pos > 1) e.pos -= 1
          let ex, ey
          const p = e.pos
          const perimeter = 2 * cw + 2 * ch
          const dist = p * perimeter
          if (dist < cw) { ex = cx + dist; ey = cy }
          else if (dist < cw + ch) { ex = cx + cw; ey = cy + (dist - cw) }
          else if (dist < 2 * cw + ch) { ex = cx + cw - (dist - (cw + ch)); ey = cy + ch }
          else { ex = cx; ey = cy + ch - (dist - (2 * cw + ch)) }
          ctx.fillStyle = '#88C0B8'; ctx.beginPath(); ctx.arc(ex, ey, 2.5, 0, Math.PI * 2); ctx.fill()
        }
      }

      const gx = 560, gy = 60, gw = 460, gh = 220
      ctx.strokeStyle = 'rgba(220,200,165,0.2)'; ctx.lineWidth = 1.5
      ctx.beginPath(); ctx.moveTo(gx, gy); ctx.lineTo(gx, gy + gh); ctx.lineTo(gx + gw, gy + gh); ctx.stroke()
      ctx.fillStyle = 'rgba(220,200,165,0.4)'; ctx.font = '10px var(--font-body)'; ctx.textAlign = 'center'
      ctx.fillText('V_c(t)', gx - 35, gy + 10)
      ctx.fillText('Time t (s) →', gx + gw - 60, gy + gh + 15)

      ctx.beginPath(); ctx.lineWidth = 2; ctx.strokeStyle = '#E8C880'
      for (let xPixel = 0; xPixel <= gw; xPixel++) {
        const plotT = (xPixel / gw) * (tau * 5)
        const plotYVal = s.V * (1 - Math.exp(-plotT / tau))
        const plotYPixel = gy + gh - (plotYVal / s.V) * gh
        if (xPixel === 0) ctx.moveTo(gx + xPixel, plotYPixel); else ctx.lineTo(gx + xPixel, plotYPixel)
      }
      ctx.stroke()

      const markerX = gx + (curT / (tau * 5)) * gw
      const markerY = gy + gh - (vc / s.V) * gh
      ctx.fillStyle = '#E8C880'; ctx.beginPath(); ctx.arc(markerX, markerY, 5, 0, Math.PI * 2); ctx.fill()

      ctx.fillStyle = '#E8C880'; ctx.font = '10px var(--font-body)'; ctx.textAlign = 'left'
      ctx.fillText(`Capacitor Voltage V_c = ${vc.toFixed(2)} V`, gx + 30, gy + 20)
      ctx.fillStyle = 'rgba(220,200,165,0.5)'
      ctx.fillText(`Current I = ${(current * 1000).toFixed(2)} mA`, gx + 30, gy + 38)
      ctx.fillText(`Stored Charge Q = ${(q * 1e6).toFixed(2)} µC`, gx + 30, gy + 56)

      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const tau = resistance * capacitance
  const maxQ = capacitance * voltage
  const maxE = 0.5 * capacitance * voltage * voltage

  const handleCalc = () => {
    if (localV === "" || localR === "" || localC === "") {
      if (localV === "") setVoltage("");
      if (localR === "") setResistance("");
      if (localC === "") setCapacitance("");
      return;
    }
    let pv = parseFloat(localV); if (isNaN(pv)) pv = 10; pv = Math.max(0.1, Math.min(100, pv))
    let pr = parseFloat(localR); if (isNaN(pr)) pr = 1000; pr = Math.max(1, Math.min(1e6, pr))
    let pc = parseFloat(localC); if (isNaN(pc)) pc = 10; pc = Math.max(0.1, Math.min(1000, pc))
    setVoltage(pv)
    setResistance(pr)
    setCapacitance(pc * 1e-6)
  }

  const handleReset = () => {
    setVoltage(10)
    setResistance(1000)
    setCapacitance(1e-5)
  }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <InputCardField label="Voltage (V₀)" value={localV} min={0.1} max={100} step={0.5} onChange={setLocalV} unit="V" />
            <InputCardField label="Resistance (R)" value={localR} min={1} max={1000000} step={10} onChange={setLocalR} unit="Ω" />
            <InputCardField label="Capacitance (C)" value={localC} min={0.1} max={1000} step={0.1} onChange={setLocalC} unit="µF" />
          </div>
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalc} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>Calculate</button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button>
          </div>
        </div>
      </WorkspacePortal>
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="rc_circuit" params={{ voltage, resistance, capacitance }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center pb-2.5" style={{ background: 'rgba(196,149,106,0.04)', borderLeft: '2px solid rgba(196,149,106,0.4)', padding: '8px 12px', borderRadius: '6px' }}>
            <span className="opacity-50">Time Constant (τ = RC):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${(tau * 1000).toFixed(2)} ms` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Max Stored Charge (Q_max):</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${(maxQ * 1e6).toFixed(3)} µC` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Max Energy Stored (E_max):</span>
            <span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${(maxE * 1e3).toFixed(4)} mJ` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(136,192,184,0.15)] bg-[rgba(136,192,184,0.04)]" style={{ borderLeft: '3px solid rgba(136,192,184,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              State Eq: V_c(t) = V₀(1 − e^(−t/RC)) <br/>
              τ = R · C = {(!isPending && realism.isRealistic) ? `${resistance} Ω · ${(capacitance * 1e6).toFixed(1)} µF = ${(tau * 1000).toFixed(2)} ms` : "[Missing]"} <br/>
              Q_max = C · V₀ = {(!isPending && realism.isRealistic) ? `${(capacitance * 1e6).toFixed(1)} µF · ${voltage} V = ${(maxQ * 1e6).toFixed(2)} µC` : "[Missing]"}
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}
