import React from 'react'
import { checkRealism as checkRealismLib } from '../lib/parameterExtractor'

// Physics Realism Check Engine wrapper
export function checkRealism(equationId, params) {
  const result = checkRealismLib(equationId, params)
  if (typeof window !== 'undefined') {
    window.__pinn_last_status = result.status
  }
  return result
}

export function RealismCheckCard({ equationId, params, isPending }) {
  const result = checkRealism(equationId, params)

  if (result.status === 'unrealistic') {
    return (
      <div
        className="p-4 rounded-xl border mb-5 font-mono text-xs backdrop-blur-md transition-all duration-300"
        style={{
          background: 'rgba(20, 18, 16, 0.45)',
          borderColor: 'rgba(239, 68, 68, 0.7)',
          borderWidth: '1px',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)',
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <div>
            <span style={{ color: 'rgba(220, 208, 188, 0.5)' }}>Status: </span>
            <span style={{ color: '#EF4444', fontWeight: 'bold' }}>UNREALISTIC / INVALID</span>
          </div>
          <div>
            <span style={{ color: 'rgba(220, 208, 188, 0.5)' }}>Reason: </span>
            <span style={{ color: '#E8DDCC' }}>{result.reason}</span>
          </div>
          <div>
            <span style={{ color: 'rgba(220, 208, 188, 0.5)' }}>Constraint: </span>
            <span style={{ color: '#EF4444' }}>{result.violatedConstraint}</span>
          </div>
          <div>
            <span style={{ color: 'rgba(220, 208, 188, 0.5)' }}>Fix: </span>
            <span style={{ color: '#E8C880' }}>{result.correctiveSuggestion}</span>
          </div>
          <div style={{ marginTop: '4px', fontWeight: 'bold', color: '#EF4444' }}>
            Calculation and simulation blocked.
          </div>
        </div>
      </div>
    )
  }

  // Color mappings based on status for realistic/extreme/incomplete
  let badgeBg = 'rgba(136, 192, 184, 0.15)'
  let badgeText = '#88C0B8'
  let borderStroke = 'rgba(136, 192, 184, 0.7)'
  let badgeLabel = 'REALISTIC'

  if (result.status === 'incomplete') {
    badgeBg = 'rgba(255, 255, 255, 0.05)'
    badgeText = 'rgba(220, 208, 188, 0.5)'
    borderStroke = 'rgba(255, 255, 255, 0.35)'
    badgeLabel = 'INCOMPLETE'
  } else if (result.status === 'extreme') {
    badgeBg = 'rgba(232, 200, 128, 0.12)'
    badgeText = '#E8C880'
    borderStroke = 'rgba(232, 200, 128, 0.7)'
    badgeLabel = 'EXTREME BUT POSSIBLE'
  }

  return (
    <div
      className="p-4 rounded-xl border mb-5 font-mono text-xs backdrop-blur-md transition-all duration-300"
      style={{
        background: 'rgba(20, 18, 16, 0.45)',
        borderColor: borderStroke,
        borderWidth: '1px',
        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px', borderBottom: `1px solid ${borderStroke}`, paddingBottom: '8px' }}>
        <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#E8DDCC', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
          REALISM CHECK:
        </span>
        <span
          style={{
            fontSize: '11px',
            fontWeight: 'bold',
            color: badgeText,
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
          }}
        >
          {badgeLabel}
        </span>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <p style={{ fontFamily: 'var(--font-body)', fontSize: '0.84rem', color: '#E8DDCC', margin: 0, lineHeight: '1.45' }}>
          {result.reason}
        </p>

        {result.correctiveSuggestion && (
          <div style={{ borderLeft: '2px solid rgba(220, 208, 188, 0.25)', paddingLeft: '8px', margin: '4px 0 2px 0' }}>
            <span style={{ fontSize: '9px', textTransform: 'uppercase', color: 'rgba(220, 208, 188, 0.4)', display: 'block', marginBottom: '2px' }}>
              Corrective Suggestion
            </span>
            <p style={{ fontSize: '0.78rem', color: 'rgba(232, 221, 204, 0.85)', margin: 0 }}>
              {result.correctiveSuggestion}
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

// Global intercepts for history saving and DOM updates on unrealistic inputs
if (typeof window !== 'undefined') {
  // Track realism status globally
  window.__pinn_last_status = 'incomplete';

  // Override localStorage.setItem to block saving invalid calculations to history
  const originalSetItem = window.localStorage.setItem;
  window.localStorage.setItem = function (key, value) {
    if (key && key.startsWith('pinn_history_')) {
      try {
        const historyArray = JSON.parse(value);
        if (Array.isArray(historyArray)) {
          const filteredArray = historyArray.filter(item => {
            if (item && item.equationId && item.params) {
              const checkResult = checkRealismLib(item.equationId, item.params);
              if (checkResult && checkResult.status === 'unrealistic') {
                return false; // exclude from history
              }
            }
            return true;
          });
          value = JSON.stringify(filteredArray);
        }
      } catch (e) {
        console.error('Error filtering history in localStorage.setItem override:', e);
      }
    }
    return originalSetItem.call(this, key, value);
  };

  // Observe DOM and replace [Missing] with Calculation blocked for unrealistic/invalid inputs
  const runReplacement = () => {
    if (window.__pinn_last_status === 'unrealistic') {
      const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT,
        null,
        false
      );
      let node;
      while (node = walker.nextNode()) {
        if (node.nodeValue.includes('[Missing]')) {
          node.nodeValue = node.nodeValue.replaceAll('[Missing]', 'Calculation blocked');
        }
      }
    }
  };

  const observer = new MutationObserver(() => {
    runReplacement();
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        characterData: true
      });
      runReplacement();
    });
  } else {
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true
    });
    runReplacement();
  }
}
