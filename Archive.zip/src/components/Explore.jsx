import { useState, useEffect, useRef, useMemo, useContext } from 'react'
import { createPortal } from 'react-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ProjectileSimulator, EnergySimulator, MomentumSimulator,
  CircularMotionSimulator, GravitationSimulator, BernoulliSimulator,
  ReynoldsSimulator, CoulombSimulator, LorentzForceSimulator, IdealGasSimulator,
  HookeSimulator, SHMSimulator, OhmSimulator, DeBroglieSimulator, PhotoelectricSimulator,
  RCCircuitSimulator
} from './NewSimulators'
import { WorkspaceContext, WorkspacePortal, InputCardField, getInitialParam } from './WorkspaceShared'
import { getInterpretation, getPrimaryResultField } from '../lib/parameterExtractor'
import { checkRealism, RealismCheckCard } from './RealismCheck'


// ══════════════════════════════════════════════════
//  SIMULATOR COMPONENTS (full-page, only on select)
// ══════════════════════════════════════════════════

function SchrodingerSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [n, setN] = useState(() => getInitialParam(initialParams, 'quantumNumber', 2))
  const [mix, setMix] = useState(() => { const v = getInitialParam(initialParams, 'mix', 0.5); return v === "" ? 0.5 : v; })
  const [speed, setSpeed] = useState(() => { const v = getInitialParam(initialParams, 'speed', 1.5); return v === "" ? 1.5 : v; })

  const [localN, setLocalN] = useState(n)
  const [localMix, setLocalMix] = useState(mix)
  const [localSpeed, setLocalSpeed] = useState(speed)

  useEffect(() => {
    setLocalN(n); setLocalMix(mix); setLocalSpeed(speed)
  }, [n, mix, speed])

  const animRef = useRef()
  
  const isPending = n === "";
  const realism = checkRealism('schrodinger', isPending ? {} : { quantumNumber: n })

  const stateRef = useRef({ n: 2, mix: 0.5, speed: 1.5, t: 0, isPending: false, isRealistic: true })
  useEffect(() => { stateRef.current = { ...stateRef.current, n, mix, speed, isPending, isRealistic: realism.isRealistic } }, [n, mix, speed, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 400
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const { n, mix, speed } = stateRef.current
      stateRef.current.t += 0.035 * speed
      const t = stateRef.current.t
      ctx.clearRect(0, 0, W, H)
      ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)

      // Subtle grid
      ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
      for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
      for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }

      const L = W - 160, startX = 60, baseY = H - 50, amp = 100

      // Potential well walls
      ctx.strokeStyle = 'rgba(220,200,165,0.5)'; ctx.lineWidth = 3
      ctx.beginPath(); ctx.moveTo(startX, 30); ctx.lineTo(startX, baseY); ctx.stroke()
      ctx.beginPath(); ctx.moveTo(startX + L, 30); ctx.lineTo(startX + L, baseY); ctx.stroke()
      ctx.fillStyle = 'rgba(220,200,165,0.06)'
      ctx.fillRect(startX - 15, 30, 15, baseY - 30)
      ctx.fillRect(startX + L, 30, 15, baseY - 30)

      // Zero line
      ctx.strokeStyle = 'rgba(220,200,165,0.1)'; ctx.lineWidth = 1; ctx.setLineDash([3, 5])
      ctx.beginPath(); ctx.moveTo(startX, baseY); ctx.lineTo(startX + L, baseY); ctx.stroke()
      ctx.setLineDash([])

      // Compute and draw: Re(ψ) in teal, |ψ|² in gold
      const nodes = []
      // Re(ψ) wavefunction
      ctx.beginPath(); ctx.lineWidth = 1.8; ctx.strokeStyle = 'rgba(136,192,184,0.5)'
      let prevReal = 0
      for (let x = 0; x <= L; x++) {
        const frac = x / L
        const psiN = Math.sqrt(2 / L) * Math.sin(n * Math.PI * frac)
        const psiN1 = Math.sqrt(2 / L) * Math.sin((n + 1) * Math.PI * frac)
        const theta = mix * (Math.PI / 2), eN = n * n * 0.5, eN1 = (n + 1) * (n + 1) * 0.5
        const real = Math.cos(theta) * psiN * Math.cos(eN * t) + Math.sin(theta) * psiN1 * Math.cos(eN1 * t)
        const scaledReal = real * L * amp * 0.5
        const py = baseY - scaledReal
        if (x === 0) ctx.moveTo(startX + x, py); else ctx.lineTo(startX + x, py)
        // Detect nodes (zero crossings)
        if (x > 5 && x < L - 5 && prevReal * real < 0) nodes.push(startX + x)
        prevReal = real
      }
      ctx.stroke()

      // |ψ|² probability density
      ctx.beginPath(); ctx.lineWidth = 2.5
      const probGrad = ctx.createLinearGradient(startX, 0, startX + L, 0)
      probGrad.addColorStop(0, 'rgba(196,149,106,0.8)'); probGrad.addColorStop(0.5, '#E8C880'); probGrad.addColorStop(1, 'rgba(196,149,106,0.8)')
      ctx.strokeStyle = probGrad
      for (let x = 0; x <= L; x++) {
        const frac = x / L
        const psiN = Math.sqrt(2 / L) * Math.sin(n * Math.PI * frac)
        const psiN1 = Math.sqrt(2 / L) * Math.sin((n + 1) * Math.PI * frac)
        const theta = mix * (Math.PI / 2), eN = n * n * 0.5, eN1 = (n + 1) * (n + 1) * 0.5
        const real = Math.cos(theta) * psiN * Math.cos(eN * t) + Math.sin(theta) * psiN1 * Math.cos(eN1 * t)
        const imag = Math.cos(theta) * psiN * Math.sin(eN * t) + Math.sin(theta) * psiN1 * Math.sin(eN1 * t)
        const prob = (real * real + imag * imag) * L * amp
        const py = baseY - prob
        if (x === 0) ctx.moveTo(startX + x, py); else ctx.lineTo(startX + x, py)
      }
      ctx.stroke()
      // Fill under probability
      ctx.lineTo(startX + L, baseY); ctx.lineTo(startX, baseY)
      ctx.fillStyle = 'rgba(196,149,106,0.05)'; ctx.fill()

      // Node indicators
      for (const nx of nodes) {
        ctx.fillStyle = 'rgba(136,192,184,0.6)'
        ctx.beginPath(); ctx.arc(nx, baseY, 3, 0, Math.PI * 2); ctx.fill()
      }

      // Energy level diagram (top-right)
      const diagX = W - 80, diagY = 40, diagH = 120
      ctx.strokeStyle = 'rgba(220,200,165,0.2)'; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(diagX - 30, diagY); ctx.lineTo(diagX - 30, diagY + diagH); ctx.stroke()
      const maxE = Math.max(n + 1, 4)
      for (let i = 1; i <= Math.min(maxE, 5); i++) {
        const pyy = diagY + diagH - (i * i / (maxE * maxE)) * diagH
        const isActive = i === n || i === n + 1
        ctx.strokeStyle = isActive ? '#E8C880' : 'rgba(220,200,165,0.15)'; ctx.lineWidth = isActive ? 2 : 1
        ctx.beginPath(); ctx.moveTo(diagX - 45, pyy); ctx.lineTo(diagX - 15, pyy); ctx.stroke()
        ctx.fillStyle = isActive ? '#E8C880' : 'rgba(220,200,165,0.3)'; ctx.font = '9px var(--font-body)'; ctx.textAlign = 'left'
        ctx.fillText(`n=${i}`, diagX - 12, pyy + 3)
      }
      ctx.fillStyle = 'rgba(220,200,165,0.4)'; ctx.font = '9px var(--font-body)'; ctx.textAlign = 'center'
      ctx.fillText('Energy', diagX - 30, diagY - 5)

      // Legend
      ctx.textAlign = 'left'; ctx.font = '10px var(--font-body)'
      ctx.fillStyle = 'rgba(136,192,184,0.6)'; ctx.fillRect(startX, 15, 10, 3)
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.fillText('Re(ψ)', startX + 14, 19)
      ctx.fillStyle = '#E8C880'; ctx.fillRect(startX + 70, 15, 10, 3)
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.fillText('|ψ|²', startX + 84, 19)

      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const handleCalculate = () => {
    if (localN === "") { setN(""); return; }

    let parsedN = parseInt(localN); if (isNaN(parsedN)) parsedN = 2; parsedN = Math.max(1, Math.min(50, parsedN))
    let parsedMix = parseFloat(localMix); if (isNaN(parsedMix)) parsedMix = 0.5; parsedMix = Math.max(0, Math.min(1, parsedMix))
    let parsedSpeed = parseFloat(localSpeed); if (isNaN(parsedSpeed)) parsedSpeed = 1.5; parsedSpeed = Math.max(0.1, Math.min(20, parsedSpeed))
    setN(parsedN); setMix(parsedMix); setSpeed(parsedSpeed)
  }

  const handleReset = () => { setN(2); setMix(0.5); setSpeed(1.5) }

  const nNodes = n - 1

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(196,149,106,0.1)' }} />
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <InputCardField label="Energy State n" value={localN} min={1} max={50} step={1} onChange={setLocalN} />
            <InputCardField label="Superposition" value={localMix} min={0} max={1} step={0.01} onChange={setLocalMix} />
            <InputCardField label="Time Speed" value={localSpeed} min={0.1} max={20} step={0.1} onChange={setLocalSpeed} />
          </div>
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalculate} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#C4956A', color: '#141210' }}>Calculate</button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button>
          </div>
        </div>
      </WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="schrodinger" params={{ quantumNumber: n }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Energy Level (Eₙ):</span><span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${(n * n * 0.5).toFixed(2)} eV` : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Nodes (n−1):</span><span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? nNodes : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Superposition:</span><span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${(mix * 100).toFixed(0)}% ψₙ₊₁` : "[Missing]"}</span></div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Quantum State:</span>
            <span className="font-mono text-xs text-[#E8C880] block">Eₙ = n²·E₁ = {(!isPending && realism.isRealistic) ? `${n}²·0.5 = ${(n * n * 0.5).toFixed(2)} eV` : "[Missing]"}</span>
            <span className="font-mono text-xs text-[#88C0B8] block mt-1">|ψ⟩ = cos(θ)|{(!isPending && realism.isRealistic) ? n : "[Missing]"}⟩ + sin(θ)|{(!isPending && realism.isRealistic) ? n+1 : "[Missing]"}⟩</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

function UncertaintySimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [sigmaX, setSigmaX] = useState(() => getInitialParam(initialParams, 'position', 0.4))
  const [sigmaP, setSigmaP] = useState(() => getInitialParam(initialParams, 'momentum', 1.25))
  const [localSigmaX, setLocalSigmaX] = useState(sigmaX)
  const [localSigmaP, setLocalSigmaP] = useState(sigmaP)

  useEffect(() => {
    setLocalSigmaX(sigmaX)
    setLocalSigmaP(sigmaP)
  }, [sigmaX, sigmaP])

  const animRef = useRef()
  
  const isPending = sigmaX === "" || sigmaP === "";
  const realism = checkRealism('uncertainty', isPending ? {} : { position: sigmaX, momentum: sigmaP })

  const stateRef = useRef({ sigmaX: 0.4, sigmaP: 1.25, t: 0, isPending: false, isRealistic: true })
  useEffect(() => {
    stateRef.current.sigmaX = sigmaX
    stateRef.current.sigmaP = sigmaP
    stateRef.current.isPending = isPending
    stateRef.current.isRealistic = realism.isRealistic
  }, [sigmaX, sigmaP, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const { sigmaX, sigmaP } = stateRef.current
      stateRef.current.t += 0.02
      const t = stateRef.current.t
      ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
      // Grid
      ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
      for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }

      const halfW = W / 2, cy = H / 2
      // Position gaussian (left half)
      const sigP = Math.max(5, Math.min(halfW / 3, sigmaX * 120 + 10))
      const ampP = 130 / (sigP * 0.08)
      ctx.beginPath(); ctx.lineWidth = 2.5; ctx.strokeStyle = '#C4956A'
      for (let x = 0; x < halfW - 20; x++) {
        const dx = x - halfW / 2
        const y = cy - ampP * Math.exp(-dx * dx / (2 * sigP * sigP)) + Math.sin(t * 2 + x * 0.05) * 2
        if (x === 0) ctx.moveTo(20 + x, y); else ctx.lineTo(20 + x, y)
      }
      ctx.stroke()
      ctx.fillStyle = '#C4956A'; ctx.font = '13px var(--font-display)'; ctx.fillText('Position ψ(x)', 30, 30)

      // Momentum gaussian (right half)
      const sigM = Math.max(5, Math.min(halfW / 3, sigmaP * 35 + 8))
      const ampM = 130 / (sigM * 0.08)
      ctx.beginPath(); ctx.lineWidth = 2.5; ctx.strokeStyle = '#88C0B8'
      for (let x = 0; x < halfW - 20; x++) {
        const dx = x - halfW / 2
        const y = cy - ampM * Math.exp(-dx * dx / (2 * sigM * sigM)) + Math.cos(t * 2.5 + x * 0.04) * 2
        if (x === 0) ctx.moveTo(halfW + 10 + x, y); else ctx.lineTo(halfW + 10 + x, y)
      }
      ctx.stroke()
      ctx.fillStyle = '#88C0B8'; ctx.fillText('Momentum φ(p)', halfW + 20, 30)

      // Divider
      ctx.strokeStyle = 'rgba(196,149,106,0.15)'; ctx.setLineDash([4, 4])
      ctx.beginPath(); ctx.moveTo(halfW, 20); ctx.lineTo(halfW, H - 20); ctx.stroke()
      ctx.setLineDash([])

      // Product indicator
      const product = sigmaX * sigmaP
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'
      ctx.fillText(`σₓ·σₚ ≈ ${product.toFixed(2)} ≥ ℏ/2`, halfW - 50, H - 15)

      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const handleCalculate = () => {
    if (localSigmaX === "" || localSigmaP === "") {
      if (localSigmaX === "") setSigmaX("");
      if (localSigmaP === "") setSigmaP("");
      return;
    }

    let valX = parseFloat(localSigmaX)
    if (isNaN(valX)) valX = 0.4
    valX = Math.max(0.01, Math.min(5.0, valX))

    let valP = parseFloat(localSigmaP)
    if (isNaN(valP)) valP = 1.25
    valP = Math.max(0.01, Math.min(10.0, valP))

    setSigmaX(valX)
    setSigmaP(valP)
  }

  const handleReset = () => {
    setSigmaX(0.4)
    setSigmaP(1.25)
  }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(196,149,106,0.1)' }} />
      
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InputCardField label="Position Uncertainty σₓ" value={localSigmaX} min={0.01} max={5.0} step={0.01} onChange={setLocalSigmaX} unit="m" />
            <InputCardField label="Momentum Uncertainty σₚ" value={localSigmaP} min={0.01} max={10.0} step={0.01} onChange={setLocalSigmaP} unit="kg·m/s" />
          </div>
          
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalculate} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#C4956A', color: '#141210' }}>
              Calculate
            </button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">
              Reset
            </button>
          </div>
        </div>
      </WorkspacePortal>

      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="uncertainty" params={{ position: sigmaX, momentum: sigmaP }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Pos. Uncertainty (σₓ):</span>
            <span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${sigmaX.toFixed(3)} m` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Mom. Uncertainty (σₚ):</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${sigmaP.toFixed(3)} kg·m/s` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Uncertainty Product:</span>
            <span className={`font-bold ${(!isPending && realism.isRealistic && sigmaX * sigmaP >= 0.5) ? 'text-[#E8C880]' : 'text-red-400'}`}>
              {(!isPending && realism.isRealistic) ? `${(sigmaX * sigmaP).toFixed(3)} ℏ ${sigmaX * sigmaP >= 0.5 ? "(≥ 0.50)" : "(Limit Violated!)"}` : "[Missing]"}
            </span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              σₓ · σₚ = {(!isPending && realism.isRealistic) ? `${sigmaX.toFixed(3)} · ${sigmaP.toFixed(3)} = ${(sigmaX * sigmaP).toFixed(3)} ℏ` : "[Missing]"}
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

function WaveSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [mode, setMode] = useState(() => getInitialParam(initialParams, 'frequency', 2))
  const [tension, setTension] = useState(() => getInitialParam(initialParams, 'waveSpeed', 2.0))
  const [amp, setAmp] = useState(() => {
    const v = getInitialParam(initialParams, 'amplitude', 35);
    return v === "" ? "" : (initialParams ? Math.max(5, Math.min(100, v * 35)) : v);
  })

  const [localMode, setLocalMode] = useState(mode)
  const [localTension, setLocalTension] = useState(tension)
  const [localAmp, setLocalAmp] = useState(amp)

  useEffect(() => {
    setLocalMode(mode)
    setLocalTension(tension)
    setLocalAmp(amp)
  }, [mode, tension, amp])

  const animRef = useRef()
  
  const isPending = mode === "" || tension === "" || amp === "";
  const realism = checkRealism('wave', isPending ? {} : { frequency: mode, waveSpeed: tension, amplitude: amp })

  const stateRef = useRef({ mode: 2, tension: 2.0, amp: 35, t: 0, isPending: false, isRealistic: true })
  useEffect(() => {
    stateRef.current = {
      ...stateRef.current,
      mode,
      tension,
      amp,
      isPending,
      isRealistic: realism.isRealistic
    }
  }, [mode, tension, amp, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const { mode, tension, amp } = stateRef.current
      stateRef.current.t += 0.025 * tension
      const t = stateRef.current.t
      ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
      ctx.strokeStyle = 'rgba(136,192,184,0.05)'; ctx.lineWidth = 1
      for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
      const L = W - 80, startX = 40, cy = H / 2
      ctx.strokeStyle = 'rgba(136,192,184,0.1)'; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(startX, cy); ctx.lineTo(startX + L, cy); ctx.stroke()
      ctx.beginPath(); ctx.lineWidth = 2.8; ctx.strokeStyle = '#88C0B8'
      for (let x = 0; x <= L; x++) {
        const y = amp * Math.sin(mode * Math.PI * (x / L)) * Math.cos(t)
        if (x === 0) ctx.moveTo(startX + x, cy + y); else ctx.lineTo(startX + x, cy + y)
      }
      ctx.stroke()
      ctx.fillStyle = '#88C0B8'
      ctx.beginPath(); ctx.arc(startX, cy, 5, 0, Math.PI * 2); ctx.fill()
      ctx.beginPath(); ctx.arc(startX + L, cy, 5, 0, Math.PI * 2); ctx.fill()
      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const handleCalculate = () => {
    if (localMode === "" || localTension === "" || localAmp === "") {
      if (localMode === "") setMode("");
      if (localTension === "") setTension("");
      if (localAmp === "") setAmp("");
      return;
    }

    let parsedMode = parseInt(localMode)
    if (isNaN(parsedMode)) parsedMode = 2
    parsedMode = Math.max(1, Math.min(24, parsedMode))

    let parsedTension = parseFloat(localTension)
    if (isNaN(parsedTension)) parsedTension = 2.0
    parsedTension = Math.max(0.1, Math.min(20.0, parsedTension))

    let parsedAmp = parseFloat(localAmp)
    if (isNaN(parsedAmp)) parsedAmp = 35
    parsedAmp = Math.max(1, Math.min(150, parsedAmp))

    setMode(parsedMode)
    setTension(parsedTension)
    setAmp(parsedAmp)
  }

  const handleReset = () => {
    setMode(2)
    setTension(2.0)
    setAmp(35)
  }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <InputCardField label="Harmonic n" value={localMode} min={1} max={24} step={1} onChange={setLocalMode} />
            <InputCardField label="Tension" value={localTension} min={0.1} max={20.0} step={0.1} onChange={setLocalTension} />
            <InputCardField label="Amplitude" value={localAmp} min={1} max={150} step={1} onChange={setLocalAmp} unit="px" />
          </div>
          
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalculate} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>
              Calculate
            </button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">
              Reset
            </button>
          </div>
        </div>
      </WorkspacePortal>

      <WorkspacePortal target="results">
        <RealismCheckCard equationId="wave" params={{ frequency: mode, waveSpeed: tension, amplitude: amp }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Standing Wave Mode:</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `n = ${mode} (Harmonic)` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Wave Speed (v ∝ √T):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${Math.sqrt(tension).toFixed(2)} units` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Max Displacement:</span>
            <span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${amp} px` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              v = √T/μ = √{tension.toFixed(1)} = {(!isPending && realism.isRealistic) ? `${Math.sqrt(tension).toFixed(2)} units` : "[Missing]"}
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

function NewtonSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [mass, setMass] = useState(() => getInitialParam(initialParams, 'mass', 2.0))
  const [force, setForce] = useState(() => getInitialParam(initialParams, 'force', 5.0))

  const [localMass, setLocalMass] = useState(mass)
  const [localForce, setLocalForce] = useState(force)

  useEffect(() => {
    setLocalMass(mass)
    setLocalForce(force)
  }, [mass, force])

  const animRef = useRef()
  
  const isPending = mass === "" || force === "";
  const realism = checkRealism('newton', isPending ? {} : { mass, force })

  const stateRef = useRef({ mass: 2.0, force: 5.0, t: 0, pos: 60, vel: 0, isPending: false, isRealistic: true })
  useEffect(() => {
    stateRef.current.mass = mass
    stateRef.current.force = force
    stateRef.current.isPending = isPending
    stateRef.current.isRealistic = realism.isRealistic
  }, [mass, force, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const { mass, force } = stateRef.current
      const a = force / mass
      stateRef.current.vel += a * 0.016
      stateRef.current.pos += stateRef.current.vel * 0.8
      if (stateRef.current.pos > W - 40) { stateRef.current.pos = 60; stateRef.current.vel = 0 }
      const px = stateRef.current.pos
      const cy = H / 2

      ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
      // Ground
      ctx.strokeStyle = 'rgba(136,192,184,0.12)'; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(30, cy + 40); ctx.lineTo(W - 30, cy + 40); ctx.stroke()
      // Dashes
      for (let x = 30; x < W - 30; x += 30) { ctx.beginPath(); ctx.moveTo(x, cy + 40); ctx.lineTo(x - 6, cy + 48); ctx.stroke() }
      // Box — scale mass visually so it doesn't blow up
      const boxSize = Math.max(12, Math.min(80, 18 + mass * 0.8))
      const g = ctx.createLinearGradient(px - boxSize / 2, cy + 40 - boxSize, px + boxSize / 2, cy + 40)
      g.addColorStop(0, '#88C0B8'); g.addColorStop(1, '#5A8A80')
      ctx.fillStyle = g
      ctx.beginPath()
      ctx.roundRect(px - boxSize / 2, cy + 40 - boxSize, boxSize, boxSize, 4)
      ctx.fill()
      // Force arrow — scale force visually
      const arrowLen = Math.max(15, Math.min(180, 10 + force * 0.5))
      ctx.strokeStyle = '#E07840'; ctx.lineWidth = 3
      ctx.beginPath(); ctx.moveTo(px + boxSize / 2 + 8, cy + 40 - boxSize / 2); ctx.lineTo(px + boxSize / 2 + 8 + arrowLen, cy + 40 - boxSize / 2); ctx.stroke()
      ctx.fillStyle = '#E07840'
      ctx.beginPath()
      ctx.moveTo(px + boxSize / 2 + 8 + arrowLen, cy + 40 - boxSize / 2 - 6)
      ctx.lineTo(px + boxSize / 2 + 18 + arrowLen, cy + 40 - boxSize / 2)
      ctx.lineTo(px + boxSize / 2 + 8 + arrowLen, cy + 40 - boxSize / 2 + 6)
      ctx.fill()
      // Labels
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'
      ctx.fillText(`a = ${a.toFixed(2)} m/s²`, 40, 30)
      ctx.fillText(`v = ${stateRef.current.vel.toFixed(1)} m/s`, 40, 50)
      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const handleCalculate = () => {
    if (localMass === "" || localForce === "") {
      if (localMass === "") setMass("");
      if (localForce === "") setForce("");
      return;
    }

    let parsedMass = parseFloat(localMass)
    if (isNaN(parsedMass)) parsedMass = 2.0
    parsedMass = Math.max(0.1, Math.min(100.0, parsedMass))

    let parsedForce = parseFloat(localForce)
    if (isNaN(parsedForce)) parsedForce = 5.0
    parsedForce = Math.max(0.1, Math.min(500.0, parsedForce))

    setMass(parsedMass)
    setForce(parsedForce)
  }

  const handleReset = () => {
    setMass(2.0)
    setForce(5.0)
    stateRef.current.pos = 60
    stateRef.current.vel = 0
  }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InputCardField label="Mass" value={localMass} min={0.1} max={100.0} step={0.1} onChange={setLocalMass} unit="kg" />
            <InputCardField label="Applied Force" value={localForce} min={0.1} max={500.0} step={0.1} onChange={setLocalForce} unit="N" />
          </div>
          
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalculate} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>
              Calculate
            </button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">
              Reset
            </button>
          </div>
        </div>
      </WorkspacePortal>

      <WorkspacePortal target="results">
        <RealismCheckCard equationId="newton" params={{ mass, force }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Mass (m):</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${mass.toFixed(1)} kg` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Applied Force (F):</span>
            <span className="font-bold text-[#E07840]">{(!isPending && realism.isRealistic) ? `${force.toFixed(1)} N` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Acceleration (a):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${(force / mass).toFixed(3)} m/s²` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              a = F / m = {(!isPending && realism.isRealistic) ? `${force.toFixed(1)} N / ${mass.toFixed(1)} kg = ${(force / mass).toFixed(3)} m/s²` : "[Missing]"}
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

function HeatSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [diffusivity, setDiffusivity] = useState(() => getInitialParam(initialParams, 'diffusivity', 0.4))
  const [x0, setX0] = useState(() => {
    const v = getInitialParam(initialParams, 'length', 0.5);
    return v === "" ? 0.5 : Math.max(0.1, Math.min(0.9, v));
  })

  const [localDiffusivity, setLocalDiffusivity] = useState(diffusivity)
  const [localX0, setLocalX0] = useState(x0)

  useEffect(() => {
    setLocalDiffusivity(diffusivity)
    setLocalX0(x0)
  }, [diffusivity, x0])

  const simTimeRef = useRef(0.1)
  const animRef = useRef()
  
  const isPending = diffusivity === "" || x0 === "";
  const realism = checkRealism('heat', isPending ? {} : { diffusivity, length: x0 })

  const stateRef = useRef({ diffusivity: 0.4, x0: 0.5, isPending: false, isRealistic: true })
  useEffect(() => { stateRef.current = { diffusivity, x0, isPending, isRealistic: realism.isRealistic } }, [diffusivity, x0, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const { diffusivity, x0 } = stateRef.current
      simTimeRef.current += diffusivity * 0.007
      if (simTimeRef.current > 8.0) simTimeRef.current = 0.12
      const simTime = simTimeRef.current
      ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
      ctx.strokeStyle = 'rgba(224,120,64,0.05)'; ctx.lineWidth = 1
      for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
      const L = W - 80, startX = 40, sigma = Math.sqrt(2 * diffusivity * simTime) * 40 + 10
      const maxVal = (130 / Math.sqrt(simTime)) * 0.22, centerPoint = x0 * L
      const tg = ctx.createLinearGradient(startX, 0, startX + L, 0)
      tg.addColorStop(0, 'rgba(224,120,64,0.4)'); tg.addColorStop(x0, '#E07840'); tg.addColorStop(1, 'rgba(224,120,64,0.4)')
      ctx.beginPath(); ctx.lineWidth = 2.8; ctx.strokeStyle = tg
      for (let x = 0; x <= L; x++) {
        const temp = maxVal * Math.exp(-Math.pow(x - centerPoint, 2) / (2 * sigma * sigma))
        const py = H - 40 - temp
        if (x === 0) ctx.moveTo(startX + x, py); else ctx.lineTo(startX + x, py)
      }
      ctx.stroke()
      const bg = ctx.createLinearGradient(startX, 0, startX + L, 0)
      for (let x = 0; x <= L; x += 10) {
        const temp = maxVal * Math.exp(-Math.pow(x - centerPoint, 2) / (2 * sigma * sigma))
        const i = Math.min(temp / 50, 1.0)
        bg.addColorStop(x / L, `rgba(${Math.round(20 + i * 210)},${Math.round(20 + i * 70)},20,${0.3 + i * 0.65})`)
      }
      ctx.fillStyle = bg; ctx.fillRect(startX, H - 24, L, 12)
      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const handleCalculate = () => {
    if (localDiffusivity === "") { setDiffusivity(""); return; }

    let parsedDiff = parseFloat(localDiffusivity)
    if (isNaN(parsedDiff)) parsedDiff = 0.4
    parsedDiff = Math.max(0.01, Math.min(5.0, parsedDiff))

    let parsedX0 = parseFloat(localX0)
    if (isNaN(parsedX0)) parsedX0 = 0.5
    parsedX0 = Math.max(0.05, Math.min(0.95, parsedX0))

    setDiffusivity(parsedDiff)
    setX0(parsedX0)
    simTimeRef.current = 0.12
  }

  const handleReset = () => {
    setDiffusivity(0.4)
    setX0(0.5)
    simTimeRef.current = 0.12
  }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(224,120,64,0.1)' }} />
      
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InputCardField label="Diffusivity α" value={localDiffusivity} min={0.01} max={5.0} step={0.01} onChange={setLocalDiffusivity} unit="m²/s" />
            <InputCardField label="Peak Position" value={localX0} min={0.05} max={0.95} step={0.01} onChange={setLocalX0} unit="frac" />
          </div>
          
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalculate} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#E07840', color: '#141210' }}>
              Calculate
            </button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">
              Reset
            </button>
          </div>
        </div>
      </WorkspacePortal>

      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="heat" params={{ diffusivity, length: x0 }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Thermal Diffusivity (α):</span>
            <span className="font-bold text-[#E07840]">{(!isPending && realism.isRealistic) ? `${diffusivity.toFixed(2)} m²/s` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Pulse Origin:</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${(x0 * 100).toFixed(0)}% width` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Thermal Dispersion σ:</span>
            <span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? "Expanding Field" : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              σ = √(2 · α · t) = {(!isPending && realism.isRealistic) ? `√(2 · ${diffusivity.toFixed(2)} · t)` : "[Missing]"}
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

function EntropySimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [temp, setTemp] = useState(() => getInitialParam(initialParams, 'temperature', 300))
  const [particleCount, setParticleCount] = useState(60)

  const [localTemp, setLocalTemp] = useState(temp)
  const [localParticleCount, setLocalParticleCount] = useState(particleCount)

  useEffect(() => {
    setLocalTemp(temp)
    setLocalParticleCount(particleCount)
  }, [temp, particleCount])

  const animRef = useRef()
  const particlesRef = useRef([])
  
  const isPending = temp === "" || particleCount === "";
  const realism = checkRealism('entropy', isPending ? {} : { temp })

  const stateRef = useRef({ temp: 300, particleCount: 60, isPending: false, isRealistic: true })
  useEffect(() => { stateRef.current = { temp, particleCount, isPending, isRealistic: realism.isRealistic } }, [temp, particleCount, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)

    // Init particles in an ordered grid (low entropy)
    const initParticles = (count) => {
      const arr = []
      const cols = Math.ceil(Math.sqrt(count))
      const rows = Math.ceil(count / cols)
      for (let i = 0; i < count; i++) {
        const col = i % cols, row = Math.floor(i / cols)
        arr.push({
          x: W * 0.25 + (col / cols) * W * 0.5,
          y: H * 0.15 + (row / rows) * H * 0.7,
          vx: 0, vy: 0,
        })
      }
      return arr
    }
    particlesRef.current = initParticles(particleCount)

    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const { temp } = stateRef.current
      const speed = temp / 400
      ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
      // Walls
      ctx.strokeStyle = 'rgba(224,120,64,0.15)'; ctx.lineWidth = 1.5
      ctx.strokeRect(30, 20, W - 60, H - 40)

      particlesRef.current.forEach(p => {
        p.vx += (Math.random() - 0.5) * speed * 0.6
        p.vy += (Math.random() - 0.5) * speed * 0.6
        p.vx *= 0.98; p.vy *= 0.98
        p.x += p.vx; p.y += p.vy
        if (p.x < 35) { p.x = 35; p.vx *= -0.8 }
        if (p.x > W - 35) { p.x = W - 35; p.vx *= -0.8 }
        if (p.y < 25) { p.y = 25; p.vy *= -0.8 }
        if (p.y > H - 25) { p.y = H - 25; p.vy *= -0.8 }
        const spd = Math.sqrt(p.vx * p.vx + p.vy * p.vy)
        const t = Math.min(spd / 3, 1)
        const r = Math.round(224 * t + 100 * (1 - t))
        const g = Math.round(120 * t + 80 * (1 - t))
        const b = Math.round(64 * t + 50 * (1 - t))
        ctx.fillStyle = `rgba(${r},${g},${b},0.8)`
        ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI * 2); ctx.fill()
      })

      // Legend / Disorder label
      const avgSpread = particlesRef.current.reduce((s, p) => s + Math.abs(p.vx) + Math.abs(p.vy), 0) / particlesRef.current.length
      ctx.fillStyle = 'rgba(220,200,165,0.5)'; ctx.font = '12px var(--font-body)'
      ctx.fillText(`Disorder ≈ ${avgSpread.toFixed(2)}`, 40, H - 8)
      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [particleCount])

  const handleCalculate = () => {
    if (localTemp === "") { setTemp(""); return; }

    let parsedTemp = parseFloat(localTemp)
    if (isNaN(parsedTemp)) parsedTemp = 300
    parsedTemp = Math.max(5, Math.min(5000, parsedTemp))

    let parsedCount = parseInt(localParticleCount)
    if (isNaN(parsedCount)) parsedCount = 60
    parsedCount = Math.max(5, Math.min(500, parsedCount))

    setTemp(parsedTemp)
    setParticleCount(parsedCount)
  }

  const handleReset = () => {
    setTemp(300)
    setParticleCount(60)
  }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(224,120,64,0.1)' }} />
      
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InputCardField label="Temperature" value={localTemp} min={5} max={5000} step={5} onChange={setLocalTemp} unit="K" />
            <InputCardField label="Particles" value={localParticleCount} min={5} max={500} step={5} onChange={setLocalParticleCount} />
          </div>
          
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalculate} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#E07840', color: '#141210' }}>
              Calculate
            </button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">
              Reset
            </button>
          </div>
        </div>
      </WorkspacePortal>

      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="entropy" params={{ temp }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Temperature (T):</span>
            <span className="font-bold text-[#E07840]">{(!isPending && realism.isRealistic) ? `${temp} K` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">System Particles (N):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? particleCount : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Entropy Coefficient:</span>
            <span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${(particleCount * Math.log(temp || 1) * 0.1).toFixed(1)} J/K` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              S = k_B ln(Ω) ≈ {(!isPending && realism.isRealistic) ? `${particleCount} · k_B ln(${temp}) = ${(particleCount * Math.log(temp || 1) * 0.1).toFixed(1)} J/K` : "[Missing]"}
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

function FluidSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [viscosity, setViscosity] = useState(() => getInitialParam(initialParams, 'viscosity', 0.4))
  const [velocity, setVelocity] = useState(() => getInitialParam(initialParams, 'velocity', 2.0))

  const [localViscosity, setLocalViscosity] = useState(viscosity)
  const [localVelocity, setLocalVelocity] = useState(velocity)

  useEffect(() => {
    setLocalViscosity(viscosity)
    setLocalVelocity(velocity)
  }, [viscosity, velocity])

  const animRef = useRef()
  
  const isPending = viscosity === "" || velocity === "";
  const realism = checkRealism('navier', isPending ? {} : { viscosity, velocity })

  const stateRef = useRef({ viscosity: 0.4, velocity: 2.0, t: 0, isPending: false, isRealistic: true })
  useEffect(() => { stateRef.current = { ...stateRef.current, viscosity, velocity, isPending, isRealistic: realism.isRealistic } }, [viscosity, velocity, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    const cx = W * 0.35, cy = H / 2, R = 30
    const particles = Array.from({ length: 260 }, () => ({ x: Math.random() * W, y: Math.random() * H, age: Math.random() * 150 }))
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const { viscosity, velocity } = stateRef.current
      stateRef.current.t += 1; const t = stateRef.current.t
      ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
      const cg = ctx.createRadialGradient(cx - R * 0.3, cy - R * 0.3, R * 0.1, cx, cy, R)
      cg.addColorStop(0, '#4A4440'); cg.addColorStop(1, '#28221E')
      ctx.fillStyle = cg; ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fill()
      ctx.strokeStyle = 'rgba(136,192,184,0.2)'; ctx.lineWidth = 1.5; ctx.stroke()
      particles.forEach(p => {
        p.age += 1
        const dx = p.x - cx, dy = p.y - cy, rSq = dx * dx + dy * dy, r = Math.sqrt(rSq)
        let vx = velocity, vy = 0
        if (rSq > R * R) {
          const cosT = dx / r, sinT = dy / r
          const ur = velocity * (1 - (R * R) / rSq) * cosT
          const ut = -velocity * (1 + (R * R) / rSq) * sinT
          vx = ur * cosT - ut * sinT; vy = ur * sinT + ut * cosT
          if (dx > 0) { const wake = (1.0 - viscosity) * 5.0 * (dx / W); vy += wake * Math.cos(0.07 * dx - t * 0.18 * velocity) * Math.exp(-dx * 0.004) }
        } else { p.x = cx - R - Math.random() * 20; p.y = cy + (Math.random() - 0.5) * 40 }
        p.x += vx; p.y += vy
        if (p.x > W || p.age > 200) { p.x = 0; p.y = Math.random() * H; p.age = 0 }
        const spd = Math.sqrt(vx * vx + vy * vy) / (velocity * 1.5)
        ctx.fillStyle = `rgba(136,192,184,${0.35 + spd * 0.55})`
        ctx.beginPath(); ctx.arc(p.x, p.y, 1.8, 0, Math.PI * 2); ctx.fill()
      })
      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const handleCalculate = () => {
    if (localViscosity === "" || localVelocity === "") {
      if (localViscosity === "") setViscosity("");
      if (localVelocity === "") setVelocity("");
      return;
    }

    let parsedVisc = parseFloat(localViscosity)
    if (isNaN(parsedVisc)) parsedVisc = 0.4
    parsedVisc = Math.max(0.01, Math.min(5.0, parsedVisc))

    let parsedVel = parseFloat(localVelocity)
    if (isNaN(parsedVel)) parsedVel = 2.0
    parsedVel = Math.max(0.1, Math.min(20.0, parsedVel))

    setViscosity(parsedVisc)
    setVelocity(parsedVel)
  }

  const handleReset = () => {
    setViscosity(0.4)
    setVelocity(2.0)
  }

  const reynolds = (velocity * 120) / (viscosity + 0.05)

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InputCardField label="Viscosity μ" value={localViscosity} min={0.01} max={5.0} step={0.01} onChange={setLocalViscosity} unit="Pa·s" />
            <InputCardField label="Flow Velocity" value={localVelocity} min={0.1} max={20.0} step={0.1} onChange={setLocalVelocity} unit="m/s" />
          </div>
          
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalculate} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>
              Calculate
            </button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">
              Reset
            </button>
          </div>
        </div>
      </WorkspacePortal>

      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="navier" params={{ viscosity, velocity }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Flow Velocity (u):</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${velocity.toFixed(1)} m/s` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Viscosity Coefficient (μ):</span>
            <span className="font-bold text-[#E07840]">{(!isPending && realism.isRealistic) ? `${viscosity.toFixed(2)} Pa·s` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Reynolds Number (Re):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${reynolds.toFixed(0)} (${reynolds > 1000 ? "Turbulent" : "Laminar"})` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              Re = ρ u L / μ = {(!isPending && realism.isRealistic) ? `(1 · ${velocity.toFixed(1)} · 120) / (${viscosity.toFixed(2)} + 0.05) = ${reynolds.toFixed(0)}` : "[Missing]"}
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

function ContinuitySimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [pipeRatio, setPipeRatio] = useState(() => getInitialParam(initialParams, 'pipeRatio', 0.5))

  const [localPipeRatio, setLocalPipeRatio] = useState(pipeRatio)

  useEffect(() => {
    setLocalPipeRatio(pipeRatio)
  }, [pipeRatio])

  const animRef = useRef()
  
  const isPending = pipeRatio === "";
  const realism = checkRealism('continuity', isPending ? {} : { pipeRatio })

  const stateRef = useRef({ pipeRatio: 0.5, t: 0, isPending: false, isRealistic: true })
  useEffect(() => { stateRef.current.pipeRatio = pipeRatio; stateRef.current.isPending = isPending; stateRef.current.isRealistic = realism.isRealistic }, [pipeRatio, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    const particles = Array.from({ length: 80 }, () => ({ x: Math.random() * W, phase: Math.random() }))

    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const { pipeRatio } = stateRef.current
      stateRef.current.t += 0.015
      ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)

      const cy = H / 2, r1 = 70, r2 = r1 * pipeRatio
      const neckStart = W * 0.4, neckEnd = W * 0.6

      // Pipe outline
      ctx.beginPath()
      ctx.moveTo(20, cy - r1)
      ctx.lineTo(neckStart, cy - r1)
      ctx.bezierCurveTo(neckStart + 30, cy - r1, neckStart + 30, cy - r2, (neckStart + neckEnd) / 2, cy - r2)
      ctx.bezierCurveTo(neckEnd - 30, cy - r2, neckEnd - 30, cy - r1, neckEnd, cy - r1)
      ctx.lineTo(W - 20, cy - r1)
      ctx.strokeStyle = 'rgba(136,192,184,0.3)'; ctx.lineWidth = 2; ctx.stroke()

      ctx.beginPath()
      ctx.moveTo(20, cy + r1)
      ctx.lineTo(neckStart, cy + r1)
      ctx.bezierCurveTo(neckStart + 30, cy + r1, neckStart + 30, cy + r2, (neckStart + neckEnd) / 2, cy + r2)
      ctx.bezierCurveTo(neckEnd - 30, cy + r2, neckEnd - 30, cy + r1, neckEnd, cy + r1)
      ctx.lineTo(W - 20, cy + r1)
      ctx.stroke()

      // Particles flowing through
      particles.forEach(p => {
        let localR, speed
        if (p.x < neckStart) {
          localR = r1; speed = 1
        } else if (p.x > neckEnd) {
          localR = r1; speed = 1
        } else {
          const t = (p.x - neckStart) / (neckEnd - neckStart)
          const s = Math.sin(t * Math.PI)
          localR = r1 - (r1 - r2) * s
          speed = (r1 * r1) / (localR * localR)
        }
        p.x += speed * 1.5
        if (p.x > W) { p.x = 10; p.phase = Math.random() }
        const yOff = (p.phase - 0.5) * 2 * (localR - 8)
        const alpha = Math.min(speed / 3, 1) * 0.7 + 0.3
        ctx.fillStyle = `rgba(136,192,184,${alpha})`
        ctx.beginPath(); ctx.arc(p.x, cy + yOff, 3, 0, Math.PI * 2); ctx.fill()
      })

      ctx.fillStyle = 'rgba(220,200,165,0.45)'; ctx.font = '12px var(--font-body)'
      ctx.fillText('A₁v₁ = A₂v₂', W / 2 - 35, 25)

      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const handleCalculate = () => {
    if (localPipeRatio === "") { setPipeRatio(""); return; }

    let parsedRatio = parseFloat(localPipeRatio)
    if (isNaN(parsedRatio)) parsedRatio = 0.5
    parsedRatio = Math.max(0.05, Math.min(0.95, parsedRatio))
    setPipeRatio(parsedRatio)
  }

  const handleReset = () => {
    setPipeRatio(0.5)
  }

  const speedup = 1 / (pipeRatio * pipeRatio)

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(136,192,184,0.1)' }} />
      
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 gap-4">
            <InputCardField label="Constriction Ratio" value={localPipeRatio} min={0.05} max={0.95} step={0.01} onChange={setLocalPipeRatio} unit="ratio" />
          </div>
          
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalculate} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#88C0B8', color: '#141210' }}>
              Calculate
            </button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">
              Reset
            </button>
          </div>
        </div>
      </WorkspacePortal>

      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="continuity" params={{ pipeRatio }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Inlet Area (A₁):</span>
            <span className="font-bold text-[#E8C880]">100%</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Neck Area (A₂):</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${(pipeRatio * 100).toFixed(0)}%` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Velocity Ratio (v₂/v₁):</span>
            <span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${speedup.toFixed(2)}× speedup` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              v₂ = v₁ · (A₁ / A₂) = {(!isPending && realism.isRealistic) ? `v₁ · (1.0 / ${pipeRatio.toFixed(2)}) = ${speedup.toFixed(2)} · v₁` : "[Missing]"}
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

function ElectricFieldSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [charge, setCharge] = useState(() => getInitialParam(initialParams, 'charge', 3))

  const [localCharge, setLocalCharge] = useState(charge)

  useEffect(() => {
    setLocalCharge(charge)
  }, [charge])

  const animRef = useRef()
  
  const isPending = charge === "";
  const realism = checkRealism('maxwell1', isPending ? {} : { charge })

  const stateRef = useRef({ charge: 3, t: 0, isPending: false, isRealistic: true })
  useEffect(() => { stateRef.current.charge = charge; stateRef.current.isPending = isPending; stateRef.current.isRealistic = realism.isRealistic }, [charge, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      stateRef.current.t += 0.015
      const { charge, t } = stateRef.current
      ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)

      const cx = W / 2, cy = H / 2

      // Field lines radiating from center
      const numLines = 12
      for (let i = 0; i < numLines; i++) {
        const angle = (i / numLines) * Math.PI * 2
        ctx.beginPath()
        ctx.strokeStyle = 'rgba(160,156,200,0.25)'; ctx.lineWidth = 1.5
        const maxR = 150
        for (let r = 20; r < maxR; r += 2) {
          const px = cx + Math.cos(angle) * r
          const py = cy + Math.sin(angle) * r
          if (r === 20) ctx.moveTo(px, py); else ctx.lineTo(px, py)
        }
        ctx.stroke()
        // Animated dots along field lines
        const dotR = ((t * 40 * charge) % maxR) + 20
        if (dotR < maxR) {
          const dx = cx + Math.cos(angle) * dotR
          const dy = cy + Math.sin(angle) * dotR
          ctx.fillStyle = '#A09CC8'
          ctx.beginPath(); ctx.arc(dx, dy, 3, 0, Math.PI * 2); ctx.fill()
        }
      }

      // Central charge
      const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, 18)
      cg.addColorStop(0, '#A09CC8'); cg.addColorStop(1, 'rgba(160,156,200,0.1)')
      ctx.fillStyle = cg; ctx.beginPath(); ctx.arc(cx, cy, 18, 0, Math.PI * 2); ctx.fill()
      ctx.fillStyle = '#fff'; ctx.font = 'bold 16px var(--font-display)'; ctx.textAlign = 'center'
      ctx.fillText('+', cx, cy + 6); ctx.textAlign = 'start'

      // Equipotential circles
      for (let r = 1; r <= 3; r++) {
        ctx.strokeStyle = `rgba(160,156,200,${0.06 + r * 0.02})`; ctx.lineWidth = 0.8
        ctx.setLineDash([3, 5])
        ctx.beginPath(); ctx.arc(cx, cy, 30 + r * 35, 0, Math.PI * 2); ctx.stroke()
        ctx.setLineDash([])
      }

      ctx.fillStyle = 'rgba(220,200,165,0.4)'; ctx.font = '12px var(--font-body)'
      ctx.fillText(`Q = ${charge}e`, 40, 25)
      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const handleCalculate = () => {
    if (localCharge === "") { setCharge(""); return; }

    let parsedCharge = parseFloat(localCharge)
    if (isNaN(parsedCharge)) parsedCharge = 3.0
    parsedCharge = Math.max(0.1, Math.min(50.0, parsedCharge))
    setCharge(parsedCharge)
  }

  const handleReset = () => {
    setCharge(3)
  }

  const flux = charge / 8.85

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(160,156,200,0.1)' }} />
      
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 gap-4">
            <InputCardField label="Charge Q" value={localCharge} min={0.1} max={50.0} step={0.1} onChange={setLocalCharge} unit="e" />
          </div>
          
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalculate} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#A09CC8', color: '#141210' }}>
              Calculate
            </button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">
              Reset
            </button>
          </div>
        </div>
      </WorkspacePortal>
<WorkspacePortal target="results">
        <RealismCheckCard equationId="maxwell1" params={{ charge }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Charge magnitude (Q):</span>
            <span className="font-bold text-[#A09CC8]">{(!isPending && realism.isRealistic) ? `${charge.toFixed(1)} e` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Electric Flux (Φ_E):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${flux.toFixed(3)} units` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Divergence ∇·E:</span>
            <span className="font-bold text-[#C4956A]">Positive ({(!isPending && realism.isRealistic) ? charge.toFixed(1) : "[Missing]"})</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              ∯ E · dA = Q / ε₀ = {(!isPending && realism.isRealistic) ? `${charge.toFixed(1)} / 8.85 = ${flux.toFixed(3)} units` : "[Missing]"}
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

function FaradaySimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [bField, setBField] = useState(() => getInitialParam(initialParams, 'bField', 2.0))
  const [freq, setFreq] = useState(() => getInitialParam(initialParams, 'freq', 1.5))

  const [localBField, setLocalBField] = useState(bField)
  const [localFreq, setLocalFreq] = useState(freq)

  useEffect(() => {
    setLocalBField(bField)
    setLocalFreq(freq)
  }, [bField, freq])

  const animRef = useRef()
  
  const isPending = bField === "" || freq === "";
  const realism = checkRealism('faraday', isPending ? {} : { bField, freq })

  const stateRef = useRef({ bField: 2, freq: 1.5, t: 0, isPending: false, isRealistic: true })
  useEffect(() => { stateRef.current.bField = bField; stateRef.current.freq = freq; stateRef.current.isPending = isPending; stateRef.current.isRealistic = realism.isRealistic }, [bField, freq, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const { bField, freq } = stateRef.current
      stateRef.current.t += 0.02 * freq
      const t = stateRef.current.t
      ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)

      const cx = W / 2, cy = H / 2

      // Magnetic field (B) — blue sinusoid on left
      ctx.beginPath(); ctx.lineWidth = 2.5; ctx.strokeStyle = '#6A8EC4'
      for (let x = 40; x < cx - 20; x++) {
        const y = cy + Math.min(100, bField * 15) * Math.sin(x * 0.03 + t)
        if (x === 40) ctx.moveTo(x, y); else ctx.lineTo(x, y)
      }
      ctx.stroke()
      ctx.fillStyle = '#6A8EC4'; ctx.font = '13px var(--font-display)'; ctx.fillText('B-field', 50, 30)

      // Induced E-field (orange) on right
      const emf = -bField * freq * Math.cos(t) // ∇×E = -∂B/∂t
      ctx.beginPath(); ctx.lineWidth = 2.5; ctx.strokeStyle = '#A09CC8'
      for (let x = cx + 20; x < W - 40; x++) {
        const y = cy + Math.max(-100, Math.min(100, emf * 12)) * Math.sin(x * 0.03 - t * 0.8)
        if (x === cx + 20) ctx.moveTo(x, y); else ctx.lineTo(x, y)
      }
      ctx.stroke()
      ctx.fillStyle = '#A09CC8'; ctx.fillText('Induced E-field', cx + 30, 30)

      // Divider
      ctx.strokeStyle = 'rgba(160,156,200,0.15)'; ctx.setLineDash([4, 4])
      ctx.beginPath(); ctx.moveTo(cx, 20); ctx.lineTo(cx, H - 20); ctx.stroke()
      ctx.setLineDash([])

      // EMF value
      ctx.fillStyle = 'rgba(220,200,165,0.45)'; ctx.font = '12px var(--font-body)'
      ctx.fillText(`EMF ∝ -∂B/∂t ≈ ${emf.toFixed(2)}`, cx - 60, H - 15)

      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const handleCalculate = () => {
    if (localBField === "" || localFreq === "") {
      if (localBField === "") setBField("");
      if (localFreq === "") setFreq("");
      return;
    }

    let parsedB = parseFloat(localBField)
    if (isNaN(parsedB)) parsedB = 2.0
    parsedB = Math.max(0.1, Math.min(20.0, parsedB))

    let parsedFreq = parseFloat(localFreq)
    if (isNaN(parsedFreq)) parsedFreq = 1.5
    parsedFreq = Math.max(0.1, Math.min(15.0, parsedFreq))

    setBField(parsedB)
    setFreq(parsedFreq)
  }

  const handleReset = () => {
    setBField(2.0)
    setFreq(1.5)
  }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(160,156,200,0.1)' }} />
      
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <InputCardField label="B-Field Strength" value={localBField} min={0.1} max={20.0} step={0.1} onChange={setLocalBField} unit="T" />
            <InputCardField label="Frequency" value={localFreq} min={0.1} max={15.0} step={0.1} onChange={setLocalFreq} unit="Hz" />
          </div>
          
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalculate} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#6A8EC4', color: '#141210' }}>
              Calculate
            </button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">
              Reset
            </button>
          </div>
        </div>
      </WorkspacePortal>

      <WorkspacePortal target="results">
        <RealismCheckCard equationId="faraday" params={{ bField, freq }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Magnetic Field (B₀):</span>
            <span className="font-bold text-[#6A8EC4]">{(!isPending && realism.isRealistic) ? `${bField.toFixed(2)} T` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Flux Frequency (f):</span>
            <span className="font-bold text-[#A09CC8]">{(!isPending && realism.isRealistic) ? `${freq.toFixed(2)} Hz` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Max Induced EMF (V_emf):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${(bField * freq).toFixed(2)} V` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              ℰ_max = B₀ · f = {(!isPending && realism.isRealistic) ? `${bField.toFixed(1)} T · ${freq.toFixed(1)} Hz = ${(bField * freq).toFixed(2)} V` : "[Missing]"}
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

function LorentzSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [velocity, setVelocity] = useState(() => {
    const val = getInitialParam(initialParams, 'velocity', 0.3)
    if (initialParams && typeof val === 'number' && val > 1.1) {
      return val / 299792458
    }
    return val
  })

  const [localVelocity, setLocalVelocity] = useState(velocity)

  useEffect(() => {
    setLocalVelocity(velocity)
  }, [velocity])

  const animRef = useRef()
  
  const isPending = velocity === "";
  const realism = checkRealism('lorentz', isPending ? {} : { velocity })

  const stateRef = useRef({ velocity: 0.3, isPending: false, isRealistic: true })
  useEffect(() => { stateRef.current.velocity = velocity; stateRef.current.isPending = isPending; stateRef.current.isRealistic = realism.isRealistic }, [velocity, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const { velocity: v } = stateRef.current
      ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)

      const gamma = 1 / Math.sqrt(1 - v * v)
      const cx = W / 2, cy = H / 2

      // Rest frame clock (left)
      const restR = 60
      ctx.strokeStyle = 'rgba(196,149,106,0.3)'; ctx.lineWidth = 2
      ctx.beginPath(); ctx.arc(cx - 180, cy, restR, 0, Math.PI * 2); ctx.stroke()
      ctx.fillStyle = '#C4956A'; ctx.font = '12px var(--font-display)'; ctx.textAlign = 'center'
      ctx.fillText('Rest Frame', cx - 180, cy + restR + 22)
      ctx.fillText('t = 1.00s', cx - 180, cy + restR + 40)
      // Clock hand
      const rAngle = (Date.now() * 0.001) % (Math.PI * 2)
      ctx.strokeStyle = '#C4956A'; ctx.lineWidth = 2
      ctx.beginPath(); ctx.moveTo(cx - 180, cy)
      ctx.lineTo(cx - 180 + Math.cos(rAngle - Math.PI / 2) * (restR - 10), cy + Math.sin(rAngle - Math.PI / 2) * (restR - 10))
      ctx.stroke()

      // Moving frame clock (right) — runs slower by gamma
      ctx.strokeStyle = 'rgba(136,192,184,0.3)'; ctx.lineWidth = 2
      const movR = restR / gamma // Length contraction visual
      ctx.save()
      ctx.translate(cx + 180, cy)
      ctx.scale(1 / gamma, 1)
      ctx.beginPath(); ctx.arc(0, 0, restR, 0, Math.PI * 2); ctx.stroke()
      ctx.restore()
      ctx.fillStyle = '#88C0B8'; ctx.font = '12px var(--font-display)'
      ctx.fillText('Moving Frame', cx + 180, cy + restR + 22)
      ctx.fillText(`t′ = ${(1 / gamma).toFixed(3)}s`, cx + 180, cy + restR + 40)
      // Slower clock hand
      const mAngle = (Date.now() * 0.001 / gamma) % (Math.PI * 2)
      ctx.strokeStyle = '#88C0B8'; ctx.lineWidth = 2
      ctx.beginPath(); ctx.moveTo(cx + 180, cy)
      ctx.lineTo(cx + 180 + Math.cos(mAngle - Math.PI / 2) * (restR - 10) / gamma, cy + Math.sin(mAngle - Math.PI / 2) * (restR - 10))
      ctx.stroke()

      // Gamma display
      ctx.fillStyle = '#E8DDCC'; ctx.font = 'bold 28px var(--font-display)'
      ctx.fillText(`γ = ${gamma.toFixed(4)}`, cx, 40)
      ctx.fillStyle = 'rgba(220,200,165,0.4)'; ctx.font = '13px var(--font-body)'
      ctx.fillText(`v = ${(v * 100).toFixed(0)}% c`, cx, 65)
      ctx.textAlign = 'start'

      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const handleCalculate = () => {
    if (localVelocity === "") { setVelocity(""); return; }

    let parsedV = parseFloat(localVelocity)
    if (isNaN(parsedV)) parsedV = 0.3
    parsedV = Math.max(0.001, Math.min(0.999, parsedV))
    setVelocity(parsedV)
  }

  const handleReset = () => {
    setVelocity(0.3)
  }

  const gamma = 1 / Math.sqrt(1 - velocity * velocity)
  const dilation = 100 * (1 - Math.sqrt(1 - velocity * velocity))

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(196,149,106,0.1)' }} />
      
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 gap-4">
            <InputCardField label="Velocity (fraction of c)" value={localVelocity} min={0.001} max={0.999} step={0.001} onChange={setLocalVelocity} unit="c" />
          </div>
          
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalculate} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#C4956A', color: '#141210' }}>
              Calculate
            </button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">
              Reset
            </button>
          </div>
        </div>
      </WorkspacePortal>

      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="lorentz" params={{ velocity }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Velocity (v/c):</span>
            <span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${(velocity * 100).toFixed(1)}% c` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Lorentz Factor (γ):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? gamma.toFixed(4) : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Time Dilation Factor:</span>
            <span className="font-bold text-[#88C0B8]">{(!isPending && realism.isRealistic) ? `${dilation.toFixed(2)}% slower` : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              γ = 1 / √(1 - v²/c²) = {(!isPending && realism.isRealistic) ? `1 / √(1 - ${velocity.toFixed(3)}²) = ${gamma.toFixed(4)}` : "[Missing]"}
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

function MassEnergySimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [mass, setMass] = useState(() => getInitialParam(initialParams, 'mass', 1.0))
  const [localMass, setLocalMass] = useState(mass)

  useEffect(() => { setLocalMass(mass) }, [mass])

  const animRef = useRef()
  
  const isPending = mass === "";
  const realism = checkRealism('einstein', isPending ? {} : { mass })

  const stateRef = useRef({ mass: 1.0, t: 0, photons: [], isPending: false, isRealistic: true })
  useEffect(() => { stateRef.current.mass = mass; stateRef.current.isPending = isPending; stateRef.current.isRealistic = realism.isRealistic }, [mass, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 400
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)

    // Initialize photons
    stateRef.current.photons = Array.from({ length: 20 }, () => ({
      angle: Math.random() * Math.PI * 2,
      speed: 1 + Math.random() * 2,
      dist: 0, alpha: 0, active: false,
    }))

    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      stateRef.current.t += 0.015
      const { mass: m, t, photons } = stateRef.current
      const c = 299792458
      const E = m * c * c
      const cycleLen = 6 // seconds per cycle
      const phase = (t % cycleLen) / cycleLen // 0-1

      ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)

      const cx = W / 2 - 80, cy = H / 2
      const baseMassR = 20 + Math.log(m + 1) * 18

      // Phase: 0-0.4 shrinking, 0.4-0.6 burst, 0.6-1.0 reform
      let massR, conversionFrac
      if (phase < 0.4) {
        conversionFrac = phase / 0.4
        massR = baseMassR * (1 - conversionFrac * 0.7)
      } else if (phase < 0.6) {
        conversionFrac = 1
        massR = baseMassR * 0.3
      } else {
        conversionFrac = 1 - (phase - 0.6) / 0.4
        massR = baseMassR * (0.3 + (1 - conversionFrac) * 0.7)
      }

      // Expanding radiation rings (during conversion)
      if (phase > 0.15 && phase < 0.8) {
        const numRings = 4
        for (let i = 0; i < numRings; i++) {
          const ringPhase = ((phase - 0.15) * 3 + i * 0.3) % 1.5
          if (ringPhase < 1.2) {
            const ringR = 20 + ringPhase * 120
            const ringAlpha = Math.max(0, 0.25 - ringPhase * 0.2)
            ctx.strokeStyle = `rgba(232,200,128,${ringAlpha})`
            ctx.lineWidth = 2 - ringPhase * 1.2
            ctx.beginPath(); ctx.arc(cx, cy, ringR, 0, Math.PI * 2); ctx.stroke()
          }
        }
      }

      // Photon burst particles
      if (phase > 0.3 && phase < 0.65) {
        for (const p of photons) {
          if (!p.active && Math.random() < 0.08) {
            p.active = true; p.dist = 0; p.alpha = 0.8
            p.angle = Math.random() * Math.PI * 2
            p.speed = 1.5 + Math.random() * 2.5
          }
          if (p.active) {
            p.dist += p.speed; p.alpha *= 0.97
            const px = cx + Math.cos(p.angle) * p.dist
            const py = cy + Math.sin(p.angle) * p.dist
            if (p.alpha > 0.05 && px > 10 && px < W - 10 && py > 10 && py < H - 10) {
              ctx.fillStyle = `rgba(232,200,128,${p.alpha})`
              ctx.beginPath(); ctx.arc(px, py, 2, 0, Math.PI * 2); ctx.fill()
              // Tiny trail
              ctx.strokeStyle = `rgba(232,200,128,${p.alpha * 0.3})`; ctx.lineWidth = 0.8
              ctx.beginPath()
              ctx.moveTo(px, py)
              ctx.lineTo(px - Math.cos(p.angle) * 6, py - Math.sin(p.angle) * 6)
              ctx.stroke()
            } else {
              p.active = false
            }
          }
        }
      } else {
        for (const p of photons) p.active = false
      }

      // Mass sphere with conversion effect
      const mg = ctx.createRadialGradient(cx - massR * 0.2, cy - massR * 0.2, 0, cx, cy, massR)
      mg.addColorStop(0, '#d4a870')
      mg.addColorStop(0.6, '#C4956A')
      mg.addColorStop(1, conversionFrac > 0.3 ? `rgba(232,200,128,${conversionFrac * 0.4})` : 'rgba(196,149,106,0.2)')
      ctx.fillStyle = mg; ctx.beginPath(); ctx.arc(cx, cy, massR, 0, Math.PI * 2); ctx.fill()

      // Conversion glow
      if (conversionFrac > 0.2) {
        const glowR = massR + 10 + conversionFrac * 20
        const gg = ctx.createRadialGradient(cx, cy, massR, cx, cy, glowR)
        gg.addColorStop(0, `rgba(232,200,128,${conversionFrac * 0.2})`)
        gg.addColorStop(1, 'rgba(232,200,128,0)')
        ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(cx, cy, glowR, 0, Math.PI * 2); ctx.fill()
      }

      // Mass label
      const displayMass = m * (1 - conversionFrac * 0.7)
      ctx.fillStyle = '#E8DDCC'; ctx.font = '13px var(--font-display)'; ctx.textAlign = 'center'
      ctx.fillText(`${displayMass.toFixed(3)} kg`, cx, cy + massR + 25)

      // Arrow
      const arrowStart = cx + baseMassR + 30
      const energyX = W / 2 + 120
      ctx.strokeStyle = 'rgba(220,200,165,0.3)'; ctx.lineWidth = 2; ctx.setLineDash([6, 4])
      ctx.beginPath(); ctx.moveTo(arrowStart, cy); ctx.lineTo(energyX - 40, cy); ctx.stroke()
      ctx.setLineDash([])
      ctx.fillStyle = 'rgba(220,200,165,0.3)'; ctx.beginPath()
      ctx.moveTo(energyX - 40, cy - 6); ctx.lineTo(energyX - 28, cy); ctx.lineTo(energyX - 40, cy + 6); ctx.fill()

      // Energy display
      ctx.fillStyle = '#E8DDCC'; ctx.font = 'bold 22px var(--font-display)'; ctx.textAlign = 'center'
      ctx.fillText('E = mc²', energyX + 30, cy - 40)
      ctx.fillStyle = '#C4956A'; ctx.font = '15px var(--font-display)'
      ctx.fillText(`${(E / 1e16).toFixed(4)} × 10¹⁶ J`, energyX + 30, cy - 15)

      // TNT equivalent
      const tntKg = E / 4.184e6
      let tntStr
      if (tntKg >= 1e9) tntStr = `${(tntKg / 1e9).toFixed(1)} Gt TNT`
      else if (tntKg >= 1e6) tntStr = `${(tntKg / 1e6).toFixed(1)} Mt TNT`
      else if (tntKg >= 1e3) tntStr = `${(tntKg / 1e3).toFixed(1)} kt TNT`
      else tntStr = `${tntKg.toFixed(0)} kg TNT`
      ctx.fillStyle = 'rgba(220,200,165,0.4)'; ctx.font = '11px var(--font-body)'
      ctx.fillText(`≈ ${tntStr}`, energyX + 30, cy + 5)

      // Energy scale bar
      const barX = energyX - 10, barY = cy + 30, barW = 120, barH = 12
      const fillFrac = Math.min(1, conversionFrac)
      ctx.strokeStyle = 'rgba(196,149,106,0.2)'; ctx.lineWidth = 1
      ctx.strokeRect(barX, barY, barW, barH)
      const barGrad = ctx.createLinearGradient(barX, 0, barX + barW * fillFrac, 0)
      barGrad.addColorStop(0, 'rgba(196,149,106,0.4)'); barGrad.addColorStop(1, '#E8C880')
      ctx.fillStyle = barGrad; ctx.fillRect(barX, barY, barW * fillFrac, barH)
      ctx.fillStyle = 'rgba(220,200,165,0.35)'; ctx.font = '9px var(--font-body)'; ctx.textAlign = 'left'
      ctx.fillText('Energy Released', barX, barY + barH + 12)

      // Rotating energy rays
      const numRays = 16
      for (let i = 0; i < numRays; i++) {
        const angle = (i / numRays) * Math.PI * 2 + t * 0.5
        const rayLen = 25 + Math.sin(t * 3 + i) * 8 + conversionFrac * 15
        ctx.strokeStyle = `rgba(232,200,128,${0.08 + conversionFrac * 0.08})`; ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(energyX + 30 + Math.cos(angle) * 18, cy + 30 + Math.sin(angle) * 18)
        ctx.lineTo(energyX + 30 + Math.cos(angle) * rayLen, cy + 30 + Math.sin(angle) * rayLen)
        ctx.stroke()
      }

      ctx.textAlign = 'start'
      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const c = 299792458
  const E = mass * c * c
  const tntKg = E / 4.184e6

  const handleCalculate = () => {
    if (localMass === "") { setMass(""); return; }

    let parsedMass = parseFloat(localMass); if (isNaN(parsedMass)) parsedMass = 1.0
    parsedMass = Math.max(0.001, Math.min(500.0, parsedMass)); setMass(parsedMass)
  }
  const handleReset = () => { setMass(1.0) }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(196,149,106,0.1)' }} />
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 gap-4">
            <InputCardField label="Mass" value={localMass} min={0.001} max={500.0} step={0.001} onChange={setLocalMass} unit="kg" />
          </div>
          <div className="flex gap-4 mt-2 w-full">
            <button onClick={handleCalculate} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200" style={{ background: '#C4956A', color: '#141210' }}>Calculate</button>
            <button onClick={handleReset} className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent">Reset</button>
          </div>
        </div>
      </WorkspacePortal>
      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="einstein" params={{ mass }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Rest Mass (m):</span><span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? `${mass.toFixed(4)} kg` : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">Energy (E):</span><span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${(E / 1e16).toFixed(4)} × 10¹⁶ J` : "[Missing]"}</span></div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5"><span className="opacity-50">TNT Equivalent:</span><span className="font-bold text-[#E07840]">{(!isPending && realism.isRealistic) ? (tntKg >= 1e6 ? `${(tntKg / 1e6).toFixed(1)} Mt` : tntKg >= 1e3 ? `${(tntKg / 1e3).toFixed(1)} kt` : `${tntKg.toFixed(0)} kg`) : "[Missing]"}</span></div>
          <div className="p-3.5 rounded-lg border border-[rgba(196,149,106,0.15)] bg-[rgba(196,149,106,0.04)]" style={{ borderLeft: '3px solid rgba(196,149,106,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula:</span>
            <span className="font-mono text-xs text-[#E8C880] block">E = mc² = {(!isPending && realism.isRealistic) ? `${mass.toFixed(4)} × (2.998×10⁸)²` : "[Missing]"}</span>
            <span className="font-mono text-xs text-[#88C0B8] block mt-1">E = {(!isPending && realism.isRealistic) ? `${(E / 1e16).toFixed(4)} × 10¹⁶ J` : "[Missing]"}</span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

function BoltzmannSimulator({ initialParams }) {
  const canvasRef = useRef(null)
  const [temp, setTemp] = useState(() => getInitialParam(initialParams, 'temperature', 300))
  const [localTemp, setLocalTemp] = useState(temp)

  useEffect(() => {
    setLocalTemp(temp)
  }, [temp])

  const animRef = useRef()
  
  const isPending = temp === "";
  const realism = checkRealism('boltzmann', isPending ? {} : { temperature: temp })

  const stateRef = useRef({ temp: 300, isPending: false, isRealistic: true })
  useEffect(() => { stateRef.current.temp = temp; stateRef.current.isPending = isPending; stateRef.current.isRealistic = realism.isRealistic }, [temp, isPending, realism.isRealistic])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const W = 1100, H = 340
    canvas.width = W * dpr; canvas.height = H * dpr
    canvas.style.width = '100%'; canvas.style.height = `${H}px`
    ctx.scale(dpr, dpr)
    const draw = () => {
      const { isPending, isRealistic } = stateRef.current
      if (isPending || !isRealistic) {
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = 'rgba(196,149,106,0.04)'; ctx.lineWidth = 1
        for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
        for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
        ctx.fillStyle = 'rgba(232, 221, 204, 0.4)'; ctx.font = '16px var(--font-mono)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.fillText(isPending ? 'Awaiting required parameters...' : 'Simulation suspended due to physical invalidity', W / 2, H / 2)
        animRef.current = requestAnimationFrame(draw)
        return
      }
      const { temp: T } = stateRef.current
      ctx.clearRect(0, 0, W, H); ctx.fillStyle = '#181410'; ctx.fillRect(0, 0, W, H)
      // Grid
      ctx.strokeStyle = 'rgba(224,120,64,0.04)'; ctx.lineWidth = 1
      for (let y = 0; y <= H; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
      for (let x = 0; x <= W; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }

      const L = W - 160, startX = 80, baseY = H - 50
      const kB = 1.38e-23

      // Axes
      ctx.strokeStyle = 'rgba(220,200,165,0.2)'; ctx.lineWidth = 1.5
      ctx.beginPath(); ctx.moveTo(startX, 30); ctx.lineTo(startX, baseY); ctx.lineTo(startX + L, baseY); ctx.stroke()
      ctx.fillStyle = 'rgba(220,200,165,0.4)'; ctx.font = '11px var(--font-body)'
      ctx.fillText('P(E)', startX - 30, 35)
      ctx.fillText('Energy E →', startX + L - 60, baseY + 20)

      // Boltzmann distribution curve
      ctx.beginPath(); ctx.lineWidth = 2.8
      const g = ctx.createLinearGradient(startX, 0, startX + L, 0)
      g.addColorStop(0, '#E07840'); g.addColorStop(1, 'rgba(224,120,64,0.3)')
      ctx.strokeStyle = g

      const scale = Math.max(0.05, T / 100) // normalize for visualization
      for (let x = 0; x <= L; x++) {
        const E = (x / L) * 10 // energy units
        const P = Math.exp(-E / scale) * (baseY - 50)
        const py = baseY - P
        if (x === 0) ctx.moveTo(startX + x, py); else ctx.lineTo(startX + x, py)
      }
      ctx.stroke()
      // Fill under
      ctx.lineTo(startX + L, baseY); ctx.lineTo(startX, baseY)
      ctx.fillStyle = 'rgba(224,120,64,0.06)'; ctx.fill()

      ctx.fillStyle = '#E07840'; ctx.font = '13px var(--font-display)'; ctx.textAlign = 'center'
      ctx.fillText(`T = ${T} K`, W / 2, 25)
      ctx.fillStyle = 'rgba(220,200,165,0.35)'; ctx.font = '11px var(--font-body)'
      ctx.fillText(`k_B·T = ${(kB * T * 1e21).toFixed(2)} × 10⁻²¹ J`, W / 2, 45)
      ctx.textAlign = 'start'

      animRef.current = requestAnimationFrame(draw)
    }
    draw()
    return () => cancelAnimationFrame(animRef.current)
  }, [])

  const handleCalculate = () => {
    if (localTemp === "") { setTemp(""); return; }

    let parsedTemp = parseFloat(localTemp)
    if (isNaN(parsedTemp)) parsedTemp = 300
    parsedTemp = Math.max(1, Math.min(10000, parsedTemp))
    setTemp(parsedTemp)
  }

  const handleReset = () => {
    setTemp(300)
  }

  return (
    <div className="flex flex-col items-center w-full">
      <canvas ref={canvasRef} style={{ borderRadius: '14px', display: 'block', border: '1px solid rgba(224,120,64,0.1)' }} />
      
      <WorkspacePortal target="inputs">
        <div className="flex flex-col gap-4 w-full">
          <div className="grid grid-cols-1 gap-4">
            <InputCardField
              label="Temperature"
              value={localTemp}
              min={1}
              max={10000}
              step={1}
              onChange={setLocalTemp}
              unit="K"
            />
          </div>
          
          <div className="flex gap-4 mt-2 w-full">
            <button
              onClick={handleCalculate}
              className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200"
              style={{ background: '#E07840', color: '#141210' }}
            >
              Calculate
            </button>
            <button
              onClick={handleReset}
              className="flex-1 py-3 px-5 rounded-xl text-sm font-bold uppercase tracking-wider font-mono cursor-pointer transition-all duration-200 border border-[rgba(220,208,188,0.2)] hover:border-[rgba(220,208,188,0.4)] text-[rgba(220,208,188,0.85)] bg-transparent"
            >
              Reset
            </button>
          </div>
        </div>
      </WorkspacePortal>

      
      <WorkspacePortal target="results">
        <RealismCheckCard equationId="boltzmann" params={{ temperature: temp }} isPending={isPending} />
        {isPending ? (
          <div className="p-3.5 rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.04)] text-red-400 font-mono text-xs mb-3" style={{ borderLeft: '3px solid #ef4444' }}>
            <span className="font-bold uppercase tracking-wider block mb-1">⚠️ Calculation Pending</span>
            Please enter the missing inputs in the Laboratory Inputs card to calculate.
          </div>
        ) : null}
        <div className="flex flex-col gap-5 font-mono text-xs w-full">
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Temperature (T):</span>
            <span className="font-bold text-[#E07840]">{(!isPending && realism.isRealistic) ? `${temp} K` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Thermal Energy (k_B·T):</span>
            <span className="font-bold text-[#E8C880]">{(!isPending && realism.isRealistic) ? `${(1.38e-23 * temp * 1e21).toFixed(4)} × 10⁻²¹ J` : "[Missing]"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-[rgba(255,255,255,0.03)] pb-2.5">
            <span className="opacity-50">Relative Probability (ΔE=1 eV):</span>
            <span className="font-bold text-[#C4956A]">{(!isPending && realism.isRealistic) ? Math.exp(-11604.5 / temp).toExponential(4) : "[Missing]"}</span>
          </div>
          <div className="p-3.5 rounded-lg border border-[rgba(224,120,64,0.15)] bg-[rgba(224,120,64,0.04)]" style={{ borderLeft: '3px solid rgba(224,120,64,0.35)' }}>
            <span className="opacity-40 block mb-1">Formula Substitution:</span>
            <span className="font-mono text-xs text-[#E8C880]">
              P(E) ∝ e^(−E / k_B·T) <br />
              At E = 1 eV: P ∝ e^(−1.602e-19 J / { (!isPending && realism.isRealistic) ? (1.38e-23 * temp).toExponential(3) : "[Missing]" } J) = { (!isPending && realism.isRealistic) ? Math.exp(-11604.5 / temp).toExponential(4) : "[Missing]" }
            </span>
          </div>
        </div>
      </WorkspacePortal>
    </div>
  )
}

// ══════════════════════════
//  EQUATION DATA
// ══════════════════════════

const BRANCHES = [
  { id: 'all', label: 'All Fields', color: '#C4956A' },
  { id: 'quantum', label: 'Quantum Mechanics', color: '#C4956A' },
  { id: 'classical', label: 'Classical Mechanics', color: '#88C0B8' },
  { id: 'thermo', label: 'Thermodynamics', color: '#E07840' },
  { id: 'fluid', label: 'Fluid Mechanics', color: '#88C0B8' },
  { id: 'em', label: 'Electromagnetism', color: '#A09CC8' },
  { id: 'relativity', label: 'Relativity', color: '#C4956A' },
  { id: 'statistical', label: 'Statistical Mech', color: '#E07840' },
]

const EQUATIONS = [
  { id: 'schrodinger', branch: 'quantum', name: 'Schrödinger Equation', formula: 'iℏ ∂ψ/∂t = Ĥψ', color: '#C4956A',
    description: 'Formulates the behavior of quantum particles by describing how their wave functions evolve continuously over time. It serves as the mathematical foundation of non-relativistic quantum mechanics, enabling the prediction of probability densities for electrons in atoms, molecules, and solid-state materials.',
    realWorldApps: 'Quantum computing, semiconductors, and nanotechnology.',
    variables: [{ symbol: 'ψ', def: 'Wave function — quantum probability amplitude' }, { symbol: 'ℏ', def: 'Reduced Planck constant ≈ 1.055 × 10⁻³⁴ J·s' }, { symbol: 'Ĥ', def: 'Hamiltonian operator — total system energy' }],
    Simulator: SchrodingerSimulator },
  { id: 'uncertainty', branch: 'quantum', name: 'Heisenberg Uncertainty', formula: 'σₓ σₚ ≥ ℏ/2', color: '#C4956A',
    description: 'States that certain pairs of physical properties, such as a particle\'s position and momentum, cannot be simultaneously measured with arbitrary precision. This fundamental limit is not a limitation of instruments, but an intrinsic property of all quantum systems.',
    realWorldApps: 'Scanning tunneling microscopes, laser physics, and particle colliders.',
    variables: [{ symbol: 'σₓ', def: 'Standard deviation in position' }, { symbol: 'σₚ', def: 'Standard deviation in momentum' }, { symbol: 'ℏ', def: 'Reduced Planck constant' }],
    Simulator: UncertaintySimulator },
  { id: 'wave', branch: 'classical', name: 'Wave Equation', formula: '∂²u/∂t² = c² ∇²u', color: '#88C0B8',
    description: 'A second-order partial differential equation that governs the propagation of mechanical and electromagnetic waves through a medium. It mathematically represents how disturbances travel over time, describing phenomena like sound waves, vibrating violin strings, and seismic waves.',
    realWorldApps: 'Acoustics, musical instruments, seismic studies, and oceanography.',
    variables: [{ symbol: 'u', def: 'Displacement field u(x,t)' }, { symbol: 'c', def: 'Phase velocity of wave propagation' }, { symbol: '∇²', def: 'Laplacian spatial operator' }],
    Simulator: WaveSimulator },
  { id: 'newton', branch: 'classical', name: 'Newton\'s Second Law', formula: 'F = ma', color: '#88C0B8',
    description: 'Defines classical dynamics by stating that the acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass. It forms the core foundation of classical mechanics, governing everyday motion from falling apples to orbiting satellites.',
    realWorldApps: 'Rocket propulsion, automotive engineering, structural design, and sports biomechanics.',
    variables: [{ symbol: 'F', def: 'Net force vector (N)' }, { symbol: 'm', def: 'Inertial mass (kg)' }, { symbol: 'a', def: 'Acceleration vector (m/s²)' }],
    Simulator: NewtonSimulator },
  { id: 'heat', branch: 'thermo', name: 'Heat Equation', formula: '∂T/∂t = α ∇²T', color: '#E07840',
    description: 'Describes how thermal energy diffuses through a given region over time, smoothing out temperature gradients. It represents a fundamental transport equation in thermodynamics, explaining heat conduction in solids, fluid thermal dissipation, and geological cooling processes.',
    realWorldApps: 'Metallurgy, climate modeling, electronics cooling, and geophysics.',
    variables: [{ symbol: 'T', def: 'Temperature scalar field T(x,t)' }, { symbol: 'α', def: 'Thermal diffusivity constant' }, { symbol: '∇²T', def: 'Spatial curvature of temperature' }],
    Simulator: HeatSimulator },
  { id: 'entropy', branch: 'thermo', name: 'Entropy — Second Law', formula: 'dS ≥ dQ/T', color: '#E07840',
    description: 'Formulates the second law of thermodynamics by stating that the total entropy of an isolated system always increases over time, approaching a state of maximum disorder. It establishes the direction of thermodynamic processes, defining the irreversible arrow of time in physical systems.',
    realWorldApps: 'Steam turbines, refrigeration, chemical engineering, and cosmology.',
    variables: [{ symbol: 'S', def: 'Thermodynamic entropy (J/K)' }, { symbol: 'Q', def: 'Heat transferred to system' }, { symbol: 'T', def: 'Absolute temperature (K)' }],
    Simulator: EntropySimulator },
  { id: 'navier', branch: 'fluid', name: 'Navier–Stokes', formula: 'ρ(∂u/∂t + u·∇u) = −∇p + μ∇²u', color: '#88C0B8',
    description: 'Applies Newton\'s second law to fluid motion, describing how velocity, pressure, temperature, and density are related in a moving viscous fluid. These equations are crucial for simulating atmospheric weather patterns, ocean currents, aerodynamics of aircraft, and pipe flow dynamics.',
    realWorldApps: 'Aerodynamics, weather forecasting, pipe network design, and ocean currents.',
    variables: [{ symbol: 'u', def: 'Velocity vector field' }, { symbol: 'ρ', def: 'Fluid density' }, { symbol: 'p', def: 'Pressure gradient' }, { symbol: 'μ', def: 'Dynamic viscosity' }],
    Simulator: FluidSimulator },
  { id: 'continuity', branch: 'fluid', name: 'Continuity Equation', formula: '∂ρ/∂t + ∇·(ρu) = 0', color: '#88C0B8',
    description: 'Expresses the fundamental principle of mass conservation in fluid dynamics, stating that the rate of mass entering a system must equal the rate of mass leaving it. It dictates how fluid velocity must increase when flowing through a constricted pipe or channel to maintain steady flow.',
    realWorldApps: 'Hydraulic systems, blood flow analysis, aerodynamics, and chemical reactors.',
    variables: [{ symbol: 'ρ', def: 'Fluid density field' }, { symbol: 'u', def: 'Velocity vector field' }],
    Simulator: ContinuitySimulator },
  { id: 'maxwell1', branch: 'em', name: 'Maxwell — Gauss\'s Law', formula: '∇·E = ρ/ε₀', color: '#A09CC8',
    description: 'Gauss\'s law for electricity states that the net electric flux outward through any closed surface is proportional to the total electric charge enclosed within that surface. It describes how electric charges produce electric fields, forming one of the four cornerstone Maxwell\'s equations.',
    realWorldApps: 'Capacitor design, electrostatic precipitators, and field shielding.',
    variables: [{ symbol: 'E', def: 'Electric field vector' }, { symbol: 'ρ', def: 'Charge density (C/m³)' }, { symbol: 'ε₀', def: 'Permittivity of free space' }],
    Simulator: ElectricFieldSimulator },
  { id: 'faraday', branch: 'em', name: 'Faraday\'s Law', formula: '∇×E = −∂B/∂t', color: '#A09CC8',
    description: 'Faraday\'s law of induction states that a time-varying magnetic field induces a circulating electromotive force and electric field. This fundamental electromagnetic principle is the operational basis for electrical generators, transformers, induction motors, and wireless power transfer.',
    realWorldApps: 'Electric generators, transformers, induction stovetops, and wireless charging.',
    variables: [{ symbol: 'E', def: 'Electric field' }, { symbol: 'B', def: 'Magnetic flux density' }],
    Simulator: FaradaySimulator },
  { id: 'lorentz', branch: 'relativity', name: 'Lorentz Factor', formula: 'γ = 1/√(1−v²/c²)', color: '#C4956A',
    description: 'Calculates the relativistic factor by which time dilates, length contracts, and relativistic mass increases for an object moving relative to an observer. It is a cornerstone of Einstein\'s special relativity, showing that physical measurements of space and time depend on the relative speed.',
    realWorldApps: 'GPS satellite clock calibration, cosmic ray detection, and particle accelerators.',
    variables: [{ symbol: 'γ', def: 'Lorentz factor' }, { symbol: 'v', def: 'Relative velocity' }, { symbol: 'c', def: 'Speed of light ≈ 3×10⁸ m/s' }],
    Simulator: LorentzSimulator },
  { id: 'einstein', branch: 'relativity', name: 'Mass–Energy Equivalence', formula: 'E = mc²', color: '#C4956A',
    description: 'States that rest mass and energy are directly equivalent and interchangeable, related by the square of the speed of light. This famous formula underpins nuclear physics, explaining the massive energy released during nuclear fission in reactors and stellar fusion in the core of stars.',
    realWorldApps: 'Nuclear power plants, solar radiation energy source, and stellar physics.',
    variables: [{ symbol: 'E', def: 'Total rest energy (J)' }, { symbol: 'm', def: 'Rest mass (kg)' }, { symbol: 'c', def: 'Speed of light' }],
    Simulator: MassEnergySimulator },
  { id: 'boltzmann', branch: 'statistical', name: 'Boltzmann Distribution', formula: 'P ∝ e^(−E/k_BT)', color: '#E07840',
    description: 'Expresses the probability that a thermodynamic system will occupy a specific microstate as a function of that state\'s energy and the system\'s absolute temperature. It forms the foundation of statistical mechanics, bridging microscopic particle energy levels to macroscopic thermodynamic properties.',
    realWorldApps: 'Semiconductor carrier concentration, gas kinetics, and astrophysics.',
    variables: [{ symbol: 'P', def: 'Probability of state' }, { symbol: 'E', def: 'Energy of the state' }, { symbol: 'k_B', def: 'Boltzmann constant ≈ 1.38×10⁻²³ J/K' }],
    Simulator: BoltzmannSimulator },
  { id: 'projectile', branch: 'classical', name: 'Projectile Motion', formula: "y = v₀t sinθ − ½gt²\nR = (v₀² sin(2θ))/g\nH = (v₀² sin²θ)/(2g)", color: '#88C0B8',
    description: 'Analyzes the trajectory of an object launched into the air at a given angle and velocity. It decomposes motion into independent horizontal and vertical components, where only vertical motion is influenced by gravitational acceleration. This framework predicts the range, maximum height, and time of flight for any projectile.',
    realWorldApps: 'Sports analytics (basketball, football), ballistic trajectory calculation, fireworks displays, and long jump training.',
    variables: [{ symbol: 'v₀', def: 'Initial launch velocity (m/s)' }, { symbol: 'θ', def: 'Launch angle from horizontal' }, { symbol: 'g', def: 'Gravitational acceleration ≈ 9.81 m/s²' }, { symbol: 't', def: 'Time elapsed (s)' }],
    Simulator: ProjectileSimulator },
  { id: 'energy', branch: 'classical', name: 'Conservation of Energy', formula: 'KE + PE = E_total', color: '#88C0B8',
    description: 'States that the total mechanical energy of an isolated system remains constant, with energy only converting between kinetic and potential forms. As an object falls from height, its potential energy transforms into kinetic energy while the sum is preserved throughout the motion.',
    realWorldApps: 'Roller coaster design, hydroelectric power generation, bungee jumping safety calculations, and ski jump engineering.',
    variables: [{ symbol: 'KE', def: 'Kinetic energy = ½mv² (J)' }, { symbol: 'PE', def: 'Potential energy = mgh (J)' }, { symbol: 'E', def: 'Total mechanical energy (J)' }],
    Simulator: EnergySimulator },
  { id: 'momentum', branch: 'classical', name: 'Momentum', formula: 'p = mv', color: '#88C0B8',
    description: 'Defines the quantity of motion of a moving body, measured as the product of its mass and velocity. In isolated systems, total momentum is conserved during collisions, enabling prediction of post-collision velocities for elastic and inelastic impacts.',
    realWorldApps: 'Car crash analysis, billiards physics, rocket propulsion, and Newton\'s cradle.',
    variables: [{ symbol: 'p', def: 'Linear momentum (kg·m/s)' }, { symbol: 'm', def: 'Mass (kg)' }, { symbol: 'v', def: 'Velocity (m/s)' }],
    Simulator: MomentumSimulator },
  { id: 'circular', branch: 'classical', name: 'Circular Motion', formula: 'F = mv²/r', color: '#88C0B8',
    description: 'Describes the centripetal force required to maintain an object moving along a circular path at constant speed. The force always points radially inward toward the center of the circle, and its magnitude depends on the object\'s mass, speed, and the radius of the circular path.',
    realWorldApps: 'Satellite orbits, car cornering physics, centrifuge design, and amusement park rides.',
    variables: [{ symbol: 'F', def: 'Centripetal force (N)' }, { symbol: 'm', def: 'Mass (kg)' }, { symbol: 'v', def: 'Tangential velocity (m/s)' }, { symbol: 'r', def: 'Radius of circular path (m)' }],
    Simulator: CircularMotionSimulator },
  { id: 'gravitation', branch: 'classical', name: 'Universal Gravitation', formula: 'F = Gm₁m₂/r²', color: '#88C0B8',
    description: 'Newton\'s law of universal gravitation states that every particle attracts every other particle with a force proportional to the product of their masses and inversely proportional to the square of the distance between them. It explains planetary orbits, tidal forces, and weight.',
    realWorldApps: 'Space mission planning, satellite trajectories, tidal predictions, and weight calculations on other planets.',
    variables: [{ symbol: 'G', def: 'Gravitational constant ≈ 6.674×10⁻¹¹ N·m²/kg²' }, { symbol: 'm₁,m₂', def: 'Masses of the two bodies' }, { symbol: 'r', def: 'Distance between centers' }],
    Simulator: GravitationSimulator },
  { id: 'bernoulli', branch: 'fluid', name: 'Bernoulli Equation', formula: 'P + ½ρv² + ρgh = const', color: '#88C0B8',
    description: 'Describes the conservation of energy in a flowing fluid, relating pressure, velocity, and elevation. As fluid speeds up (e.g., through a constriction), its static pressure decreases, and vice versa. This principle is fundamental to understanding lift, flow meters, and pipe dynamics.',
    realWorldApps: 'Airplane lift generation, venturi meters, carburetors, pitot tubes, and water tower pressure.',
    variables: [{ symbol: 'P', def: 'Static pressure (Pa)' }, { symbol: 'ρ', def: 'Fluid density (kg/m³)' }, { symbol: 'v', def: 'Flow velocity (m/s)' }, { symbol: 'h', def: 'Elevation height (m)' }],
    Simulator: BernoulliSimulator },
  { id: 'reynolds_num', branch: 'fluid', name: 'Reynolds Number', formula: 'Re = ρvL/μ', color: '#88C0B8',
    description: 'A dimensionless quantity that predicts whether fluid flow will be laminar (smooth, orderly) or turbulent (chaotic, mixing). Below ~2300, flow is laminar; above ~4000, it is fully turbulent. The transition regime lies between these values and is highly sensitive to disturbances.',
    realWorldApps: 'Pipe system design, aircraft aerodynamics, blood flow analysis, industrial mixing, and weather modeling.',
    variables: [{ symbol: 'Re', def: 'Reynolds number (dimensionless)' }, { symbol: 'ρ', def: 'Fluid density (kg/m³)' }, { symbol: 'v', def: 'Flow velocity (m/s)' }, { symbol: 'L', def: 'Characteristic length (m)' }, { symbol: 'μ', def: 'Dynamic viscosity (Pa·s)' }],
    Simulator: ReynoldsSimulator },
  { id: 'coulomb', branch: 'em', name: 'Coulomb\'s Law', formula: 'F = kq₁q₂/r²', color: '#A09CC8',
    description: 'Quantifies the electrostatic force between two point charges. Like charges repel and opposite charges attract, with the force magnitude proportional to the product of charges and inversely proportional to the square of separation distance. It is the electrical analog of Newton\'s gravitational law.',
    realWorldApps: 'Electrostatic interactions in chemistry, crystal bonding, electroscope physics, and charge separation.',
    variables: [{ symbol: 'k', def: 'Coulomb constant ≈ 8.99×10⁹ N·m²/C²' }, { symbol: 'q₁,q₂', def: 'Electric charges (C)' }, { symbol: 'r', def: 'Separation distance (m)' }],
    Simulator: CoulombSimulator },
  { id: 'lorentzforce', branch: 'em', name: 'Lorentz Force', formula: 'F = qv × B', color: '#A09CC8',
    description: 'Describes the force experienced by a charged particle moving through a magnetic field. The force is always perpendicular to both the velocity and the magnetic field, causing the particle to follow a circular or helical trajectory. This is the basis for cyclotrons and mass spectrometers.',
    realWorldApps: 'Mass spectrometers, cyclotron particle accelerators, MRI machines, aurora borealis, and CRT displays.',
    variables: [{ symbol: 'F', def: 'Lorentz force (N)' }, { symbol: 'q', def: 'Particle charge (C)' }, { symbol: 'v', def: 'Particle velocity (m/s)' }, { symbol: 'B', def: 'Magnetic field strength (T)' }],
    Simulator: LorentzForceSimulator },
  { id: 'idealgas', branch: 'thermo', name: 'Ideal Gas Law', formula: 'PV = nRT', color: '#E07840',
    description: 'Relates the pressure, volume, temperature, and amount of an ideal gas. It combines Boyle\'s, Charles\'s, and Avogadro\'s laws into a single equation of state. While real gases deviate at high pressures or low temperatures, it provides excellent predictions for most practical conditions.',
    realWorldApps: 'Weather balloon behavior, scuba diving gas calculations, internal combustion engines, tire pressure changes, and altitude sickness.',
    variables: [{ symbol: 'P', def: 'Gas pressure (Pa)' }, { symbol: 'V', def: 'Volume (m³)' }, { symbol: 'n', def: 'Amount of substance (mol)' }, { symbol: 'R', def: 'Gas constant = 8.314 J/(mol·K)' }, { symbol: 'T', def: 'Absolute temperature (K)' }],
    Simulator: IdealGasSimulator },
  { id: 'hooke', branch: 'classical', name: "Hooke's Law", formula: 'F = −kx', color: '#88C0B8',
    description: 'States that the force needed to extend or compress a spring by some distance is proportional to that distance. The restoring force always acts in the opposite direction to the displacement, making it the foundation of elasticity and the starting point for understanding oscillatory systems.',
    realWorldApps: 'Shock absorbers, spring scales, mattress design, trampoline engineering, and suspension bridges.',
    variables: [{ symbol: 'F', def: 'Restoring force (N)' }, { symbol: 'k', def: 'Spring constant (N/m)' }, { symbol: 'x', def: 'Displacement from equilibrium (m)' }],
    Simulator: HookeSimulator },
  { id: 'shm', branch: 'classical', name: 'Simple Harmonic Motion', formula: 'x = A cos(ωt + φ)', color: '#88C0B8',
    description: 'Describes the repetitive back-and-forth motion of a system about an equilibrium position, where the restoring force is directly proportional to displacement. The motion is perfectly sinusoidal, with a period that depends only on the system parameters, not the amplitude.',
    realWorldApps: 'Clock pendulums, tuning forks, seismographs, molecular vibrations, and playground swings.',
    variables: [{ symbol: 'A', def: 'Amplitude — maximum displacement (m)' }, { symbol: 'ω', def: 'Angular frequency = 2πf (rad/s)' }, { symbol: 'φ', def: 'Phase constant (rad)' }, { symbol: 't', def: 'Time (s)' }],
    Simulator: SHMSimulator },
  { id: 'ohm', branch: 'em', name: "Ohm's Law", formula: 'V = IR', color: '#A09CC8',
    description: 'States that the electric current flowing through a conductor between two points is directly proportional to the voltage across the two points and inversely proportional to the resistance. It is the most fundamental law of circuit analysis, governing everything from simple LED circuits to complex power grids.',
    realWorldApps: 'Circuit design, LED resistor calculation, household wiring, battery systems, and multimeter operation.',
    variables: [{ symbol: 'V', def: 'Voltage / potential difference (V)' }, { symbol: 'I', def: 'Electric current (A)' }, { symbol: 'R', def: 'Electrical resistance (Ω)' }],
    Simulator: OhmSimulator },
  { id: 'debroglie', branch: 'quantum', name: 'de Broglie Wavelength', formula: 'λ = h/p = h/(mv)', color: '#C4956A',
    description: 'Proposes that every particle with momentum has an associated wavelength, establishing the wave–particle duality of matter. For subatomic particles like electrons, this wavelength is significant and experimentally measurable through diffraction, while for macroscopic objects it is immeasurably small.',
    realWorldApps: 'Electron microscopy, neutron diffraction, semiconductor band theory, and quantum tunneling applications.',
    variables: [{ symbol: 'λ', def: 'de Broglie wavelength (m)' }, { symbol: 'h', def: 'Planck constant ≈ 6.626 × 10⁻³⁴ J·s' }, { symbol: 'p', def: 'Momentum = mv (kg·m/s)' }],
    Simulator: DeBroglieSimulator },
  { id: 'photoelectric', branch: 'quantum', name: 'Photoelectric Effect', formula: 'KE = hf − φ', color: '#C4956A',
    description: 'Explains that when light of sufficient frequency strikes a metal surface, it ejects electrons with kinetic energy equal to the photon energy minus the metal\'s work function. Below the threshold frequency, no electrons are emitted regardless of light intensity — proving the quantized particle nature of light.',
    realWorldApps: 'Solar cells, photomultiplier tubes, camera sensors, night vision devices, and automatic doors.',
    variables: [{ symbol: 'KE', def: 'Kinetic energy of emitted electron (J or eV)' }, { symbol: 'h', def: 'Planck constant' }, { symbol: 'f', def: 'Frequency of incident light (Hz)' }, { symbol: 'φ', def: 'Work function of the metal (eV)' }],
    Simulator: PhotoelectricSimulator },
  { id: 'rc_circuit', branch: 'em', name: 'RC Circuit Charging', formula: 'V_c(t) = V₀(1 − e^(−t/RC))', color: '#A09CC8',
    description: 'Governs the charging behavior of a resistor-capacitor circuit, describing how the capacitor voltage increases exponentially towards the source voltage over time. The rate of charging is determined by the circuit time constant τ = RC, which represents the time required for the capacitor to charge to approximately 63.2% of its maximum value.',
    realWorldApps: 'Electronic timers, noise filters, power supply smoothing, and camera flash units.',
    variables: [{ symbol: 'V_c(t)', def: 'Capacitor voltage at time t (V)' }, { symbol: 'V₀', def: 'Source voltage (V)' }, { symbol: 'R', def: 'Resistance (Ω)' }, { symbol: 'C', def: 'Capacitance (F)' }, { symbol: 't', def: 'Time elapsed (s)' }],
    Simulator: RCCircuitSimulator },
]

// ══════════════════════════
//  FLOATING ORB ANIMATION
// ══════════════════════════
function FloatingOrbs() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 0 }}>
      {[
        { size: 350, x: '10%', y: '20%', color: 'rgba(196,149,106,0.025)', dur: 22, delay: 0 },
        { size: 280, x: '75%', y: '60%', color: 'rgba(136,192,184,0.02)', dur: 28, delay: -5 },
        { size: 200, x: '50%', y: '80%', color: 'rgba(224,120,64,0.015)', dur: 18, delay: -10 },
        { size: 320, x: '85%', y: '15%', color: 'rgba(160,156,200,0.02)', dur: 25, delay: -8 },
      ].map((orb, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            width: orb.size,
            height: orb.size,
            left: orb.x,
            top: orb.y,
            background: `radial-gradient(circle, ${orb.color} 0%, transparent 70%)`,
            filter: 'blur(60px)',
          }}
          animate={{
            x: [0, 30, -20, 15, 0],
            y: [0, -25, 15, -10, 0],
          }}
          transition={{
            duration: orb.dur,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: orb.delay,
          }}
        />
      ))}
    </div>
  )
}

// ══════════════════════════════════════════
//  BRANCH-SPECIFIC AMBIENT EFFECTS
//  Subtle, non-distracting canvas overlays
// ══════════════════════════════════════════
function BranchAmbientEffect({ branch = 'classical', color = '#C4956A' }) {
  const canvasRef = useRef(null)
  const animRef = useRef()

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resize()
    window.addEventListener('resize', resize)

    const hexToRgb = (hex) => {
      const h = hex.replace('#', '')
      return { r: parseInt(h.substring(0, 2), 16), g: parseInt(h.substring(2, 4), 16), b: parseInt(h.substring(4, 6), 16) }
    }
    const rgb = hexToRgb(color)
    let t = 0

    // Branch-specific elements
    const particles = Array.from({ length: 35 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      r: Math.random() * 1.8 + 0.5,
      vx: (Math.random() - 0.5) * 0.15,
      vy: (Math.random() - 0.5) * 0.12,
      alpha: Math.random() * 0.08 + 0.02,
      pulse: Math.random() * Math.PI * 2,
      pulseSpeed: Math.random() * 0.008 + 0.003,
    }))

    const draw = () => {
      t += 0.008
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Common: soft glowing particles
      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy; p.pulse += p.pulseSpeed
        const flickerAlpha = p.alpha * (0.6 + 0.4 * Math.sin(p.pulse))
        if (p.x < -10) p.x = canvas.width + 10
        if (p.x > canvas.width + 10) p.x = -10
        if (p.y < -10) p.y = canvas.height + 10
        if (p.y > canvas.height + 10) p.y = -10
        const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 4)
        grad.addColorStop(0, `rgba(${rgb.r},${rgb.g},${rgb.b},${flickerAlpha})`)
        grad.addColorStop(1, 'transparent')
        ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 4, 0, Math.PI * 2); ctx.fill()
      })

      // Branch-specific overlay effects (very low opacity)
      if (branch === 'fluid') {
        // Slow horizontal streamlines
        for (let i = 0; i < 6; i++) {
          const y = canvas.height * (0.15 + i * 0.14)
          ctx.strokeStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},0.04)`; ctx.lineWidth = 1
          ctx.beginPath()
          for (let x = 0; x < canvas.width; x += 4) {
            const dy = Math.sin(x * 0.003 + t + i * 0.8) * 8
            x === 0 ? ctx.moveTo(x, y + dy) : ctx.lineTo(x, y + dy)
          }
          ctx.stroke()
        }
      } else if (branch === 'quantum') {
        // Sine-wave ripple field
        for (let i = 0; i < 4; i++) {
          const y = canvas.height * (0.2 + i * 0.2)
          ctx.strokeStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},0.035)`; ctx.lineWidth = 1.5
          ctx.beginPath()
          for (let x = 0; x < canvas.width; x += 3) {
            const dy = Math.sin(x * 0.008 + t * 1.5 + i) * 15 * Math.sin(x * 0.002)
            x === 0 ? ctx.moveTo(x, y + dy) : ctx.lineTo(x, y + dy)
          }
          ctx.stroke()
        }
      } else if (branch === 'classical') {
        // Drifting arrows/vectors
        for (let i = 0; i < 8; i++) {
          const ax = (i * 160 + t * 20) % (canvas.width + 100) - 50
          const ay = canvas.height * (0.2 + (i % 4) * 0.2) + Math.sin(t + i) * 10
          ctx.strokeStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},0.05)`; ctx.lineWidth = 1
          ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(ax + 25, ay); ctx.stroke()
          ctx.beginPath(); ctx.moveTo(ax + 25, ay); ctx.lineTo(ax + 20, ay - 3); ctx.lineTo(ax + 20, ay + 3); ctx.closePath()
          ctx.fillStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},0.05)`; ctx.fill()
        }
      } else if (branch === 'em') {
        // Faint curved field lines
        for (let i = 0; i < 6; i++) {
          const cx = canvas.width * 0.5, cy = canvas.height * 0.5
          const r = 80 + i * 50
          ctx.strokeStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},0.03)`; ctx.lineWidth = 1
          ctx.beginPath()
          for (let a = 0; a < Math.PI * 2; a += 0.05) {
            const rr = r + Math.sin(a * 3 + t) * 8
            const x = cx + rr * Math.cos(a + t * 0.1), y = cy + rr * Math.sin(a + t * 0.1)
            a === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)
          }
          ctx.stroke()
        }
      } else if (branch === 'thermo') {
        // Soft heat shimmer (vertical wavy lines)
        for (let i = 0; i < 8; i++) {
          const x = canvas.width * (0.1 + i * 0.1)
          ctx.strokeStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},0.03)`; ctx.lineWidth = 1
          ctx.beginPath()
          for (let y = canvas.height; y > canvas.height * 0.3; y -= 4) {
            const dx = Math.sin(y * 0.01 + t * 2 + i) * 5
            y === canvas.height ? ctx.moveTo(x + dx, y) : ctx.lineTo(x + dx, y)
          }
          ctx.stroke()
        }
      } else if (branch === 'relativity') {
        // Slow spacetime grid warp
        ctx.strokeStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},0.025)`; ctx.lineWidth = 0.5
        for (let i = 0; i < 10; i++) {
          ctx.beginPath()
          for (let x = 0; x < canvas.width; x += 5) {
            const y = canvas.height * (0.1 + i * 0.08) + Math.sin(x * 0.005 + t * 0.5) * (4 + Math.sin(t * 0.3) * 2)
            x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)
          }
          ctx.stroke()
        }
      } else if (branch === 'statistical') {
        // Random Brownian dots
        for (let i = 0; i < 20; i++) {
          const bx = (particles[i % particles.length].x + Math.sin(t * 2 + i * 5) * 3)
          const by = (particles[i % particles.length].y + Math.cos(t * 2.5 + i * 3) * 3)
          ctx.fillStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},0.06)`
          ctx.beginPath(); ctx.arc(bx, by, 1.5, 0, Math.PI * 2); ctx.fill()
        }
      }

      animRef.current = requestAnimationFrame(draw)
    }
    draw()

    return () => {
      cancelAnimationFrame(animRef.current)
      window.removeEventListener('resize', resize)
    }
  }, [branch, color])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 1, opacity: 0.6 }}
    />
  )
}

function CornerAnimations() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 1 }}>
      {/* Top Left: Concentric Orbits / Radar / Astrolabe */}
      <div
        className="absolute top-10 left-10 opacity-30 flex items-center justify-center animate-fade-in-corner"
        style={{ width: '180px', height: '180px' }}
      >
        <svg width="180" height="180" viewBox="0 0 100 100" fill="none" stroke="#C4956A" strokeWidth="0.5">
          <circle cx="50" cy="50" r="45" strokeDasharray="1 3" />
          <circle cx="50" cy="50" r="35" strokeWidth="0.3" strokeDasharray="4 2" />
          <circle cx="50" cy="50" r="22" strokeWidth="0.5" />
          <circle cx="50" cy="50" r="10" strokeDasharray="1 1" />
          <line x1="5" y1="50" x2="95" y2="50" strokeDasharray="2 2" strokeWidth="0.3" />
          <line x1="50" y1="5" x2="50" y2="95" strokeDasharray="2 2" strokeWidth="0.3" />
          <g
            style={{ transformOrigin: '50px 50px' }}
            className="animate-spin-clockwise"
          >
            <line x1="50" y1="50" x2="85" y2="15" strokeWidth="0.8" />
            <circle cx="85" cy="15" r="2.5" fill="#C4956A" />
            <line x1="50" y1="50" x2="15" y2="85" strokeWidth="0.4" />
          </g>
          <g
            style={{ transformOrigin: '50px 50px' }}
            className="animate-spin-counterclockwise"
          >
            <circle cx="50" cy="15" r="1.5" fill="#88C0B8" stroke="none" />
            <circle cx="50" cy="85" r="1.5" fill="#88C0B8" stroke="none" />
            <path d="M 50 15 A 35 35 0 0 1 85 50" stroke="#88C0B8" strokeWidth="1" strokeDasharray="2 2" />
          </g>
        </svg>
      </div>

      {/* Top Right: Fourier/Wave Oscilloscope */}
      <div
        className="absolute top-10 right-10 opacity-30 flex items-center justify-center animate-fade-in-corner"
        style={{ width: '180px', height: '180px' }}
      >
        <svg width="180" height="180" viewBox="0 0 100 100" fill="none" stroke="#88C0B8" strokeWidth="0.5">
          <path d="M10,10 H90 V90 H10 Z" strokeWidth="0.3" strokeDasharray="1 4" />
          <line x1="10" y1="50" x2="90" y2="50" strokeWidth="0.4" strokeDasharray="3 3" />
          <line x1="50" y1="10" x2="50" y2="90" strokeWidth="0.4" strokeDasharray="3 3" />
          <path
            d="M 10 50 Q 25 30 40 50 T 70 50 T 90 50"
            stroke="#88C0B8"
            strokeWidth="0.8"
          />
          <path
            d="M 10 50 C 25 70 35 30 50 50 C 65 70 75 30 90 50"
            stroke="#C4956A"
            strokeWidth="0.6"
          />
          <circle
            cx="50" cy="50" r="30"
            stroke="rgba(224,120,64,0.15)"
            strokeDasharray="2 5"
            style={{ transformOrigin: '50px 50px' }}
            className="animate-spin-clockwise-fast"
          />
        </svg>
      </div>
    </div>
  )
}

const GRAPH_METADATA = {
  schrodinger: {
    title: "Quantum Wave Probability Density",
    xAxis: "Position (x)",
    yAxis: "Probability Density |ψ(x)|²",
    units: "Position: arbitrary, Probability: dimensionless",
    explanation: "Visualizes the spatial probability distribution of a particle in an infinite potential well under a superposed quantum state.",
    simInfo: { currentState: "Particle confined in a 1D infinite potential well", interpretation: "The peaks show where the particle is most likely found. In superposition states, the wave function oscillates between different spatial distributions, illustrating quantum interference." }
  },
  uncertainty: {
    title: "Heisenberg Wavepacket Widths",
    xAxis: "Position (x) / Momentum (p)",
    yAxis: "Wave Intensity / Probability",
    units: "Position: meters (m), Momentum: kg·m/s",
    explanation: "Demonstrates the reciprocal relationship between positional localization and momentum spread; narrow wavepackets in position correspond to broad momentum spreads.",
    simInfo: { currentState: "Gaussian wavepackets in position and momentum space", interpretation: "As you narrow the position wavepacket, the momentum wavepacket broadens — and vice versa. This is the fundamental uncertainty principle: σₓ·σₚ ≥ ℏ/2." }
  },
  wave: {
    title: "1D String Vibration Harmonic Modes",
    xAxis: "Position along String (x)",
    yAxis: "Displacement (y)",
    units: "Length: meters (m), Displacement: pixels (px)",
    explanation: "Shows the spatial standing wave patterns of a vibrating string under tension at a selected harmonic mode.",
    simInfo: { currentState: "Standing wave at selected harmonic mode", interpretation: "Higher harmonics have more nodes (zero-displacement points). The wave speed c and string length L determine the allowed frequencies: fₙ = nc/(2L)." }
  },
  newton: {
    title: "Inertial Mass Acceleration Motion",
    xAxis: "Time (t)",
    yAxis: "Displacement (x)",
    units: "Time: seconds (s), Displacement: meters (m)",
    explanation: "Simulates the constant acceleration of a mass block subjected to a continuous applied force on a frictionless track.",
    simInfo: { currentState: "Mass accelerating under constant applied force", interpretation: "The block accelerates proportionally to force and inversely to mass. Doubling force doubles acceleration; doubling mass halves it." }
  },
  heat: {
    title: "1D Heat Diffusion Profile",
    xAxis: "Spatial Domain (x)",
    yAxis: "Temperature (T)",
    units: "Domain: dimensionless, Temperature: Kelvin (K)",
    explanation: "Visualizes the smoothing and flattening of a localized temperature peak over time through thermal diffusion.",
    simInfo: { currentState: "Temperature profile evolving via thermal diffusion", interpretation: "Heat flows from hot to cold regions. Higher thermal diffusivity (α) causes faster spreading. The initial peak flattens over time as the system approaches thermal equilibrium." }
  },
  entropy: {
    title: "Gas Particle Microstates and Disorder",
    xAxis: "Container Width (x)",
    yAxis: "Container Height (y)",
    units: "Dimensions: arbitrary, Entropy: Joules/Kelvin (J/K)",
    explanation: "Illustrates particle dispersal in a thermodynamic system, showing the progression toward maximum entropy and chaotic equilibrium.",
    simInfo: { currentState: "Gas particles dispersing toward maximum entropy", interpretation: "Particles naturally spread to occupy all available space. Entropy increases as the system explores more microstates — this is the thermodynamic arrow of time." }
  },
  navier: {
    title: "Viscous Fluid Flow & Velocity Fields",
    xAxis: "Horizontal Position (x)",
    yAxis: "Vertical Velocity Profile (v_y)",
    units: "Position: meters (m), Velocity: m/s",
    explanation: "Visualizes the velocity boundary layer profiles of a viscous fluid flowing through a narrow channel under shear stress.",
    simInfo: { currentState: "Viscous flow developing a parabolic velocity profile", interpretation: "Fluid at the wall has zero velocity (no-slip condition). Maximum velocity occurs at the channel center. Higher viscosity creates a flatter, slower profile." }
  },
  continuity: {
    title: "Fluid Continuity in Constricted Pipe",
    xAxis: "Length along Pipe (x)",
    yAxis: "Inlet and Outlet Velocity Vectors",
    units: "Length: meters (m), Velocity: m/s",
    explanation: "Demonstrates mass conservation in fluid dynamics where narrowing the pipe cross-section accelerates flow velocity proportionately.",
    simInfo: { currentState: "Incompressible fluid through a variable-width channel", interpretation: "When the pipe narrows, fluid must speed up to conserve mass flow rate: A₁v₁ = A₂v₂. Halving the area doubles the velocity." }
  },
  maxwell1: {
    title: "Electrostatic Field Divergence",
    xAxis: "Radial Distance (r)",
    yAxis: "Electric Field Intensity (E)",
    units: "Distance: meters (m), Electric Field: N/C",
    explanation: "Visualizes the radiating electric field lines surrounding a point charge, illustrating how flux density falls off with distance.",
    simInfo: { currentState: "Electric field radiating from a point charge", interpretation: "Field strength falls off as 1/r². The total flux through any closed surface enclosing the charge equals Q/ε₀ — regardless of surface shape." }
  },
  faraday: {
    title: "Induced Electromotive Force (EMF) Cycle",
    xAxis: "Time (t)",
    yAxis: "Magnetic Flux (Φ) vs Induced EMF (V)",
    units: "Time: seconds (s), EMF: Volts (V), Flux: Webers (Wb)",
    explanation: "Simulates a rotating magnet creating a time-varying magnetic field to induce a sinusoidal alternating electric current.",
    simInfo: { currentState: "Time-varying magnetic flux inducing EMF", interpretation: "The induced EMF is proportional to the rate of change of magnetic flux. When flux changes fastest (zero crossings), EMF peaks. This is how generators convert mechanical rotation to electricity." }
  },
  lorentz: {
    title: "Relativistic Time Dilation & Contraction",
    xAxis: "Relative Velocity (v/c)",
    yAxis: "Lorentz Dilation Factor (γ)",
    units: "Velocity: fraction of c, Factor: dimensionless",
    explanation: "Plots the exponential rise in the Lorentz factor as relative speed approaches the speed of light, showing key relativistic limits.",
    simInfo: { currentState: "Lorentz factor γ vs relative velocity", interpretation: "At low speeds, γ ≈ 1 (classical regime). As v approaches c, γ diverges to infinity — time slows, lengths contract, and mass increases without bound. No massive object can reach c." }
  },
  einstein: {
    title: "Mass to Energy Conversion Sandbox",
    xAxis: "Mass Conversion Scale (m)",
    yAxis: "Equivalent Rest Energy (E)",
    units: "Mass: kilograms (kg), Energy: Joules (J)",
    explanation: "Visualizes the conversion of rest mass into electromagnetic energy burst radiation according to E = mc².",
    simInfo: { currentState: "Rest mass converting to electromagnetic energy", interpretation: "Even a tiny mass contains enormous energy due to c² ≈ 9×10¹⁶. One kilogram of matter, if fully converted, releases ~90 petajoules — equivalent to a 21-megaton nuclear explosion." }
  },
  boltzmann: {
    title: "Boltzmann Thermal State Distribution",
    xAxis: "State Energy Level (E)",
    yAxis: "Occupancy Probability P(E)",
    units: "Energy: arbitrary, Probability: dimensionless",
    explanation: "Plots the exponential probability distribution of system states at thermal equilibrium for a given absolute temperature.",
    simInfo: { currentState: "Thermal probability distribution across energy states", interpretation: "Lower energy states are exponentially more probable. Higher temperature flattens the distribution, populating higher energy states. At T→0, only the ground state is occupied." }
  },
  projectile: {
    title: "Projectile Trajectory Arc",
    xAxis: "Horizontal Distance (m)",
    yAxis: "Vertical Height (m)",
    units: "Distance: meters (m), Time: seconds (s)",
    explanation: "Traces the parabolic trajectory of a launched projectile under gravitational acceleration, showing range and maximum height.",
    simInfo: { currentState: "Projectile tracing a parabolic arc under gravity", interpretation: "Horizontal motion is uniform (no air resistance), while vertical motion decelerates upward and accelerates downward. Maximum range occurs at 45° launch angle." }
  },
  energy: {
    title: "Kinetic ↔ Potential Energy Transfer",
    xAxis: "Position along Ramp",
    yAxis: "Energy (J)",
    units: "Energy: Joules (J), Height: meters (m)",
    explanation: "Visualizes the continuous conversion between kinetic and potential energy as a mass slides along an inclined ramp.",
    simInfo: { currentState: "Mass sliding on a frictionless ramp", interpretation: "At the top, energy is all potential (mgh). At the bottom, it's all kinetic (½mv²). The total mechanical energy remains constant throughout — energy is only transformed, never created or destroyed." }
  },
  momentum: {
    title: "Elastic Collision Momentum Transfer",
    xAxis: "Position (x)",
    yAxis: "Collision Dynamics",
    units: "Mass: kg, Velocity: m/s, Momentum: kg·m/s",
    explanation: "Simulates a 1D elastic collision between two masses, demonstrating conservation of total momentum before and after impact.",
    simInfo: { currentState: "Two masses approaching and colliding elastically", interpretation: "Total momentum p₁+p₂ is identical before and after collision. In elastic collisions, kinetic energy is also conserved. Heavier objects transfer more momentum per collision." }
  },
  circular: {
    title: "Uniform Circular Motion Track",
    xAxis: "Position (x)",
    yAxis: "Position (y)",
    units: "Force: Newtons (N), Velocity: m/s, Radius: m",
    explanation: "Visualizes an object moving along a circular path with a centripetal force vector always pointing toward the center.",
    simInfo: { currentState: "Object in uniform circular motion with centripetal force", interpretation: "The centripetal force always points radially inward. If this force vanishes, the object flies off tangentially. Higher speed or smaller radius requires stronger centripetal force." }
  },
  gravitation: {
    title: "Gravitational Field & Orbital Motion",
    xAxis: "Radial Distance",
    yAxis: "Gravitational Force",
    units: "Force: Newtons (N), Distance: ×10⁶ m, Mass: ×10²⁴ kg",
    explanation: "Simulates the gravitational interaction between two bodies with field lines and orbital dynamics.",
    simInfo: { currentState: "Two-body gravitational interaction with orbital motion", interpretation: "Gravitational force follows an inverse-square law: doubling the distance reduces force to one quarter. Stable orbits form when gravitational pull exactly provides the centripetal acceleration needed." }
  },
  bernoulli: {
    title: "Bernoulli Pressure-Velocity in Pipe",
    xAxis: "Length along Pipe (x)",
    yAxis: "Pressure (Pa) & Velocity (m/s)",
    units: "Pressure: Pascals (Pa), Velocity: m/s",
    explanation: "Demonstrates how fluid velocity increases and pressure decreases in a constricted pipe section according to Bernoulli's principle.",
    simInfo: { currentState: "Fluid flowing through a variable-width pipe", interpretation: "Where the pipe narrows, velocity increases and pressure drops (Bernoulli effect). This creates lift on airplane wings and draws fluid through spray bottles." }
  },
  reynolds_num: {
    title: "Laminar vs Turbulent Flow Visualization",
    xAxis: "Flow Direction (x)",
    yAxis: "Flow Pattern",
    units: "Reynolds Number: dimensionless",
    explanation: "Visualizes the transition from smooth laminar flow to chaotic turbulent flow as Reynolds number increases past the critical value.",
    simInfo: { currentState: "Flow pattern at current Reynolds number", interpretation: "Below Re ≈ 2300, flow is smooth and laminar. Above Re ≈ 4000, chaotic vortices dominate (turbulent). The transition depends on velocity, pipe size, and fluid viscosity." }
  },
  coulomb: {
    title: "Electrostatic Force Between Charges",
    xAxis: "Separation Distance (m)",
    yAxis: "Electrostatic Force (N)",
    units: "Force: Newtons (N), Charge: microcoulombs (μC)",
    explanation: "Visualizes the attractive or repulsive electrostatic force between two point charges with electric field lines.",
    simInfo: { currentState: "Electrostatic interaction between two point charges", interpretation: "Like charges repel, opposite charges attract. Force follows an inverse-square law identical in form to gravity, but ~10³⁶ times stronger for elementary particles." }
  },
  lorentzforce: {
    title: "Charged Particle in Magnetic Field",
    xAxis: "Position (x)",
    yAxis: "Position (y)",
    units: "Force: Newtons (N), Radius: μm, Field: Tesla (T)",
    explanation: "Shows a charged particle spiraling in a uniform magnetic field (into the page), demonstrating the Lorentz force creating circular orbits.",
    simInfo: { currentState: "Charged particle spiraling in a uniform magnetic field", interpretation: "The magnetic force is always perpendicular to velocity, so it changes direction but not speed. This creates circular or helical orbits whose radius depends on mass, charge, speed, and field strength." }
  },
  idealgas: {
    title: "Ideal Gas Particle Dynamics",
    xAxis: "Container Width",
    yAxis: "Container Height",
    units: "Pressure: kPa, Volume: m³, Temperature: Kelvin (K)",
    explanation: "Simulates gas molecules bouncing inside a container, with particle speed and container size reflecting temperature and volume changes.",
    simInfo: { currentState: "Gas molecules in thermal equilibrium within a container", interpretation: "Temperature determines average molecular speed. Pressure arises from molecular collisions with container walls. Reducing volume (at constant T) increases collision frequency, raising pressure." }
  },
  hooke: {
    title: "Spring-Mass Oscillation System",
    xAxis: "Time (s)",
    yAxis: "Displacement (m)",
    units: "Force: Newtons (N), Displacement: meters (m)",
    explanation: "Visualizes a spring-mass system oscillating about equilibrium with force vectors and a real-time position-time graph.",
    simInfo: { currentState: "Mass oscillating on a spring with restoring force", interpretation: "The spring force always opposes displacement — stretching produces a pulling force, compression produces a pushing force. This linear restoring force produces simple harmonic motion." }
  },
  shm: {
    title: "Simple Harmonic Motion — Pendulum & Waveform",
    xAxis: "Time (s)",
    yAxis: "Position x(t) (m)",
    units: "Amplitude: meters (m), Frequency: Hertz (Hz)",
    explanation: "Shows a pendulum swinging with a synchronized sinusoidal position-time graph, demonstrating the fundamental periodic motion.",
    simInfo: { currentState: "Pendulum oscillating with sinusoidal displacement", interpretation: "The motion is perfectly sinusoidal. Period depends only on length and gravity (not amplitude) for small angles. All SHM can be described by a single cosine function." }
  },
  ohm: {
    title: "Electric Circuit — Voltage, Current & Resistance",
    xAxis: "Circuit Position",
    yAxis: "Current Flow",
    units: "Voltage: Volts (V), Current: Amperes (A), Resistance: Ohms (Ω)",
    explanation: "Animates electron flow through a simple battery-resistor circuit, with speed proportional to current magnitude.",
    simInfo: { currentState: "Steady-state DC current flowing through a resistor", interpretation: "Higher voltage drives more current. Higher resistance impedes flow. Power dissipated as heat equals I²R. Electrons move slowly (drift velocity) but the electric field propagates at near light speed." }
  },
  debroglie: {
    title: "Matter Wave — de Broglie Wave Packet",
    xAxis: "Position (m)",
    yAxis: "Wave Amplitude",
    units: "Wavelength: meters (m), Momentum: kg·m/s",
    explanation: "Visualizes the quantum wave packet of a particle, showing how wavelength scales inversely with momentum.",
    simInfo: { currentState: "Quantum wave packet propagating in free space", interpretation: "Larger momentum means shorter wavelength. For electrons, the de Broglie wavelength is on the order of atomic dimensions (~0.1 nm), enabling electron diffraction and microscopy." }
  },
  photoelectric: {
    title: "Photoelectric Effect — Photon-Metal Interaction",
    xAxis: "Position",
    yAxis: "Energy",
    units: "Energy: electronvolts (eV), Frequency: Hertz (Hz)",
    explanation: "Simulates photons striking a metal surface. Above the threshold frequency, electrons are ejected; below it, no emission occurs regardless of intensity.",
    simInfo: { currentState: "Photons impacting a metal surface", interpretation: "Each photon carries energy E = hf. If hf > φ (work function), an electron is ejected with kinetic energy KE = hf - φ. This proved light behaves as discrete particles (photons), not just waves." }
  }
};

function EquationFullView({ equation, onClose, initialParams }) {
  const eq = equation
  const branchLabel = BRANCHES.find(b => b.id === eq.branch)?.label || eq.branch
  const [inputsEl, setInputsEl] = useState(null)
  const [resultsEl, setResultsEl] = useState(null)

  const hasMissingParams = initialParams && initialParams.paramDetails && 
    Object.values(initialParams.paramDetails).some(d => d.source === 'Missing');

  const metadata = GRAPH_METADATA[eq.id] || {
    title: "Simulation Graph Visualization",
    xAxis: "X-Axis",
    yAxis: "Y-Axis",
    units: "Arbitrary units",
    explanation: "Interactive simulation representing the physical system variables in real time."
  };

  const cardStyle = {
    background: 'rgba(255,255,255,0.01)',
    borderColor: 'rgba(196,149,106,0.35)',
    padding: '2.5rem',
  };

  return (
    <WorkspaceContext.Provider value={{ inputsTarget: inputsEl, resultsTarget: resultsEl }}>
      {/* Ambient floating particles — subtle, 10–15% intensity */}
      <BranchAmbientEffect branch={eq.branch} color={eq.color || '#C4956A'} />

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="w-full min-h-screen pb-32 relative pt-4"
        style={{ color: '#E8DDCC' }}
      >
        <div className="w-[90%] max-w-[1400px] mx-auto w-full flex flex-col gap-8">
          {/* 1. Top Left Exit Button — gold-accent outlined */}
          <div className="w-full flex justify-start">
            <button
              onClick={onClose}
              className="flex items-center gap-3 cursor-pointer font-mono tracking-widest uppercase text-xs font-bold animate-fade-in"
              style={{
                color: 'rgba(220,208,188,0.7)',
                transition: 'all 0.25s ease',
                padding: '8px 18px',
                borderRadius: '8px',
                border: `1px solid ${eq.color}35`,
                background: `${eq.color}08`,
                outline: 'none',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.color = eq.color
                e.currentTarget.style.borderColor = `${eq.color}60`
                e.currentTarget.style.background = `${eq.color}12`
              }}
              onMouseLeave={e => {
                e.currentTarget.style.color = 'rgba(220,208,188,0.7)'
                e.currentTarget.style.borderColor = `${eq.color}35`
                e.currentTarget.style.background = `${eq.color}08`
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="19" y1="12" x2="5" y2="12" /><polyline points="12 19 5 12 12 5" />
              </svg>
              Exit Workspace
            </button>
          </div>

          {/* 2. Center Header */}
          <div className="flex flex-col items-center text-center">
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase"
              style={{ color: eq.color, background: `${eq.color}14`, border: `1px solid ${eq.color}25` }}>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: eq.color }} />
              {branchLabel}
            </span>
            <div className="h-4" />
            <h1 className="text-3xl md:text-5xl font-bold font-display tracking-tight text-[#E8DDCC]">{eq.name}</h1>
          </div>

          {/* Row 1: Theory Section (Side by side cards with exactly 32px spacing) */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Card: Meaning & Apps */}
            <div className="rounded-2xl border flex flex-col justify-between gap-8" style={cardStyle}>
              <div>
                <h3 className="text-xs font-mono tracking-widest text-[rgba(220,208,188,0.45)] uppercase mb-4 font-bold">Meaning of the Equation</h3>
                <p className="text-sm md:text-base opacity-85 font-body leading-relaxed">{eq.description}</p>
              </div>
              <div>
                <h3 className="text-xs font-mono tracking-widest text-[rgba(220,208,188,0.45)] uppercase mb-4 font-bold">Real-World Applications</h3>
                <ul className="flex flex-col gap-3 text-sm opacity-80 font-body">
                  {eq.realWorldApps ? eq.realWorldApps.split(',').map((app, i) => (
                    <li key={i} className="leading-relaxed flex items-start gap-2.5">
                      <span style={{ color: eq.color, fontSize: '1.2rem', lineHeight: '1' }}>•</span>
                      <span>{app.trim()}</span>
                    </li>
                  )) : (
                    <li className="leading-relaxed flex items-start gap-2.5">
                      <span style={{ color: eq.color, fontSize: '1.2rem', lineHeight: '1' }}>•</span>
                      <span>Advanced scientific research and simulation analysis.</span>
                    </li>
                  )}
                </ul>
              </div>
            </div>

            {/* Right Card: Formula & Variables */}
            <div className="rounded-2xl border flex flex-col gap-3" style={cardStyle}>
              <div>
                <h3 className="text-xs font-mono tracking-widest text-[rgba(220,208,188,0.45)] uppercase mb-2 font-bold">Formula</h3>
                <div className="flex justify-center py-3 px-5 rounded-xl border border-[rgba(196,149,106,0.15)]" style={{ background: `${eq.color}08` }}>
                  <span className="font-display text-2xl md:text-3xl font-bold tracking-wide" style={{ color: eq.color, whiteSpace: 'pre-line' }}>
                    {eq.formula}
                  </span>
                </div>
              </div>
              <div>
                <h3 className="text-xs font-mono tracking-widest text-[rgba(220,208,188,0.45)] uppercase mb-2 font-bold">Variable Glossary</h3>
                <div className="flex flex-col gap-2 max-h-[200px] overflow-y-auto pr-1">
                  {eq.variables.map(v => (
                    <div key={v.symbol} className="flex gap-3.5 items-center text-xs py-2 border-b border-[rgba(255,255,255,0.03)] last:border-0">
                      <span className="font-display font-bold px-2 py-0.5 rounded text-center min-w-[28px] text-[11px]" style={{ background: `${eq.color}18`, color: eq.color, border: `1px solid ${eq.color}30` }}>
                        {v.symbol}
                      </span>
                      <span className="opacity-85 font-body leading-relaxed">{v.def}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Missing Parameters Warning Banner */}
          {hasMissingParams && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              style={{
                padding: '16px 20px',
                borderRadius: '12px',
                background: 'rgba(224, 120, 64, 0.08)',
                border: '1px solid rgba(224, 120, 64, 0.3)',
                color: '#E07840',
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                fontFamily: 'var(--font-body)',
                fontSize: '0.88rem',
                fontWeight: 500,
                marginTop: '8px'
              }}
            >
              <span style={{ fontSize: '1.2rem' }}>⚠️</span>
              <span>
                <strong>Missing Parameters:</strong> Please enter the missing inputs in the Laboratory Inputs card below to calculate.
              </span>
            </motion.div>
          )}

          {/* Row 2: Inputs and Results Section (Exactly 32px spacing) */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Laboratory Inputs Card */}
            <div className="flex flex-col gap-6 rounded-2xl border" style={cardStyle}>
              <h2 className="text-xl md:text-2xl font-bold font-display text-[#E8DDCC] border-b border-[rgba(255,255,255,0.05)] pb-3">Laboratory Inputs</h2>
              <div ref={setInputsEl} className="flex flex-col gap-5">
                {/* Dynamic portal content (actual numeric fields with Calc buttons) */}
              </div>
            </div>

            {/* Calculated Results Card */}
            <div className="flex flex-col gap-6 rounded-2xl border" style={cardStyle}>
              <h2 className="text-xl md:text-2xl font-bold font-display text-[#E8DDCC] border-b border-[rgba(255,255,255,0.05)] pb-3">Calculated Results</h2>
              <div ref={setResultsEl} className="flex flex-col gap-5">
                {/* Dynamic portal content (derived state variables with clear spacing) */}
              </div>
            </div>
          </div>

          {/* Row 3: Simulation Section */}
          <div className="w-full flex flex-col gap-4 rounded-2xl border animate-fade-in" style={{ ...cardStyle, background: 'rgba(255,255,255,0.005)' }}>
            {/* Simulation header */}
            <div className="border-b border-[rgba(196,149,106,0.15)] pb-4">
              <h2 className="text-xl md:text-2xl font-bold font-display text-[#E8DDCC] mb-2">{metadata.title}</h2>
              <p className="text-xs md:text-sm opacity-75 font-body leading-relaxed">{metadata.explanation}</p>
            </div>

            {/* Compact Simulation Info Bar */}
            <div className="flex flex-wrap gap-3 items-center px-4 py-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(196,149,106,0.08)' }}>
              <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider" style={{ color: `${eq.color}AA` }}>
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: eq.color }} />
                <span>X: {metadata.xAxis}</span>
              </div>
              <span className="text-[rgba(220,208,188,0.15)]" style={{ fontSize: '10px' }}>│</span>
              <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider text-[#88C0B8AA]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#88C0B8]" />
                <span>Y: {metadata.yAxis}</span>
              </div>
              <span className="text-[rgba(220,208,188,0.15)]" style={{ fontSize: '10px' }}>│</span>
              <div className="text-[10px] font-mono uppercase tracking-wider text-[rgba(220,208,188,0.4)]">
                Units: {metadata.units}
              </div>
            </div>

            {/* Dynamic Simulation Info Panel */}
            {metadata.simInfo && (
              <div className="flex flex-col sm:flex-row gap-4 px-1">
                <div className="flex-1 p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.015)', border: '1px solid rgba(196,149,106,0.1)', borderLeft: `3px solid ${eq.color}40` }}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-1.5 h-1.5 rounded-full" style={{ background: eq.color }} />
                    <span className="text-[10px] font-mono uppercase tracking-wider" style={{ color: `${eq.color}99` }}>Current State</span>
                  </div>
                  <p className="text-xs font-body leading-relaxed" style={{ color: 'rgba(232,221,204,0.7)' }}>{metadata.simInfo.currentState}</p>
                </div>
                <div className="flex-1 p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.015)', border: '1px solid rgba(136,192,184,0.1)', borderLeft: '3px solid rgba(136,192,184,0.3)' }}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#88C0B8]" />
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#88C0B899]">Physical Interpretation</span>
                  </div>
                  <p className="text-xs font-body leading-relaxed" style={{ color: 'rgba(232,221,204,0.7)' }}>{metadata.simInfo.interpretation}</p>
                </div>
              </div>
            )}

            {eq.Simulator ? (
              <div className="w-full relative mt-1">
                {/* Y-Axis Label Annotation */}
                <div className="absolute top-4 left-4 z-20 flex items-center gap-1.5 text-[10px] font-mono text-[rgba(220,208,188,0.65)] uppercase tracking-wider bg-[rgba(20,18,16,0.9)] px-3 py-2 rounded-lg border border-[rgba(196,149,106,0.12)] backdrop-blur-sm pointer-events-none">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#88C0B8]" />
                  <span>Y: {metadata.yAxis}</span>
                </div>

                {/* Scale/Units Annotation */}
                <div className="absolute top-4 right-4 z-20 text-[10px] font-mono text-[rgba(220,208,188,0.55)] uppercase tracking-wider bg-[rgba(20,18,16,0.9)] px-3 py-2 rounded-lg border border-[rgba(196,149,106,0.12)] backdrop-blur-sm pointer-events-none">
                  <span>{metadata.units}</span>
                </div>

                {/* Simulator Canvas */}
                <eq.Simulator inputsTarget={inputsEl} resultsTarget={resultsEl} initialParams={initialParams} />

                {/* X-Axis Label Annotation */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 text-[10px] font-mono text-[rgba(220,208,188,0.65)] uppercase tracking-wider bg-[rgba(20,18,16,0.9)] px-3 py-2 rounded-lg border border-[rgba(196,149,106,0.12)] backdrop-blur-sm pointer-events-none">
                  <span className="w-1.5 h-1.5 rounded-full" style={{ background: eq.color }} />
                  <span>X: {metadata.xAxis}</span>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center border border-dashed border-[rgba(196,149,106,0.2)] rounded-xl p-12 w-full bg-[rgba(0,0,0,0.2)]">
                <span className="text-sm opacity-40 font-mono">WORKSPACE_ERR: NO_SIMULATOR_INSTANCE_FOUND</span>
              </div>
            )}
          </div>

          {/* Row 4: Scientific Interpretation */}
          <div className="rounded-2xl border" style={cardStyle}>
            <h2 className="text-xl md:text-2xl font-bold font-display text-[#E8DDCC] border-b border-[rgba(255,255,255,0.05)] pb-3 mb-4">Physical Meaning</h2>
            <div className="flex flex-col gap-3">
              {getInterpretation(eq.id, initialParams?.params || {}).map((line, i) => (
                <div key={i} className="flex items-start gap-3" style={{ padding: '8px 12px', borderRadius: '10px', background: i === 0 ? `${eq.color}08` : 'transparent', borderLeft: i === 0 ? `3px solid ${eq.color}40` : '3px solid transparent' }}>
                  <span style={{ color: eq.color, marginTop: '2px', fontSize: '0.7rem' }}>{i === 0 ? '◆' : '◇'}</span>
                  <p className="text-sm font-body leading-relaxed" style={{ color: i === 0 ? 'rgba(232,221,204,0.9)' : 'rgba(232,221,204,0.65)' }}>{line}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </WorkspaceContext.Provider>
  )
}

// ══════════════════════════
//  MAIN EXPLORE COMPONENT
// ══════════════════════════
export default function Explore({ initialEquationId, initialParams, onEquationConsumed }) {
  const [search, setSearch] = useState('')
  const [activeBranch, setActiveBranch] = useState('all')
  const [selectedEquation, setSelectedEquation] = useState(null)

  // Auto-select equation when navigated from landing page classifier
  useEffect(() => {
    if (initialEquationId) {
      const eq = EQUATIONS.find(e => e.id === initialEquationId)
      if (eq) {
        setSelectedEquation(eq)
        window.scrollTo({ top: 0, behavior: 'smooth' })
      }
      if (onEquationConsumed) onEquationConsumed()
    }
  }, [initialEquationId, onEquationConsumed])

  const hasSearch = search.trim().length > 0

  const listedEquations = useMemo(() =>
    EQUATIONS.filter(eq => activeBranch === 'all' || eq.branch === activeBranch),
  [activeBranch])

  const searchResults = useMemo(() => {
    if (!hasSearch) return []
    const q = search.toLowerCase()
    return EQUATIONS.filter(eq =>
      eq.name.toLowerCase().includes(q) ||
      eq.formula.toLowerCase().includes(q) ||
      eq.branch.toLowerCase().includes(q)
    )
  }, [search, hasSearch])

  const handleSelectEquation = (eq) => {
    setSelectedEquation(eq)
    setSearch('')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <div className="w-full min-h-screen relative" style={{ background: 'transparent', color: '#DDD0BC', fontFamily: 'var(--font-body)', overflowX: 'hidden' }}>

      {/* Floating orb background animation */}
      <FloatingOrbs />
      {!selectedEquation && <CornerAnimations />}

      <div className="relative z-10 w-full">
        <AnimatePresence mode="wait">
          {selectedEquation ? (
            /* ═══ FULL-PAGE EQUATION VIEW ═══ */
            <motion.div
              key="equation-detail"
              className="px-4 md:px-8 pb-24 w-full"
              style={{ paddingTop: '150px' }}
            >
              <EquationFullView
                equation={selectedEquation}
                onClose={() => setSelectedEquation(null)}
                initialParams={initialParams}
              />
            </motion.div>
          ) : (
            /* ═══ BROWSE / SEARCH VIEW ═══ */
            <motion.div
              key="browse-view"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
              className="w-full"
            >
              {/* Header */}
              <div className="text-center w-full" style={{ paddingTop: '130px', paddingBottom: '32px' }}>
                <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
                  <span className="inline-flex items-center gap-2 mb-8 px-5 py-2 rounded-full text-xs tracking-widest uppercase"
                    style={{ color: 'rgba(196,149,106,0.65)', border: '1px solid rgba(196,149,106,0.2)', background: 'rgba(196,149,106,0.06)', letterSpacing: '0.18em' }}>
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                    Interactive Equations
                  </span>

                  <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2.5rem, 5vw, 4.5rem)', fontWeight: 700, letterSpacing: '-0.03em', lineHeight: 1.1, color: '#E8DDCC', marginBottom: '14px' }}>
                    The Scientific Sandbox
                  </h1>
                </motion.div>

                {/* CENTERED Search bar — LARGER SIZE */}
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 }}
                  className="mt-14 mb-8 px-4"
                  style={{ maxWidth: '820px', margin: '48px auto 20px' }}
                >
                  <div
                    className="flex items-center gap-4 px-7 py-4.5 rounded-2xl"
                    style={{
                      background: 'rgba(255,255,255,0.04)',
                      border: '1px solid rgba(196,149,106,0.25)',
                      padding: '16px 28px',
                      boxShadow: hasSearch ? '0 0 0 3px rgba(196,149,106,0.14)' : 'none',
                      transition: 'all 0.2s',
                    }}
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgba(196,149,106,0.6)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                      <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
                    </svg>
                    <input
                      type="text"
                      placeholder="Search equations — Schrödinger, E=mc², Entropy..."
                      value={search}
                      onChange={e => setSearch(e.target.value)}
                      className="flex-1 bg-transparent border-none outline-none"
                      style={{ fontFamily: 'var(--font-body)', fontSize: '16.5px', color: '#DDD0BC', caretColor: '#C4956A', letterSpacing: '0.01em' }}
                    />
                    {search && (
                      <button onClick={() => setSearch('')}
                        style={{ color: 'rgba(196,149,106,0.65)', background: 'none', border: 'none', cursor: 'pointer', fontSize: '24px', lineHeight: 1 }}>
                        ×
                      </button>
                    )}
                  </div>
                  {!hasSearch && (
                    <p className="text-center" style={{ marginTop: '14px', fontSize: '13px', color: 'rgba(220,200,165,0.38)', letterSpacing: '0.04em' }}>
                      Search to find equations, or browse by branch below
                    </p>
                  )}
                </motion.div>
              </div>

              {/* Search Results */}
              <AnimatePresence>
                {hasSearch && (
                  <motion.div
                    key="search-results"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="px-8 pb-10"
                  >
                    <div className="max-w-5xl mx-auto">
                      <p style={{ fontSize: '13px', color: 'rgba(220,200,165,0.35)', marginBottom: '20px' }}>
                        {searchResults.length} result{searchResults.length !== 1 ? 's' : ''} for "{search}"
                      </p>
                      <div className="flex flex-col gap-3">
                        {searchResults.map((eq, idx) => (
                           <motion.button
                            key={eq.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: idx * 0.04 }}
                            onClick={() => handleSelectEquation(eq)}
                            className="flex items-center justify-between w-full rounded-xl cursor-pointer"
                            style={{ padding: '18px 24px', background: 'rgba(255,255,255,0.025)', border: `1px solid ${eq.color}40`, textAlign: 'left', transition: 'all 0.18s', fontFamily: 'var(--font-body)' }}
                            whileHover={{ background: 'rgba(255,255,255,0.05)', borderColor: `${eq.color}80` }}
                          >
                            <div className="flex items-center gap-4">
                              <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: eq.color }} />
                              <div>
                                <span style={{ fontSize: '16.5px', fontWeight: 500, color: '#DDD0BC', display: 'block' }}>{eq.name}</span>
                                <span style={{ fontSize: '12px', color: 'rgba(220,208,188,0.35)', marginTop: '3px', display: 'block' }}>
                                  {BRANCHES.find(b => b.id === eq.branch)?.label}
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center gap-4">
                              <span style={{ fontFamily: 'var(--font-display)', fontSize: '15px', color: `${eq.color}80`, whiteSpace: 'pre-line' }}>{eq.formula}</span>
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(220,208,188,0.3)" strokeWidth="2">
                                <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
                              </svg>
                            </div>
                          </motion.button>
                        ))}
                        {searchResults.length === 0 && (
                          <div className="text-center py-20" style={{ color: 'rgba(220,208,188,0.25)', fontSize: '15px' }}>
                            No equations match "{search}"
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Browse: Branches left, Equation names right */}
              {!hasSearch && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.4, delay: 0.15 }}
                  className="px-8 pb-20"
                  style={{ marginTop: '30px' }}
                >
                  <div className="max-w-7xl mx-auto flex gap-16 items-start w-full px-4">

                    {/* LEFT: Branches */}
                    <div className="shrink-0" style={{ width: '250px' }}>
                      <p style={{ fontSize: '11px', fontWeight: 600, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgba(196,149,106,0.45)', marginBottom: '20px' }}>
                        Branches
                      </p>
                      <div className="flex flex-col gap-2.5">
                        {BRANCHES.map(branch => {
                          const isActive = activeBranch === branch.id
                          const count = branch.id === 'all' ? EQUATIONS.length : EQUATIONS.filter(e => e.branch === branch.id).length
                          return (
                            <button
                              key={branch.id}
                              onClick={() => setActiveBranch(branch.id)}
                              className="flex items-center justify-between w-full rounded-xl cursor-pointer"
                              style={{
                                padding: '12px 20px',
                                background: isActive ? `${branch.color}15` : 'transparent',
                                border: isActive ? `1px solid ${branch.color}28` : '1px solid transparent',
                                fontFamily: 'var(--font-body)', fontSize: '14px',
                                fontWeight: isActive ? 500 : 400,
                                color: isActive ? branch.color : 'rgba(220,208,188,0.45)',
                                textAlign: 'left', transition: 'all 0.18s',
                              }}
                            >
                              <span>{branch.label}</span>
                              <span style={{ fontSize: '12px', opacity: 0.5, fontWeight: 400 }}>{count}</span>
                            </button>
                          )
                        })}
                      </div>
                    </div>

                    {/* Divider */}
                    <div style={{ width: '1px', alignSelf: 'stretch', background: 'rgba(196,149,106,0.07)', minHeight: '500px' }} />

                    {/* RIGHT: Equation Names */}
                    <div className="flex-1">
                      <p style={{ fontSize: '11px', fontWeight: 600, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgba(196,149,106,0.45)', marginBottom: '20px' }}>
                        {(BRANCHES.find(b => b.id === activeBranch) || BRANCHES[0]).label} · {listedEquations.length} equations
                      </p>
                      <div className="flex flex-col gap-4">
                        {listedEquations.map((eq, idx) => (
                          <motion.button
                            key={eq.id}
                            initial={{ opacity: 0, x: 12 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.35, delay: idx * 0.04 }}
                            onClick={() => handleSelectEquation(eq)}
                            className="flex items-center justify-between w-full rounded-xl cursor-pointer"
                            style={{
                              padding: '18px 26px',
                              background: 'rgba(255,255,255,0.02)',
                              border: '1px solid rgba(196,149,106,0.22)',
                              fontFamily: 'var(--font-body)', textAlign: 'left',
                              transition: 'all 0.18s',
                            }}
                            whileHover={{ background: 'rgba(255,255,255,0.04)', borderColor: `${eq.color}55` }}
                          >
                            <div className="flex items-center gap-4">
                              <span className="w-2 h-2 rounded-full shrink-0" style={{ background: eq.color }} />
                              <span style={{ fontSize: '16.5px', fontWeight: 500, color: '#DDD0BC', letterSpacing: '-0.01em' }}>
                                {eq.name}
                              </span>
                            </div>
                            <div className="flex items-center gap-5">
                              <span style={{ fontFamily: 'var(--font-display)', fontSize: '14.5px', color: 'rgba(220,208,188,0.25)', whiteSpace: 'pre-line' }}>
                                {eq.formula}
                              </span>
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(220,208,188,0.22)" strokeWidth="2">
                                <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
                              </svg>
                            </div>
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
