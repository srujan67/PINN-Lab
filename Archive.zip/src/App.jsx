import { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import useSmoothScroll from './hooks/useSmoothScroll'
import Navbar from './components/Navbar'
import HeroSection from './components/HeroSection'
import Explore from './components/Explore'
import HistoryPage from './components/HistoryPage'
import ParticleUniverse from './components/ParticleUniverse'

// Smooth page transition variants
const pageVariants = {
  initial: {
    opacity: 0,
    y: 30,
    filter: 'blur(6px)',
  },
  animate: {
    opacity: 1,
    y: 0,
    filter: 'blur(0px)',
    transition: {
      duration: 0.7,
      ease: [0.16, 1, 0.3, 1],
    },
  },
  exit: {
    opacity: 0,
    y: -20,
    filter: 'blur(4px)',
    transition: {
      duration: 0.45,
      ease: [0.55, 0, 1, 0.45],
    },
  },
}

export default function App() {
  useSmoothScroll()
  const [currentPage, setCurrentPage] = useState('home')
  const [currentUser, setCurrentUser] = useState(() => {
    const user = localStorage.getItem('pinn_session_user')
    return user ? JSON.parse(user) : null
  })
  const [pendingEquationId, setPendingEquationId] = useState(null)
  const [pendingParams, setPendingParams] = useState(null)

  const isDark = currentPage === 'home'

  // Called from HeroSection when user clicks a detected equation
  const handleNavigateToEquation = useCallback((equationId, params = null) => {
    setPendingEquationId(equationId)
    setPendingParams(params)
    setCurrentPage('explore')
  }, [])

  // Clear pending equation after Explore has consumed it
  const handleEquationConsumed = useCallback(() => {
    setPendingEquationId(null)
    setPendingParams(null)
  }, [])

  return (
    <div
      className="relative min-h-screen transition-colors duration-700 ease-in-out"
      style={{
        background: isDark ? 'var(--color-bg-primary)' : '#141210',
      }}
    >
      {/* Persistent Particle Background */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          zIndex: 0,
          opacity: currentPage === 'home' ? 0.35 : 0.2,
          transition: 'opacity 0.6s ease',
        }}
      >
        <ParticleUniverse />
      </div>

      {/* Navbar */}
      <Navbar
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        currentUser={currentUser}
        setCurrentUser={setCurrentUser}
      />

      <main className="w-full">
        <AnimatePresence mode="wait">
          {currentPage === 'home' ? (
            <motion.div
              key="home-page"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="w-full"
            >
              <HeroSection
                onEnterExplore={() => setCurrentPage('explore')}
                onNavigateToEquation={handleNavigateToEquation}
              />
            </motion.div>
          ) : currentPage === 'explore' ? (
            <motion.div
              key="explore-page"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="w-full"
            >
              <Explore
                initialEquationId={pendingEquationId}
                initialParams={pendingParams}
                onEquationConsumed={handleEquationConsumed}
              />
            </motion.div>
          ) : (
            <motion.div
              key="history-page"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="w-full"
            >
              <HistoryPage
                currentUser={currentUser}
                setCurrentUser={setCurrentUser}
                onNavigateToEquation={handleNavigateToEquation}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  )
}
